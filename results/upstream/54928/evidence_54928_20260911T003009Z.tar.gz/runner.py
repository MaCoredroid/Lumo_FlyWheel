#!/usr/bin/env python3
"""#54928 related reproduction on GB10 — one server launch, fixed request set.

Usage: runner.py --arm A|B --launch L1|L2 --port 8000
Everything is recorded: resolved argv (/proc/<pid>/cmdline), /v1/models,
every request JSON, every raw response JSON, /metrics snapshots, server log.
"""
import argparse
import hashlib
import json
import os
import signal
import subprocess
import sys
import time
import urllib.request

E = os.path.dirname(os.path.abspath(__file__))
TARGET = "Qwen/Qwen3.8-27B-FP8"
TARGET_REV = "017b9c7af6b5689d5dd426a76e0bc077eb5ca20a"
DRAFT = "incoai/Qwen3.8-27B-DFlash2"
DRAFT_REV = "dedf8df68adfb1afeaf7b7480c0a0243108177b4"
K = 7

COMMON_ARGS = [
    "--revision", TARGET_REV,
    "--tensor-parallel-size", "1",
    "--no-enable-prefix-caching",
    "--max-num-seqs", "4",
    "--max-model-len", "4096",
    "--logprobs-mode", "raw_logprobs",
    "--served-model-name", "qwen38",
    "--gpu-memory-utilization", "0.50",
]

CASES = {
    "G": {
        "messages": [{"role": "user", "content": "Write a git command sequence to squash the last 3 commits."}],
        "seed": 1234,
        "chat_template_kwargs": {"enable_thinking": False},
    },
    "T": {
        "messages": [{"role": "user", "content": "hazme un tetris de gatos en una pagina web, debe de ser muy impactante y visualmente atractivo con efecto gráficos y sonoros"}],
        "seed": 20260902,
        "chat_template_kwargs": {"reasoning_effort": "medium", "preserve_thinking": True},
    },
}
SAMPLING = dict(temperature=0, top_p=1, top_k=-1, min_p=0, repetition_penalty=1,
                presence_penalty=0, frequency_penalty=0, min_tokens=0, ignore_eos=False,
                max_tokens=256, n=1, stream=False, logprobs=True, top_logprobs=5,
                return_token_ids=True, return_tokens_as_token_ids=True)
REPS = 5


def http(url, data=None, timeout=600):
    req = urllib.request.Request(url, data=json.dumps(data).encode() if data is not None else None,
                                 headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read().decode()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--arm", choices=["A", "B"], required=True)
    ap.add_argument("--launch", required=True)
    ap.add_argument("--port", type=int, default=8000)
    ap.add_argument("--spec-config", default=json.dumps({"model": DRAFT, "revision": DRAFT_REV,
                                                          "num_speculative_tokens": K}))
    a = ap.parse_args()
    out = os.path.join(E, "runs", f"{a.launch}_{a.arm}")
    os.makedirs(out, exist_ok=True)
    env = dict(os.environ, HF_HOME=os.path.join(E, "hf"), HF_HUB_OFFLINE="1",
               # FlashInfer JIT (sampling kernels on sm_121) shells out to `ninja`; the venv's bin must be on PATH
               PATH=os.path.join(E, ".venv/bin") + os.pathsep + os.environ.get("PATH", ""),
               FLASHINFER_WORKSPACE_BASE=os.path.join(E, "flashinfer_ws"))
    argv = [os.path.join(E, ".venv/bin/vllm"), "serve", TARGET, *COMMON_ARGS, "--port", str(a.port)]
    if a.arm == "B":
        argv += ["--speculative-config", a.spec_config]
    log = open(os.path.join(out, "server.log"), "w")
    t0 = time.time()
    srv = subprocess.Popen(argv, stdout=log, stderr=subprocess.STDOUT, env=env, start_new_session=True)
    base = f"http://127.0.0.1:{a.port}"
    ready = False
    while time.time() - t0 < 1800:
        if srv.poll() is not None:
            break
        try:
            http(base + "/health", timeout=5)
            ready = True
            break
        except Exception:
            time.sleep(5)
    meta = {"arm": a.arm, "launch": a.launch, "argv": argv, "started_utc": time.strftime("%FT%TZ", time.gmtime(t0)),
            "ready": ready, "startup_s": round(time.time() - t0, 1), "server_exit": srv.poll()}
    if ready:
        try:
            with open(f"/proc/{srv.pid}/cmdline", "rb") as f:
                meta["proc_cmdline"] = f.read().split(b"\0")
                meta["proc_cmdline"] = [x.decode() for x in meta["proc_cmdline"] if x]
        except Exception as ex:
            meta["proc_cmdline_error"] = repr(ex)
        meta["models"] = json.loads(http(base + "/v1/models"))
        try:
            meta["version"] = json.loads(http(base + "/version"))
        except Exception:
            pass
        order = [(c, r) for c in ("G", "T") for r in range(1, REPS + 1)]
        meta["order"] = order
        for case, rep in order:
            req = {"model": "qwen38", **SAMPLING, **{k: v for k, v in CASES[case].items()}}
            tag = f"{case}{rep}"
            with open(os.path.join(out, f"req_{tag}.json"), "w") as f:
                json.dump(req, f, indent=1, ensure_ascii=False)
            t1 = time.time()
            try:
                resp = http(base + "/v1/chat/completions", req)
            except Exception as ex:
                resp = json.dumps({"error": repr(ex)})
            with open(os.path.join(out, f"resp_{tag}.json"), "w") as f:
                f.write(resp)
            try:
                with open(os.path.join(out, f"metrics_{tag}.txt"), "w") as f:
                    f.write(http(base + "/metrics"))
            except Exception:
                pass
            print(f"[{a.launch}/{a.arm}] {tag} {round(time.time() - t1, 1)}s", flush=True)
    meta["finished_utc"] = time.strftime("%FT%TZ", time.gmtime())
    with open(os.path.join(out, "meta.json"), "w") as f:
        json.dump(meta, f, indent=1)
    if srv.poll() is None:
        os.killpg(os.getpgid(srv.pid), signal.SIGINT)
        try:
            srv.wait(120)
        except subprocess.TimeoutExpired:
            os.killpg(os.getpgid(srv.pid), signal.SIGKILL)
    log.close()
    print(f"[{a.launch}/{a.arm}] done ready={ready} exit={srv.poll()}", flush=True)
    return 0 if ready else 2


if __name__ == "__main__":
    sys.exit(main())
