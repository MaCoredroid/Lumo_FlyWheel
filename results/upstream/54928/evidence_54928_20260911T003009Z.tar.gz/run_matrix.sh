#!/usr/bin/env bash
# #54928 related reproduction — initial matrix per EXPERIMENT_CARD_54928.md v2.
# Launch order: L1 = A then B; L2 = B then A. One server at a time. Serial requests.
set -u
E=/home/mark/shared/exp54928
cd "$E"
export HF_HOME="$E/hf" HF_HUB_OFFLINE=1
{
  echo "=== matrix start $(date -u +%FT%TZ)"
  nvidia-smi --query-gpu=name,driver_version,memory.used --format=csv,noheader
  .venv/bin/python -c "import vllm,torch;print('vllm',vllm.__version__,'torch',torch.__version__,'cuda',torch.version.cuda)"
  sha256sum wheels/*.whl
  ls hf/hub/models--*/snapshots/
  for step in "L1 A" "L1 B" "L2 B" "L2 A"; do
    set -- $step
    # GB10 unified memory: the CUDA free-memory query counts clean page cache (the model files) as used,
    # so vLLM's startup check fails on every launch after the first. Drop clean caches before each launch.
    sudo -n sh -c 'sync; echo 3 > /proc/sys/vm/drop_caches' 2>/dev/null; sleep 3
    free_gib=$(.venv/bin/python -c "import torch;f,t=torch.cuda.mem_get_info();print(round(f/2**30,1))" 2>/dev/null || echo 0)
    echo "--- $1/$2 start $(date -u +%FT%TZ) free=${free_gib}GiB"
    .venv/bin/python runner.py --launch "$1" --arm "$2" --port 8000
    rc=$?
    echo "--- $1/$2 exit=$rc $(date -u +%FT%TZ)"
    # make sure nothing lingers on the GPU between launches
    pkill -f 'vllm serve' 2>/dev/null; sleep 10
    nvidia-smi --query-gpu=memory.used --format=csv,noheader
  done
  echo "=== matrix end $(date -u +%FT%TZ)"
  .venv/bin/python analyze.py
} 2>&1 | tee -a logs/matrix.log
