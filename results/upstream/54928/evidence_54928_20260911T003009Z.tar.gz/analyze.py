#!/usr/bin/env python3
"""Token-ID-level attribution for the #54928 reproduction runs.

For each launch pair (Lx_A, Lx_B) and case: check within-launch stability,
between-launch stability, then at the first differing generated position p
(identical preceding IDs) record A (target-only emitted + maximizers), E
(speculative emitted), V (set of verifier maximizers from B's top-5), tie
status, and top-two margins in nats. Prints a table and writes summary.json.
"""
import glob
import json
import math
import os
import sys

E = os.path.dirname(os.path.abspath(__file__))
RUNS = os.path.join(E, "runs")


def load(run, tag):
    p = os.path.join(RUNS, run, f"resp_{tag}.json")
    if not os.path.exists(p):
        return None
    d = json.load(open(p))
    if "choices" not in d:
        return {"error": d}
    ch = d["choices"][0]
    ids = ch.get("token_ids")
    lp = (ch.get("logprobs") or {}).get("content") or []
    # alignment: same length AND every returned "token_id:N" equals ids[i]
    mism = None
    if ids is not None and len(ids) == len(lp):
        mism = sum(1 for i, e in enumerate(lp) if tid(e.get("token")) != ids[i])
    return {"ids": ids, "lp": lp, "finish": ch.get("finish_reason"),
            "aligned": ids is not None and len(ids) == len(lp) and mism == 0,
            "id_mismatches": mism, "usage": d.get("usage")}


def tid(s):
    # return_tokens_as_token_ids=True renders tokens as "token_id:N"
    return int(s.split(":", 1)[1]) if isinstance(s, str) and s.startswith("token_id:") else s


def maximizers(entry):
    tops = entry.get("top_logprobs") or []
    if not tops:
        return set(), None, None
    vals = sorted((t["logprob"] for t in tops), reverse=True)
    best = vals[0]
    V = {tid(t["token"]) for t in tops if t["logprob"] == best}
    # tied maximum => top-two margin is zero by definition
    margin = 0.0 if len(V) > 1 else ((best - vals[1]) if len(vals) > 1 else None)
    return V, best, margin


def first_div(a, b):
    n = min(len(a), len(b))
    for i in range(n):
        if a[i] != b[i]:
            return i
    return None if len(a) == len(b) else n


def main():
    launches = sorted({os.path.basename(r).split("_")[0] for r in glob.glob(os.path.join(RUNS, "L*_A"))})
    summary = {}
    rows = []
    for L in launches:
        for case in ("G", "T"):
            A_all = [load(f"{L}_A", f"{case}{r}") for r in range(1, 6)]
            B_all = [load(f"{L}_B", f"{case}{r}") for r in range(1, 6)]
            A = [x for x in A_all if x and "error" not in x]
            B = [x for x in B_all if x and "error" not in x]
            key = f"{L}/{case}"
            errs = {"A_missing_or_error": 5 - len(A), "B_missing_or_error": 5 - len(B),
                    "A_errors": [x["error"] for x in A_all if x and "error" in x],
                    "B_errors": [x["error"] for x in B_all if x and "error" in x]}
            if not A or not B:
                summary[key] = {"status": "missing", "nA": len(A), "nB": len(B), **errs}
                rows.append((key, "missing", "", "", "", "", "", ""))
                continue
            a_ids = [x["ids"] for x in A]
            b_ids = [x["ids"] for x in B]
            a_stable = all(i == a_ids[0] for i in a_ids)
            b_stable = all(i == b_ids[0] for i in b_ids)
            aligned = all(x["aligned"] for x in A + B)
            p = first_div(a_ids[0], b_ids[0])
            # all comparable repetitions: distinct sequences per arm and every cross pair
            a_distinct = []
            [a_distinct.append(i) for i in a_ids if i not in a_distinct]
            b_distinct = []
            [b_distinct.append(i) for i in b_ids if i not in b_distinct]
            pairs = [{"A_variant": ai, "B_variant": bi, "first_div": first_div(a, b)}
                     for ai, a in enumerate(a_distinct) for bi, b in enumerate(b_distinct)]
            rec = {**errs, "A_distinct_sequences": len(a_distinct), "B_distinct_sequences": len(b_distinct),
                   "A_variant_counts": [a_ids.count(x) for x in a_distinct],
                   "B_variant_counts": [b_ids.count(x) for x in b_distinct],
                   "all_pairs_first_div": pairs,
                   "id_mismatches_A": [x["id_mismatches"] for x in A], "id_mismatches_B": [x["id_mismatches"] for x in B],
                   "A_within_launch_stable": a_stable, "B_within_launch_stable": b_stable,
                   "logprob_alignment_ok": aligned, "A_len": len(a_ids[0]), "B_len": len(b_ids[0]),
                   "A_finish": A[0]["finish"], "B_finish": B[0]["finish"], "first_divergence": p}
            pattern = "no divergence before EOS/limit" if p is None else ""
            if p is not None and p < len(a_ids[0]) and p < len(b_ids[0]) and aligned:
                a_e = a_ids[0][p]
                e = b_ids[0][p]
                VA, bestA, mA = maximizers(A[0]["lp"][p])
                VB, bestB, mB = maximizers(B[0]["lp"][p])
                uniqueV = len(VB) == 1
                v = next(iter(VB)) if uniqueV else None
                if uniqueV:
                    if e == v and v != a_e:
                        pattern = "E == V != A"
                    elif e != v and v == a_e:
                        pattern = "A == V != E"
                    elif e == v == a_e:
                        pattern = "E == V == A (?)"
                    else:
                        pattern = "E != V, V != A"
                else:
                    pattern = "argmax unresolved from returned logprobs (tie)"
                rec.update({"A_emitted": a_e, "A_maximizers": sorted(VA), "A_top2_margin_nats": mA,
                            "E_emitted": e, "V_maximizers": sorted(VB), "V_unique": uniqueV,
                            "B_top2_margin_nats": mB, "pattern": pattern})
            elif p is not None:
                pattern = "length-only divergence" if not aligned else pattern
                rec["pattern"] = pattern
            else:
                rec["pattern"] = pattern
            summary[key] = rec
            rows.append((key, "ok", a_stable, b_stable, p, rec.get("pattern"),
                         rec.get("A_top2_margin_nats"), rec.get("B_top2_margin_nats")))
    # between-launch stability of A and B
    for case in ("G", "T"):
        for arm in ("A", "B"):
            seqs = []
            for L in launches:
                x = load(f"{L}_{arm}", f"{case}1")
                if x and "error" not in x:
                    seqs.append(x["ids"])
            if len(seqs) >= 2:
                summary[f"between_launch/{case}/{arm}"] = {"identical": all(s == seqs[0] for s in seqs),
                                                            "first_div": first_div(seqs[0], seqs[1]) if len(seqs) > 1 else None}
    with open(os.path.join(E, "summary.json"), "w") as f:
        json.dump(summary, f, indent=1)
    print(f"{'launch/case':<12}{'status':<8}{'A5/5':<7}{'B5/5':<7}{'first_div':<10}{'pattern':<44}{'mA':>8}{'mB':>8}")
    for r in rows:
        k, st, a, b, p, pat, ma, mb = r
        fm = lambda m: "" if m is None or m == "" else f"{m:.3f}"
        print(f"{k:<12}{st:<8}{str(a):<7}{str(b):<7}{str(p):<10}{str(pat):<44}{fm(ma):>8}{fm(mb):>8}")
    for k, v in summary.items():
        if k.startswith("between_launch"):
            print(k, v)


if __name__ == "__main__":
    main()
