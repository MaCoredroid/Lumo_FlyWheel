# SPDX-License-Identifier: Apache-2.0
"""Standalone probe for the padded-row out-of-bounds idx_mapping read in
``MambaSpecDecodeGPUContext.compute_aligned_state_indices`` at vllm#55506 head.

Reproduces the call ``MambaHybridModelState.prepare_attn`` makes under
CUDAGraphMode.FULL:

    compute_aligned_state_indices(
        input_batch.seq_lens,           # length num_reqs_after_padding
        input_batch.num_reqs_after_padding,
        input_batch.idx_mapping,        # length num_reqs  <-- shorter
    )

modes:
  track   -- show the padded rows track a controllable value placed past the
             end of the mapping tensor (deterministic, stays inside one
             allocation so it is safe to run anywhere)
  memcheck-- give idx_mapping its own exact-size allocation so
             compute-sanitizer reports the read past its end.  Run as:
             PYTORCH_NO_CUDA_MEMORY_CACHING=1 compute-sanitizer --tool memcheck \
                 python probe_padded_oob.py memcheck
"""

import sys

import torch

from vllm.model_executor.layers.mamba.mamba_utils import (
    get_conv_copy_spec,
    get_temporal_copy_spec,
)
from vllm.v1.attention.backends.registry import MambaAttentionBackendEnum
from vllm.v1.kv_cache_interface import KVCacheConfig, KVCacheGroupSpec, MambaSpec
from vllm.v1.worker.mamba_utils import MambaSpecDecodeGPUContext

BLOCK = 16
NSPEC = 2
MAX_REQS = 8
MAX_BLOCKS = 12
NGROUPS = 1
COPY = {MambaAttentionBackendEnum.MAMBA2: (get_conv_copy_spec, get_temporal_copy_spec)}


class _Attn:
    def __init__(self, kv):
        self.kv_cache = kv


def build(device):
    spec = MambaSpec(
        block_size=BLOCK,
        shapes=((4, 8), (16,)),
        dtypes=(torch.float16, torch.float16),
        mamba_type=MambaAttentionBackendEnum.MAMBA2,
        mamba_cache_mode="align",
        num_speculative_blocks=NSPEC,
    )
    cfg = KVCacheConfig(
        num_blocks=64,
        kv_cache_tensors=[],
        kv_cache_groups=[
            KVCacheGroupSpec(layer_names=[f"layer_{g}"], kv_cache_spec=spec)
            for g in range(NGROUPS)
        ],
    )

    class _Buf:
        def __init__(self, n, dtype, device):
            self.cpu = torch.zeros(n, dtype=dtype)
            self.gpu = torch.zeros(n, dtype=dtype, device=device)
            self.np = self.cpu.numpy()

        def copy_to_gpu(self, n=None):
            return self.gpu.copy_(self.cpu)

    ctx = MambaSpecDecodeGPUContext.create(
        max_num_reqs=MAX_REQS,
        kv_cache_config=cfg,
        copy_funcs=COPY,
        device=device,
        make_buffer=lambda n, dtype: _Buf(n, dtype, device),
    )
    tables = []
    for g in range(NGROUPS):
        t = torch.empty((MAX_REQS, MAX_BLOCKS), dtype=torch.int32, device=device)
        for slot in range(MAX_REQS):
            for col in range(MAX_BLOCKS):
                t[slot, col] = 1 + g * 10_000 + slot * 100 + col
        tables.append(t)
    fwd = {
        f"layer_{g}": _Attn(
            [
                torch.zeros((64, 4, 8), dtype=torch.float16, device=device),
                torch.zeros((64, 16), dtype=torch.float16, device=device),
            ]
        )
        for g in range(NGROUPS)
    }
    ctx.initialize_from_forward_context(cfg, fwd, COPY, tables)
    # Keep the tables (and the state tensors) alive: the context stores raw
    # data_ptrs, so letting them be freed would hand the kernel dangling rows.
    ctx._keepalive = (tables, fwd)
    return ctx, tables


def main():
    mode = sys.argv[1] if len(sys.argv) > 1 else "track"
    device = torch.device("cuda")
    ctx, tables = build(device)

    num_reqs, num_reqs_padded = 3, 6
    real = [2, 0, 5]
    seq_lens = torch.zeros(MAX_REQS, dtype=torch.int32, device=device)
    seq_lens[:num_reqs] = torch.tensor([17, 33, 48], dtype=torch.int32)

    if mode == "memcheck":
        # Exact-size allocation, so the read past its end is a real OOB.
        idx_mapping = torch.tensor(real, dtype=torch.int64, device=device)
        print(f"idx_mapping numel={idx_mapping.numel()} "
              f"bytes={idx_mapping.numel() * 8} ptr={idx_mapping.data_ptr():#x}")
        ctx.aligned_state_indices.fill_(-7)
        out = ctx.compute_aligned_state_indices(
            seq_lens[:num_reqs_padded], num_reqs_padded, idx_mapping
        )
        torch.cuda.synchronize()
        print("padded rows:", out[:, num_reqs:num_reqs_padded, :].cpu().tolist())
        return

    for poison in (7, 3, 1):
        backing = torch.full(
            (num_reqs_padded,), poison, dtype=torch.int64, device=device
        )
        backing[:num_reqs] = torch.tensor(real, dtype=torch.int64)
        idx_mapping = backing[:num_reqs]
        ctx.aligned_state_indices.fill_(-7)
        out = ctx.compute_aligned_state_indices(
            seq_lens[:num_reqs_padded], num_reqs_padded, idx_mapping
        )
        torch.cuda.synchronize()
        real_rows = out[:, :num_reqs, :].cpu().tolist()
        pad_rows = out[:, num_reqs:num_reqs_padded, :].cpu().tolist()
        print(f"value past end of idx_mapping = {poison}")
        print(f"  real rows 0..{num_reqs - 1}  : {real_rows}")
        print(f"  padded rows {num_reqs}..{num_reqs_padded - 1}: {pad_rows}")
        expect = [1 + poison * 100 + c for c in range(1 + NSPEC)]
        print(f"  block ids of slot {poison} = {expect} -> "
              f"{'LEAKED' if pad_rows[0][0] == expect else 'not leaked'}")


if __name__ == "__main__":
    main()
