# Pre-run CARD — item I, execution coverage for vllm-project/vllm#55506

Written **before** any test was run. Date: 2026-09-23. Box: NVIDIA GB10 (sm_121, aarch64).

## 1. Unit under test

`MambaSpecDecodeGPUContext.compute_aligned_state_indices()` and the Triton kernel it
launches, `get_aligned_state_indices_multi_group_kernel`, at PR head
`a28e90223540e861af5ef6e3a2e1c7ea010d45b1`
(`vllm/v1/worker/mamba_utils.py:37-111` kernel, `:1117-1166` method), plus the
context-binding lifecycle `MambaSpecDecodeGPUContext.initialize_from_forward_context`
(`vllm/v1/worker/mamba_utils.py:946-997`) as it is driven from
`MambaHybridModelState._ensure_align_ctx` (`vllm/v1/worker/gpu/model_states/mamba_hybrid.py:141-181`).

This is the second commit of the PR (`a28e902`, "Resolve aligned state indices through the
request-slot mapping"), which the author states was verified **statically only** because he has
no KDA/Kimi hardware. It is the piece izhuhaoran asked about. The first commit (`c99ba59`,
precopy/postprocess kernels) already has execution coverage in the PR's own
`tests/kernels/mamba/test_precopy_mamba_align.py` and a PP repro by tomasruizt on H100 —
NOT re-done here.

## 2. The mapping under test

Before the PR the context was bound to the per-step **gathered** tables
(`BlockTables.input_block_tables`, batch-row ordered), and the kernel used the grid row
directly as the table row:

    state_indices = load(block_tables + rows * stride_req + first_state_slot + state_slots)

After the PR the context is bound to the **source per-request-slot** tables
(`BlockTables.block_tables[i].gpu`, row = request-state slot) and the row is resolved through
`idx_mapping` (batch_idx -> req_state_idx):

    table_row = idx_mapping[rows]                 # HAS_IDX_MAPPING=True
    active_row = (rows < num_requests) & (table_row >= 0)

`seq_lens` (input) and `aligned_state_indices` (output) stay in **batch** order.

## 3. What "pass" means

For every group g, batch row r < num_reqs and state slot s:

    expected[g, r, s] == source_table[g][ idx_mapping[r], first_state_slot(seq_lens[r]) + s ]
    first_state_slot(L) == max((L - 1) // mamba_block_size, 0)

compared **bytewise** (`torch.equal` on int32). Block ids are laid out so that every
(row, slot) pair is unique, i.e. reading any wrong table row is detectable in the output.

## 4. Cases

| # | case | expectation |
|---|---|---|
| C1 | identity mapping (`arange`) vs `idx_mapping=None` | identical — control that must pass on PR head AND on merge-base |
| C2 | permuted mapping, disjoint per-row block ids | matches the per-slot oracle — **negative control: must FAIL on merge-base** |
| C3 | `-1` sentinel row inside the batch | sentinel row must not read a negative table row; document what the kernel writes for it |
| C4 | eager vs CUDA-graph capture+replay of the same launch, inputs updated **in place**, mapping permuted between replays | bytewise identical to eager |
| C5 | CUDA-graph replay after the mapping tensor is **reallocated** (as the runner does every step) | documents that a captured launch bakes the pointer |
| C6 | `num_reqs = num_reqs_after_padding > len(idx_mapping)`, i.e. the FULL-cudagraph call the runner actually makes | probe: what does the kernel read for padded rows? |
| C7 | first-context initialization: `initialize_from_forward_context` called twice with different table sets | documents which binding survives (idempotent-by-design) |

## 5. What eager-vs-captured equality proves, and what it does NOT

**Proves.** The kernel's addressing is a pure function of its pointer arguments and of
`num_requests` (a non-constexpr runtime scalar, `do_not_specialize`): a graph captured once and
replayed against in-place-updated input buffers produces the same bytes as an eager launch with
the same buffer contents. So the kernel is replay-safe *given* stable buffers.

**Does NOT prove.**
1. That the production path is capture-safe. In the V2 runner this kernel is launched from
   `MambaHybridModelState.prepare_attn`, which runs **outside** the captured region (metadata
   prep, before the captured model forward). Equality under capture therefore says nothing about
   what actually happens in production for this kernel; it is a property test of the kernel, not
   of the runner.
2. That the pointers the context holds are the right ones. The graph and the eager launch read
   the SAME `block_table_ptrs`, so any mis-binding of the context is invisible to this
   comparison. Binding is covered separately by C7, which is a lifecycle test, not a numeric one.
3. Anything about the K3/KDA kernels downstream. The test stops at the produced index tensor.
4. Anything about PP, async scheduling, or the end-to-end corruption. tomasruizt already
   reproduced that on H100; this test is deliberately narrower.

## 6. Rules in force

GitHub read-only; nothing posted, nothing pushed. GPU only under
`flock /home/mark/shared/exp54928/gpu.lock`. No model loads. PR code is not modified: the
deliverable is a test. Every number in the report comes from an archived log under
`/home/mark/shared/tmp-scratch/I_55506/logs/`.

## 7. Environment

Python sources come from the PR-head worktree `/home/mark/shared/tmp-scratch/wt-55506` via
`PYTHONPATH`; the interpreter is `/home/mark/shared/vllm-head/.venv/bin/python`. The editable
install's finder is appended to `sys.meta_path`, so `PYTHONPATH` wins — verified by printing
`vllm.__file__`. The unit under test is pure Triton + PyTorch, so no vLLM C++/CUDA extension is
loaded; the venv's prebuilt `.so` set is recorded in `logs/00_provenance.log` for completeness
but is not on the path of this test.
