# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the vLLM project
"""Align-mode Mamba allocation across an exact state-page boundary when the
scheduler has asked for lookahead capacity.

Model-free: only `MambaManager` and `BlockPool` are exercised, so these run on
CPU. Written for vllm-project/vllm#57605.

Vocabulary used throughout, all taken from the production code:

* *page* = one Mamba state block, `MambaSpec.block_size` tokens wide.
* *main-model end* = `num_tokens_main_model` in
  `KVCacheManager.allocate_slots`: `total_computed_tokens + num_new_tokens`.
* *lookahead* = `num_lookahead_tokens`
  (`VllmConfig.num_lookahead_tokens`); `allocate_slots` passes
  `num_tokens = main_end + lookahead` and `num_tokens_main_model = main_end`.
* *running-state column* = the block-table column the worker writes the
  recurrent state into, `cdiv(main_end, block_size) - 1`
  (`vllm/v1/worker/mamba_utils.py`, `curr_state_idx = num_blocks - 1 -
  num_speculative_blocks` with `num_blocks = cdiv(main_end, block_size) +
  num_speculative_blocks`).
* *next page column* = `cdiv(main_end, block_size)`, the page the first
  lookahead token past a page-aligned main end falls into.
"""

from dataclasses import dataclass

import pytest
import torch

from vllm.utils.math_utils import cdiv
from vllm.v1.core.block_pool import BlockPool
from vllm.v1.core.single_type_kv_cache_manager import MambaManager
from vllm.v1.kv_cache_interface import MambaSpec

pytestmark = pytest.mark.cpu_test

BLOCK_SIZE = 64
HASH_BLOCK_SIZE = 16
CKPT_ALIGNMENT = 16
# Page column 3 is the running-state column for a main end of 256 tokens.
BOUNDARY = 4 * BLOCK_SIZE
# A representative non-zero lookahead (num_speculative_tokens for an MTP or
# Eagle drafter).
LOOKAHEAD = 2


def _make(num_speculative_blocks, internal_checkpoints, num_gpu_blocks=4096):
    spec = MambaSpec(
        block_size=BLOCK_SIZE,
        shapes=((1, 1),),
        dtypes=(torch.float32,),
        mamba_cache_mode="align",
        num_speculative_blocks=num_speculative_blocks,
        num_prefill_checkpoint_blocks=1 if internal_checkpoints else 0,
        prefill_checkpoint_alignment=CKPT_ALIGNMENT if internal_checkpoints else None,
    )
    pool = BlockPool(
        num_gpu_blocks=num_gpu_blocks,
        enable_caching=True,
        hash_block_size=HASH_BLOCK_SIZE,
    )
    manager = MambaManager(
        spec,
        block_pool=pool,
        enable_caching=True,
        kv_cache_group_id=0,
        scheduler_block_size=BLOCK_SIZE,
    )
    return manager, pool


@dataclass
class Step:
    """What one scheduler step asked for and what it got."""

    main_end: int
    estimated: int
    allocated: int
    table_len: int
    required: int
    running_state_col: int
    running_state_is_null: bool
    next_page_col: int
    next_page_is_real: bool


def _step(manager, pool, request_id, main_end, lookahead, computed):
    """One `allocate_slots` step, in `allocate_slots`' own order."""
    num_tokens = main_end + lookahead
    estimated = manager.get_num_blocks_to_allocate(
        request_id=request_id,
        num_tokens=num_tokens,
        new_computed_blocks=[],
        total_computed_tokens=computed,
        num_local_computed_tokens=computed,
        num_tokens_main_model=main_end,
    )
    free_before = pool.get_num_free_blocks()
    manager.allocate_new_blocks(request_id, num_tokens, main_end)
    allocated = free_before - pool.get_num_free_blocks()

    blocks = manager.req_to_blocks[request_id]
    running_state_col = cdiv(main_end, BLOCK_SIZE) - 1
    next_page_col = cdiv(main_end, BLOCK_SIZE)
    return Step(
        main_end=main_end,
        estimated=estimated,
        allocated=allocated,
        table_len=len(blocks),
        required=cdiv(main_end, BLOCK_SIZE) + manager.num_speculative_blocks,
        running_state_col=running_state_col,
        running_state_is_null=(
            running_state_col >= len(blocks) or blocks[running_state_col].is_null
        ),
        next_page_col=next_page_col,
        next_page_is_real=(
            next_page_col < len(blocks) and not blocks[next_page_col].is_null
        ),
    )


def _decode_ladder(manager, pool, request_id, first, last, lookahead):
    """Advance the main-model end one token per step, as decode does.

    `first` is deliberately not page-aligned so that the request already owns a
    block table before the boundary step under test.
    """
    assert first % BLOCK_SIZE != 0
    steps = []
    computed = 0
    for main_end in range(first, last + 1):
        steps.append(_step(manager, pool, request_id, main_end, lookahead, computed))
        computed = main_end
    return steps


@pytest.mark.parametrize("num_speculative_blocks", [0, 1, 2])
def test_align_lookahead_boundary_materializes_next_state_page(
    num_speculative_blocks,
):
    """Mechanism (a): the page the first lookahead token needs must exist.

    When the main-model end lands exactly on a page boundary and the scheduler
    has reserved lookahead past it, the first lookahead token's state write
    targets page column `cdiv(main_end, block_size)`. That column must hold a
    real block in the same schedule that carries the boundary token.

    With `num_speculative_blocks > 0` the speculative scratch blocks already
    cover that column, so only the `num_speculative_blocks == 0` case
    (`CacheConfig.use_kda_recoverssm`, which zeroes
    `MambaSpec.num_speculative_blocks` while `num_lookahead_tokens` stays at
    `num_speculative_tokens`) actually depends on the reservation.
    """
    manager, pool = _make(num_speculative_blocks, internal_checkpoints=False)
    steps = _decode_ladder(
        manager, pool, "r", BOUNDARY - 4, BOUNDARY + 2, LOOKAHEAD
    )
    boundary_steps = [s for s in steps if s.main_end == BOUNDARY]
    assert len(boundary_steps) == 1
    boundary = boundary_steps[0]
    assert boundary.next_page_is_real, (
        f"main end {boundary.main_end} is page-aligned and {LOOKAHEAD} "
        f"lookahead tokens were scheduled past it, but page column "
        f"{boundary.next_page_col} is not a real block "
        f"(table length {boundary.table_len})"
    )


@pytest.mark.parametrize("num_speculative_blocks", [0, 1, 2])
@pytest.mark.parametrize("internal_checkpoints", [False, True])
@pytest.mark.parametrize("lookahead", [0, LOOKAHEAD])
@pytest.mark.parametrize("offset", [-1, 0, 1])
def test_align_admission_estimate_pays_for_its_allocation(
    num_speculative_blocks, internal_checkpoints, lookahead, offset
):
    """`get_num_blocks_to_allocate` must cover `allocate_new_blocks`.

    `KVCacheManager.allocate_slots` admits a step only if the estimate fits in
    the free pool, then calls `allocate_new_blocks`, which pulls blocks from
    `BlockPool.get_new_blocks` -- and that raises `ValueError` if the pool is
    short. So the estimate has to be an upper bound on what is actually taken,
    and the block table must not grow past what the worker indexes
    (`cdiv(main_end, block_size) + num_speculative_blocks`).

    Driven the way the scheduler drives align mode: an intermediate prefill
    chunk (which `Scheduler._mamba_block_aligned_split` forces to end on a page
    boundary) followed by a chunk ending at the boundary under test.
    """
    request_id = "r"
    manager, pool = _make(num_speculative_blocks, internal_checkpoints)
    initial_free = pool.get_num_free_blocks()

    first_chunk = 2 * BLOCK_SIZE
    main_end = BOUNDARY + offset
    steps = [
        _step(manager, pool, request_id, first_chunk, lookahead, 0),
        _step(manager, pool, request_id, main_end, lookahead, first_chunk),
    ]

    for step in steps:
        assert step.estimated >= 0, (
            f"negative admission estimate {step.estimated} at main end "
            f"{step.main_end}"
        )
        assert step.estimated >= step.allocated, (
            f"admission estimated {step.estimated} block(s) at main end "
            f"{step.main_end} but the allocation took {step.allocated}"
        )
        # The worker indexes `required` columns; one extra column is allowed
        # for a reserved next page, more than that is over-allocation.
        assert step.required <= step.table_len <= step.required + 1, (
            f"block table is {step.table_len} long at main end "
            f"{step.main_end}, the worker indexes {step.required} and at "
            f"most one reserved page beyond that is expected"
        )
        assert not step.running_state_is_null, (
            f"running-state column {step.running_state_col} is a null block "
            f"at main end {step.main_end}"
        )

    manager.free(request_id)
    assert pool.get_num_free_blocks() == initial_free


@pytest.mark.parametrize("num_speculative_blocks", [0, 1, 2])
@pytest.mark.parametrize("lookahead", [0, LOOKAHEAD])
@pytest.mark.parametrize("offset", [-1, 0, 1])
def test_align_tight_pool_admission_is_honoured(
    num_speculative_blocks, lookahead, offset
):
    """The estimate must hold when the pool has exactly that much left.

    Same invariant as above, but the failure is the one a saturated server
    actually sees: the pool is squeezed to the number of blocks admission
    asked for, so any under-estimate surfaces as
    `ValueError: Cannot get N free blocks from the pool`.
    """
    request_id = "r"
    manager, pool = _make(num_speculative_blocks, internal_checkpoints=False)

    # Walk up to just short of the boundary with a generous pool.
    computed = 0
    for main_end in range(BOUNDARY - 4, BOUNDARY):
        _step(manager, pool, request_id, main_end, lookahead, computed)
        computed = main_end

    main_end = BOUNDARY + offset
    estimated = manager.get_num_blocks_to_allocate(
        request_id=request_id,
        num_tokens=main_end + lookahead,
        new_computed_blocks=[],
        total_computed_tokens=computed,
        num_local_computed_tokens=computed,
        num_tokens_main_model=main_end,
    )
    assert estimated >= 0
    # Grant exactly what admission asked for, as a saturated scheduler would.
    spare = pool.get_num_free_blocks() - estimated
    if spare > 0:
        pool.get_new_blocks(spare)
    manager.allocate_new_blocks(request_id, main_end + lookahead, main_end)


@pytest.mark.parametrize("num_speculative_blocks", [0, 1, 2])
@pytest.mark.parametrize("offset", [-1, 0, 1])
def test_align_zero_lookahead_keeps_the_original_padding_math(
    num_speculative_blocks, offset
):
    """Negative control: with no lookahead nothing about align mode changes.

    `num_tokens == num_tokens_main_model` is the no-lookahead case, and the
    block table it produces is fully determined by the align-mode invariant:
    `cdiv(main_end, bs) + num_speculative_blocks` columns, a real block at the
    running-state column and at every column above it. This must hold
    identically before and after any lookahead change, so it is expected to
    pass on every build.
    """
    request_id = "r"
    manager, pool = _make(num_speculative_blocks, internal_checkpoints=False)
    initial_free = pool.get_num_free_blocks()

    first_chunk = 2 * BLOCK_SIZE
    main_end = BOUNDARY + offset
    _step(manager, pool, request_id, first_chunk, 0, 0)
    step = _step(manager, pool, request_id, main_end, 0, first_chunk)

    assert step.estimated == step.allocated
    assert step.table_len == cdiv(main_end, BLOCK_SIZE) + num_speculative_blocks
    assert not step.running_state_is_null
    blocks = manager.req_to_blocks[request_id]
    # Every column at or above the running-state column is a real block.
    for col in range(step.running_state_col, len(blocks)):
        assert not blocks[col].is_null, f"column {col} is null"

    manager.free(request_id)
    assert pool.get_num_free_blocks() == initial_free


@pytest.mark.parametrize("num_speculative_blocks", [0, 1, 2])
@pytest.mark.parametrize("offset", [-1, 0, 1])
def test_align_internal_checkpoint_chunk_stays_within_its_bound(
    num_speculative_blocks, offset
):
    """An internal prefill checkpoint costs one extra real block, no lookahead.

    A chunk that exports an internal checkpoint keeps that column out of the
    null padding (`null_end = num_skipped_blocks - checkpoint_block`), so it
    needs one more new block than a chunk without one. The allocator's own
    bound has to allow for it, on a request that already owns blocks. Nothing
    here involves lookahead: `num_tokens == num_tokens_main_model` throughout.
    """
    request_id = "r"
    manager, pool = _make(num_speculative_blocks, internal_checkpoints=True)
    initial_free = pool.get_num_free_blocks()

    first_chunk = 2 * BLOCK_SIZE
    main_end = BOUNDARY + offset
    _step(manager, pool, request_id, first_chunk, 0, 0)
    assert request_id in manager._allocated_block_reqs
    step = _step(manager, pool, request_id, main_end, 0, first_chunk)
    assert request_id in manager._checkpoints, (
        "case does not exercise an internal checkpoint; tighten the fixture"
    )

    assert step.estimated == step.allocated
    assert step.table_len == step.required
    assert not step.running_state_is_null

    manager.free(request_id)
    assert pool.get_num_free_blocks() == initial_free


@pytest.mark.parametrize("num_speculative_blocks", [0, 1, 2])
@pytest.mark.parametrize("chunk_pages", [1, 2])
@pytest.mark.parametrize("lookahead", [0, LOOKAHEAD])
def test_align_lookahead_reserve_keeps_state_residency_bounded(
    num_speculative_blocks, chunk_pages, lookahead
):
    """Reserving a page must not raise steady-state state residency.

    `MambaSpec.max_memory_usage_bytes` budgets align mode at
    `2 + num_speculative_blocks + num_prefill_checkpoint_blocks` pages per
    request (the current and previous state plus the speculative scratch),
    and that budget is what sizes the KV pool at profiling time. Replaying a
    block-aligned chunked prefill -- the shape
    `Scheduler._mamba_block_aligned_split` produces -- must stay inside it.
    """
    request_id = "r"
    manager, pool = _make(num_speculative_blocks, internal_checkpoints=False)
    initial_free = pool.get_num_free_blocks()
    budget = 2 + num_speculative_blocks

    chunk = chunk_pages * BLOCK_SIZE
    peak = 0
    for i in range(1, 13):
        main_end = i * chunk
        computed = main_end - chunk
        manager.remove_skipped_blocks(request_id, computed)
        _step(manager, pool, request_id, main_end, lookahead, computed)
        peak = max(peak, initial_free - pool.get_num_free_blocks())
    assert peak <= budget, (
        f"held {peak} state pages at once, align-mode budget is {budget}"
    )

    manager.free(request_id)
    assert pool.get_num_free_blocks() == initial_free


def test_align_null_padding_must_not_land_on_the_running_state_column():
    """Mechanism (b), with its own sensitivity control.

    If the null padding of a step that reserved a page for lookahead is
    derived from the lookahead-inflated token count, the padding runs one
    column too far and buries the running-state column under a null block. The
    worker then chains the next chunk's state pre-copy from the null slot.

    The control neutralises `MambaManager._align_num_skipped_blocks` (the
    clamp that keeps the padding on the main-model length) and asserts the
    column really does go null without it, so a pass above cannot be vacuous.
    On a build that has no such clamp because it never inflates the token
    count, the control is skipped.
    """
    request_id = "r"
    manager, pool = _make(1, internal_checkpoints=False)
    computed = 0
    for main_end in range(BOUNDARY - 4, BOUNDARY + 1):
        step = _step(manager, pool, request_id, main_end, LOOKAHEAD, computed)
        computed = main_end
        assert not step.running_state_is_null, (
            f"running-state column {step.running_state_col} is null at main "
            f"end {step.main_end}"
        )

    if not hasattr(manager, "_align_num_skipped_blocks"):
        pytest.skip(
            "build does not inflate num_tokens for lookahead, so there is no "
            "padding clamp to neutralise"
        )

    # The padding only runs when the table is still shorter than the padding
    # target, i.e. on a chunk that ends on the boundary without having stepped
    # up to it -- which is what an intermediate align-mode prefill chunk does.
    control, control_pool = _make(1, internal_checkpoints=False)
    control._align_num_skipped_blocks = (
        lambda num_skipped_blocks, num_tokens, num_tokens_main_model: (
            num_skipped_blocks
        )
    )
    control_step = _step(control, control_pool, request_id, BOUNDARY, LOOKAHEAD, 0)
    assert control_step.running_state_is_null, (
        "control did not reproduce mechanism (b): with the padding clamp "
        "neutralised the running-state column stayed a real block, so the "
        "assertion above proves nothing"
    )
