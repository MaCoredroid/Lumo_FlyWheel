# Pre-run card — Item M / vllm-project/vllm#57605

Written before any run. Date 2026-09-26.

## What is under test

`MambaManager` in `vllm/v1/core/single_type_kv_cache_manager.py`, align cache mode
(`mamba_cache_mode="align"`), two methods only:

- `get_num_blocks_to_allocate(...)` — the *admission estimate* the scheduler compares
  against the free-block pool before it commits to a step.
- `allocate_new_blocks(...)` — the *actual* allocation that pulls blocks out of
  `BlockPool`.

The unit of observation is the manager's own bookkeeping: the returned estimate, the
number of blocks actually removed from the pool, the contents of
`manager.req_to_blocks[request_id]` (null vs real block at each page column), and
whether an internal assertion or `BlockPool.get_new_blocks` `ValueError` is raised.

No model, no GPU, no kernels. `torch` is imported only because `MambaSpec` carries
dtypes.

## Refs

- head = PR #57605 head `ef97fad96ac4bcab3321933f1855755a61d38d09`
- merge-base = `63d9ad0a3a435cdf3a44495028b10f390a38f960` (`git merge-base pr-57605 origin/main`)

## Mechanisms the PR claims (from the PR body)

(a) **Missing next page.** Main-model sequence ends exactly on a page boundary and the
scheduler asked for lookahead past it; the next state page is not materialized in the
same schedule, so the boundary token's state write lands on a block-table entry holding
a recycled block.

(b) **Displaced running-state column.** Null padding derived from the lookahead-inflated
`num_tokens` puts a null block at page column `cdiv(main_end, bs) - 1`, which is exactly
the column the worker uses for the running state
(`vllm/v1/worker/mamba_utils.py`, `curr_state_idx = num_blocks - 1 - num_speculative_blocks`).

## Predictions / pass-fail meaning

For each case (main-model end at boundary−1 / boundary / boundary+1 tokens,
lookahead ∈ {0, k}, checkpoints on/off, tight and generous pools):

1. **Estimate ≥ actual.** If `get_num_blocks_to_allocate` returns fewer blocks than
   `allocate_new_blocks` then takes, the scheduler admits a step it cannot pay for; with
   a pool sized to the estimate, `allocate_new_blocks` raises
   `ValueError: Cannot get N free blocks from the pool`. FAIL = mismatch or ValueError.
2. **Running-state column is a real block.** `req_to_blocks[rid][cdiv(main_end,bs)-1]`
   must exist and must not be the null block. FAIL = null or index out of range.
   This is the direct manager-level surrogate for mechanism (b).
3. **Next page materialized.** When the main end is exactly on a boundary and lookahead
   > 0, `len(req_to_blocks[rid]) > cdiv(main_end, bs)` — i.e. page column
   `cdiv(main_end, bs)` exists. FAIL = it does not. This is the manager-level surrogate
   for mechanism (a).
4. **No over-allocation / no leak.** `len(req_to_blocks[rid])` must equal the manager's
   own `num_required_blocks` and the pool must return to its initial free count after
   `free()`. FAIL = table longer than required, or blocks not returned.
5. **No internal assertion fires** in either method.

A case that FAILS at merge-base and PASSES at head is a discriminating case. A case that
passes at both is a negative control. A case that FAILS at head is a defect in the PR
and is reported as such, not suppressed.

## What this evidence will NOT show

- Nothing about the GPU state write, the state pre-copy, NaNs, repetition lock, or
  spec-decode acceptance. Those are worker/kernel behaviours; only the *block-table
  shape* the worker would see is observed here.
- Nothing about the author's 4-node Thor / GLM-5.3-Flash numbers — not reproduced, no
  such hardware here, no GPU used at all.
- Nothing about whether the real scheduler ever presents a given
  (`num_tokens`, `num_tokens_main_model`, checkpoint) combination in production: the
  manager is driven directly. Reachability of each case from `Scheduler` is argued from
  code reading (`vllm/v1/core/kv_cache_manager.py`, `vllm/v1/core/sched/scheduler.py`,
  `vllm/config/vllm.py:num_lookahead_tokens`), not demonstrated end to end.
- No merge verdict, no statement about whether the fix is the right design.
