"""Exploratory probe 4: steady-state state-page residency for a block-aligned
chunked prefill with lookahead (the align-mode prefill pattern)."""

import torch

from vllm.v1.core.block_pool import BlockPool
from vllm.v1.core.single_type_kv_cache_manager import MambaManager
from vllm.v1.kv_cache_interface import MambaSpec

BS = 64
HBS = 16


def run(nsb, chunk_pages, lookahead, nsteps=12):
    spec = MambaSpec(
        block_size=BS,
        shapes=((1, 1),),
        dtypes=(torch.float32,),
        mamba_cache_mode="align",
        num_speculative_blocks=nsb,
    )
    pool = BlockPool(num_gpu_blocks=4096, enable_caching=True, hash_block_size=HBS)
    mgr = MambaManager(
        spec,
        block_pool=pool,
        enable_caching=True,
        kv_cache_group_id=0,
        scheduler_block_size=BS,
    )
    rid = "r"
    initial = pool.get_num_free_blocks()
    chunk = chunk_pages * BS
    peak = 0
    try:
        for i in range(1, nsteps + 1):
            target = i * chunk
            computed = target - chunk
            mgr.remove_skipped_blocks(rid, computed)
            mgr.get_num_blocks_to_allocate(
                rid, target + lookahead, [], computed, computed, target
            )
            mgr.allocate_new_blocks(rid, target + lookahead, target)
            peak = max(peak, initial - pool.get_num_free_blocks())
    except BaseException as e:  # noqa: BLE001
        print(
            f"nsb={nsb} chunk_pages={chunk_pages} la={lookahead}: "
            f"{type(e).__name__}({e})"
        )
        return
    budget = 2 + nsb
    print(
        f"nsb={nsb} chunk_pages={chunk_pages} la={lookahead}: peak={peak} "
        f"budget(2+nsb)={budget} {'OK' if peak <= budget else 'OVER'}"
    )


if __name__ == "__main__":
    for nsb in (0, 1, 5):
        for chunk_pages in (1, 2, 3):
            for la in (0, 2):
                run(nsb, chunk_pages, la)
