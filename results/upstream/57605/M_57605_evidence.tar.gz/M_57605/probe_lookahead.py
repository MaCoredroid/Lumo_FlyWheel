"""Exploratory probe (not the offered test): tabulate MambaManager align-mode
allocation for boundary-1 / boundary / boundary+1 x lookahead in {0, k}.

Run with PYTHONPATH pointing at the ref under test:
  PYTHONPATH=<worktree> <venv>/bin/python probe_lookahead.py
"""

import itertools
import linecache
import sys
import traceback

import torch

from vllm.utils.math_utils import cdiv
from vllm.v1.core.block_pool import BlockPool
from vllm.v1.core.single_type_kv_cache_manager import MambaManager
from vllm.v1.kv_cache_interface import MambaSpec

BS = 64       # mamba (state) block size == page size in tokens
HBS = 16      # prefix-cache hash block size
ALIGN = 16    # prefill_checkpoint_alignment


def make(nsb, ckpt, pool_blocks):
    spec = MambaSpec(
        block_size=BS,
        shapes=((1, 1),),
        dtypes=(torch.float32,),
        mamba_cache_mode="align",
        num_speculative_blocks=nsb,
        num_prefill_checkpoint_blocks=1 if ckpt else 0,
        prefill_checkpoint_alignment=ALIGN if ckpt else None,
    )
    pool = BlockPool(
        num_gpu_blocks=pool_blocks, enable_caching=True, hash_block_size=HBS
    )
    mgr = MambaManager(
        spec,
        block_pool=pool,
        enable_caching=True,
        kv_cache_group_id=0,
        scheduler_block_size=BS,
    )
    return mgr, pool


def step(mgr, pool, rid, main_end, lookahead, computed):
    """One scheduler step, mirroring KVCacheManager.allocate_slots ordering."""
    num_tokens = main_end + lookahead
    out = {"main_end": main_end, "num_tokens": num_tokens}
    out["est"] = mgr.get_num_blocks_to_allocate(
        request_id=rid,
        num_tokens=num_tokens,
        new_computed_blocks=[],
        total_computed_tokens=computed,
        num_local_computed_tokens=computed,
        num_tokens_main_model=main_end,
    )
    out["ckpt"] = rid in mgr._checkpoints
    free_before = pool.get_num_free_blocks()
    mgr.allocate_new_blocks(rid, num_tokens, main_end)
    out["act"] = free_before - pool.get_num_free_blocks()
    blocks = mgr.req_to_blocks[rid]
    out["len"] = len(blocks)
    out["nulls"] = sum(1 for b in blocks if b.is_null)
    rs = cdiv(main_end, BS) - 1
    out["rs_idx"] = rs
    out["rs_ok"] = 0 <= rs < len(blocks) and not blocks[rs].is_null
    out["next_page"] = cdiv(main_end, BS) < len(blocks)
    out["required"] = cdiv(main_end, BS) + mgr.num_speculative_blocks
    return out


def where():
    """file:line of the innermost frame in single_type_kv_cache_manager."""
    tb = sys.exc_info()[2]
    last = None
    while tb is not None:
        fn = tb.tb_frame.f_code.co_filename
        if "single_type_kv_cache_manager" in fn or "block_pool" in fn:
            last = (fn.rsplit("/", 1)[-1], tb.tb_lineno)
        tb = tb.tb_next
    if last is None:
        return "?"
    src = ""
    for f in traceback.extract_tb(sys.exc_info()[2]):
        if f.lineno == last[1]:
            src = (linecache.getline(f.filename, f.lineno) or "").strip()
    return f"{last[0]}:{last[1]} {src[:60]}"


def run_case(nsb, ckpt, lookahead, offset, two_step, pool_blocks):
    rid = "r"
    mgr, pool = make(nsb, ckpt, pool_blocks)
    boundary = 4 * BS
    main_end = boundary + offset
    rows, err = [], None
    try:
        if two_step:
            first = 2 * BS
            rows.append(("s1", step(mgr, pool, rid, first, lookahead, 0)))
            rows.append(("s2", step(mgr, pool, rid, main_end, lookahead, first)))
        else:
            rows.append(("s1", step(mgr, pool, rid, main_end, lookahead, 0)))
    except BaseException as e:  # noqa: BLE001
        err = f"{type(e).__name__}({e}) @ {where()}"
    return rows, err


def main():
    print(f"block_size={BS} hash_block_size={HBS} ckpt_alignment={ALIGN}")
    print(f"boundary main_end = {4 * BS} tokens -> running-state page column 3")
    print("est=get_num_blocks_to_allocate, act=blocks actually taken from pool,")
    print("len=len(req_to_blocks), req=cdiv(main_end,bs)+nsb, rsOK=running-state")
    print("column is a real (non-null) block, npg=page cdiv(main_end,bs) exists")
    print()
    hdr = (
        f"{'nsb':>3} {'ck':>2} {'la':>3} {'off':>4} {'2st':>3} | "
        f"{'st':>2} {'est':>4} {'act':>4} {'len':>4} {'req':>4} {'nul':>4} "
        f"{'rs':>3} {'rsOK':>5} {'npg':>5} {'ck?':>5} | note"
    )
    print(hdr)
    print("-" * len(hdr))
    for nsb, ckpt, lookahead, offset, two_step in itertools.product(
        [0, 1, 2], [False, True], [0, 2], [-1, 0, 1], [False, True]
    ):
        rows, err = run_case(nsb, ckpt, lookahead, offset, two_step, 4096)
        pre = f"{nsb:>3} {int(ckpt):>2} {lookahead:>3} {offset:>4} {int(two_step):>3}"
        for name, o in rows:
            note = []
            if o["est"] < o["act"]:
                note.append("UNDER-ESTIMATE")
            if o["len"] > o["required"]:
                note.append(f"OVER-ALLOC(+{o['len'] - o['required']})")
            if not o["rs_ok"]:
                note.append("RUNNING-STATE-NULL")
            print(
                f"{pre} | {name:>2} {o['est']:>4} {o['act']:>4} {o['len']:>4} "
                f"{o['required']:>4} {o['nulls']:>4} {o['rs_idx']:>3} "
                f"{str(o['rs_ok']):>5} {str(o['next_page']):>5} "
                f"{str(o['ckpt']):>5} | {' '.join(note)}"
            )
        if err:
            print(f"{pre} | !! RAISED {err}")
    print()
    print("=== leak check: pool free count restored after free() ===")
    for nsb, ckpt, lookahead, offset in itertools.product(
        [0, 1], [False, True], [0, 2], [-1, 0, 1]
    ):
        mgr, pool = make(nsb, ckpt, 4096)
        initial = pool.get_num_free_blocks()
        try:
            step(mgr, pool, "r", 2 * BS, lookahead, 0)
            step(mgr, pool, "r", 4 * BS + offset, lookahead, 2 * BS)
            mgr.free("r")
            print(
                f"nsb={nsb} ck={int(ckpt)} la={lookahead} off={offset:>2} "
                f"free {initial} -> {pool.get_num_free_blocks()} "
                f"{'OK' if pool.get_num_free_blocks() == initial else 'LEAK'}"
            )
        except BaseException as e:  # noqa: BLE001
            print(
                f"nsb={nsb} ck={int(ckpt)} la={lookahead} off={offset:>2} "
                f"raised {type(e).__name__}({e}) @ {where()}"
            )


if __name__ == "__main__":
    main()
