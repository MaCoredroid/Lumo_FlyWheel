"""Exploratory probe 2: walk a single request's main-model end across an exact
page boundary one token at a time (the decode/spec-decode pattern) and record
what the block table holds at the running-state column and at the next page
column.

Run with PYTHONPATH pointing at the ref under test.
"""

import sys
import traceback

import torch

from vllm.utils.math_utils import cdiv
from vllm.v1.core.block_pool import BlockPool
from vllm.v1.core.single_type_kv_cache_manager import MambaManager
from vllm.v1.kv_cache_interface import MambaSpec

BS = 64
HBS = 16


def make(nsb, pool_blocks=4096):
    spec = MambaSpec(
        block_size=BS,
        shapes=((1, 1),),
        dtypes=(torch.float32,),
        mamba_cache_mode="align",
        num_speculative_blocks=nsb,
    )
    pool = BlockPool(
        num_gpu_blocks=pool_blocks, enable_caching=True, hash_block_size=HBS
    )
    return (
        MambaManager(
            spec,
            block_pool=pool,
            enable_caching=True,
            kv_cache_group_id=0,
            scheduler_block_size=BS,
        ),
        pool,
    )


def ident(pool, b):
    return "NULL" if b.is_null else f"b{b.block_id}"


def ladder(nsb, lookahead, start, stop):
    mgr, pool = make(nsb)
    rid = "r"
    print(f"--- nsb={nsb} lookahead={lookahead} block_size={BS}")
    print(
        f"{'main_end':>8} {'ntok':>6} {'est':>4} {'act':>4} {'len':>4} {'req':>4} "
        f"{'rs':>3} {'rs_blk':>7} {'npg':>3} {'npg_blk':>8} | note"
    )
    prev = 0
    for main_end in range(start, stop + 1):
        num_tokens = main_end + lookahead
        try:
            est = mgr.get_num_blocks_to_allocate(
                request_id=rid,
                num_tokens=num_tokens,
                new_computed_blocks=[],
                total_computed_tokens=prev,
                num_local_computed_tokens=prev,
                num_tokens_main_model=main_end,
            )
            free_before = pool.get_num_free_blocks()
            mgr.allocate_new_blocks(rid, num_tokens, main_end)
            act = free_before - pool.get_num_free_blocks()
        except BaseException as e:  # noqa: BLE001
            tb = traceback.extract_tb(sys.exc_info()[2])[-1]
            print(
                f"{main_end:>8} {num_tokens:>6} !! {type(e).__name__}({e}) "
                f"@ {tb.filename.rsplit('/', 1)[-1]}:{tb.lineno}"
            )
            return
        blocks = mgr.req_to_blocks[rid]
        rs = cdiv(main_end, BS) - 1
        npg = cdiv(main_end, BS)
        req = cdiv(main_end, BS) + nsb
        note = []
        if est < act:
            note.append("UNDER-ESTIMATE")
        if len(blocks) > req:
            note.append(f"OVER-ALLOC(+{len(blocks) - req})")
        if not (0 <= rs < len(blocks)) or blocks[rs].is_null:
            note.append("RUNNING-STATE-NULL")
        if lookahead > 0 and main_end % BS == 0:
            if npg >= len(blocks) or blocks[npg].is_null:
                note.append("NEXT-PAGE-MISSING")
        print(
            f"{main_end:>8} {num_tokens:>6} {est:>4} {act:>4} {len(blocks):>4} "
            f"{req:>4} {rs:>3} {ident(pool, blocks[rs]):>7} {npg:>3} "
            f"{(ident(pool, blocks[npg]) if npg < len(blocks) else 'ABSENT'):>8} "
            f"| {' '.join(note)}"
        )
        prev = main_end


if __name__ == "__main__":
    # A decode ladder that crosses the 256-token page boundary.
    for nsb in (0, 1, 2):
        for la in (0, 2):
            ladder(nsb, la, 252, 260)
            print()
