"""Exploratory probe 3.

(1) Tight pool: size the pool to exactly what get_num_blocks_to_allocate asked
    for and show whether allocate_new_blocks can be paid for.
(2) Mechanism (b) sensitivity: neutralise MambaManager._align_num_skipped_blocks
    (head only) and show whether the running-state column becomes a null block.
"""

import torch

from vllm.utils.math_utils import cdiv
from vllm.v1.core.block_pool import BlockPool
from vllm.v1.core.single_type_kv_cache_manager import MambaManager
from vllm.v1.kv_cache_interface import MambaSpec

BS = 64
HBS = 16


def make(nsb, pool_blocks):
    spec = MambaSpec(
        block_size=BS,
        shapes=((1, 1),),
        dtypes=(torch.float32,),
        mamba_cache_mode="align",
        num_speculative_blocks=nsb,
    )
    pool = BlockPool(
        num_gpu_blocks=pool_blocks, enable_caching=True, hash_block_size=HBS
    )
    return (
        MambaManager(
            spec,
            block_pool=pool,
            enable_caching=True,
            kv_cache_group_id=0,
            scheduler_block_size=BS,
        ),
        pool,
    )


def tight_pool(nsb, lookahead):
    """Grant exactly the estimate, as a saturated scheduler would."""
    rid = "r"
    # Pool big enough to reach the boundary, then squeezed to the estimate.
    mgr, pool = make(nsb, 4096)
    prev = 0
    for main_end in (252, 253, 254, 255):
        mgr.get_num_blocks_to_allocate(
            request_id=rid,
            num_tokens=main_end + lookahead,
            new_computed_blocks=[],
            total_computed_tokens=prev,
            num_local_computed_tokens=prev,
            num_tokens_main_model=main_end,
        )
        mgr.allocate_new_blocks(rid, main_end + lookahead, main_end)
        prev = main_end
    main_end = 256
    est = mgr.get_num_blocks_to_allocate(
        request_id=rid,
        num_tokens=main_end + lookahead,
        new_computed_blocks=[],
        total_computed_tokens=prev,
        num_local_computed_tokens=prev,
        num_tokens_main_model=main_end,
    )
    # Saturate the pool down to exactly `est` free blocks, as the scheduler
    # would when it admits this step on the strength of that estimate.
    spare = pool.get_num_free_blocks() - max(est, 0)
    if spare > 0:
        pool.get_new_blocks(spare)
    try:
        mgr.allocate_new_blocks(rid, main_end + lookahead, main_end)
        print(
            f"nsb={nsb} la={lookahead}: est={est} free_granted={max(est, 0)} -> OK"
        )
    except BaseException as e:  # noqa: BLE001
        print(
            f"nsb={nsb} la={lookahead}: est={est} free_granted={max(est, 0)} -> "
            f"{type(e).__name__}: {e}"
        )


def guard_off(nsb, lookahead, patch):
    """Run the boundary step with _align_num_skipped_blocks neutralised."""
    rid = "r"
    mgr, pool = make(nsb, 4096)
    if patch and hasattr(mgr, "_align_num_skipped_blocks"):
        mgr._align_num_skipped_blocks = (
            lambda num_skipped_blocks, num_tokens, num_tokens_main_model: (
                num_skipped_blocks
            )
        )
    main_end = 256
    try:
        mgr.get_num_blocks_to_allocate(
            request_id=rid,
            num_tokens=main_end + lookahead,
            new_computed_blocks=[],
            total_computed_tokens=0,
            num_local_computed_tokens=0,
            num_tokens_main_model=main_end,
        )
        mgr.allocate_new_blocks(rid, main_end + lookahead, main_end)
        blocks = mgr.req_to_blocks[rid]
        rs = cdiv(main_end, BS) - 1
        print(
            f"nsb={nsb} la={lookahead} guard={'OFF' if patch else 'ON '}: "
            f"len={len(blocks)} rs_col={rs} "
            f"rs_is_null={blocks[rs].is_null} "
            f"table={['NULL' if b.is_null else b.block_id for b in blocks]}"
        )
    except BaseException as e:  # noqa: BLE001
        print(
            f"nsb={nsb} la={lookahead} guard={'OFF' if patch else 'ON '}: "
            f"{type(e).__name__}({e})"
        )


if __name__ == "__main__":
    print("=== (1) tight pool sized to the admission estimate ===")
    for nsb in (0, 1, 2):
        for la in (0, 2):
            tight_pool(nsb, la)
    print()
    print("=== (2) _align_num_skipped_blocks guard on/off, fresh request ===")
    print("(fresh boundary-aligned chunk; head trips its own assert here)")
    for nsb in (0, 1, 2):
        for patch in (False, True):
            guard_off(nsb, 2, patch)
