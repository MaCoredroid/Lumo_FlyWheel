"""CPU probe: does the real worker write the terminal state INTO the shared
block-aligned prefix-cache hit block, or into a freshly allocated block?

Drives the real ``vllm.v1.worker.mamba_utils.preprocess_mamba`` (the MRV1 align
pre-copy planner) with ``collect_mamba_copy_meta`` / ``do_mamba_copy_block``
stubbed out, so the src/dst state block columns come from the shipped arithmetic
(mamba_utils.py:1481 prev_state_idx, :1498 curr_state_idx, :1503 the copy gate)
rather than from a transcription.

dst_col is the column the kernels write in place; src_col is the column they
read the initial state from. src_col == dst_col  =>  the hit block is mutated
in place (CoW needed). src_col != dst_col  =>  the state is migrated out before
the forward and the hit block is read-only (no CoW needed).
"""

from types import SimpleNamespace

import numpy as np
import torch

from vllm.config.cache import CacheConfig
from vllm.v1.kv_cache_interface import KVCacheConfig, KVCacheGroupSpec, MambaSpec
from vllm.v1.worker import mamba_utils

BLOCK = 4
NUM_SPEC = 0

recorded = []


def _fake_collect(copy_bufs, kv_cache_config, copy_funcs, group_ids,
                  prev_state_idx, curr_state_idx, accept_token_bias,
                  req_state, forward_context):
    recorded.append((prev_state_idx, curr_state_idx, accept_token_bias))


mamba_utils.collect_mamba_copy_meta = _fake_collect
mamba_utils.do_mamba_copy_block = lambda copy_bufs: None

spec = MambaSpec(
    block_size=BLOCK,
    shapes=((1, 1),),
    dtypes=(torch.float32,),
    mamba_cache_mode="align",
    num_speculative_blocks=NUM_SPEC,
)
kv_cache_config = KVCacheConfig(
    num_blocks=32,
    kv_cache_tensors=[],
    kv_cache_groups=[KVCacheGroupSpec(["mamba_layer"], spec)],
)
cache_config = CacheConfig(block_size=BLOCK, enable_prefix_caching=True)


def run(label, num_computed, num_scheduled, seeded_state_idx=None):
    recorded.clear()
    req_id = "r"
    scheduler_output = SimpleNamespace(
        num_scheduled_tokens={req_id: num_scheduled},
        finished_req_ids=[],
        preempted_req_ids=set(),
        scheduled_cached_reqs=SimpleNamespace(resumed_req_ids=set()),
    )
    mamba_state_idx = {} if seeded_state_idx is None else {req_id: seeded_state_idx}
    input_batch = SimpleNamespace(
        req_ids=[req_id],
        num_accepted_tokens_cpu=np.ones(1, dtype=np.int32),
        block_table=None,
    )
    requests = {req_id: SimpleNamespace(num_computed_tokens=num_computed)}
    copy_bufs = SimpleNamespace(
        offset=0,
        mamba_group_ids=[0],
        mamba_spec=spec,
    )
    mamba_utils.preprocess_mamba(
        scheduler_output,
        kv_cache_config,
        cache_config,
        mamba_state_idx,
        input_batch,
        requests,
        forward_context={},
        mamba_state_copy_funcs={},
        copy_bufs=copy_bufs,
        align_ctx=None,
    )
    dst = mamba_state_idx[req_id]
    if recorded:
        src, dst2, bias = recorded[0]
        assert dst2 == dst
        verdict = f"src_col={src} -> dst_col={dst}: state MIGRATED before forward"
    else:
        verdict = f"src_col==dst_col=={dst}: state written IN PLACE (CoW needed)"
    print(f"{label:<62} {verdict}")


print(f"mamba block_size={BLOCK}, num_speculative_blocks={NUM_SPEC}\n")
print("-- resumed request, FULL block-aligned prefix-cache hit (PR premise) --")
for q in (1, 2, 4):
    run(f"hit=4 tokens (1 full block), {q} new token(s)", 4, q)
run("hit=8 tokens (2 full blocks), 4 new tokens", 8, 4)
print()
print("-- resumed request, SUB-BLOCK partial hit (existing CoW path, control) --")
for hit, q in ((2, 1), (2, 2), (3, 1), (6, 1), (6, 2)):
    run(f"hit={hit} tokens (partial block), {q} new token(s)", hit, q)
print()
print("-- running producer, step after publishing an aligned boundary --")
run("was writing col 0, 4 tokens computed, 1 new token", 4, 1, seeded_state_idx=0)
run("was writing col 0, 4 tokens computed, 4 new tokens", 4, 4, seeded_state_idx=0)
run("was writing col 1, 8 tokens computed, 1 new token", 8, 1, seeded_state_idx=1)
print()
print("-- running producer, mid-block step (no boundary crossed, control) --")
run("was writing col 1, 5 tokens computed, 1 new token", 5, 1, seeded_state_idx=1)
run("was writing col 1, 6 tokens computed, 2 new tokens", 6, 2, seeded_state_idx=1)
