"""CPU probe: align-mode producer boundary publishing, at merge-base vs PR head.

Mirrors tests/v1/core/test_prefix_caching.py::
test_mamba_boundary_handoffs_do_not_pin_obsolete_blocks, but prints the state
instead of asserting, so the two refs can be compared line by line.
"""

import os
import sys
from math import lcm

import torch
from vllm.utils.hashing import sha256
from vllm.v1.core.kv_cache_manager import KVCacheManager
from vllm.v1.kv_cache_interface import KVCacheConfig, KVCacheGroupSpec, MambaSpec

sys.path.insert(0, "tests")
from v1.core.test_prefix_caching import make_request  # noqa: E402
from vllm.v1.core.kv_cache_utils import init_none_hash  # noqa: E402

init_none_hash(sha256)

BS = 16


def build():
    cfg = KVCacheConfig(
        num_blocks=16,
        kv_cache_tensors=[],
        kv_cache_groups=[
            KVCacheGroupSpec(
                ["mamba"],
                MambaSpec(
                    block_size=BS,
                    shapes=((1,),),
                    dtypes=(torch.float32,),
                    mamba_cache_mode="align",
                ),
            )
        ],
    )
    return KVCacheManager(
        cfg,
        max_model_len=128,
        enable_caching=True,
        hash_block_size=BS,
        scheduler_block_size=lcm(BS),
    )


DRAIN = os.environ.get("DRAIN") == "1"


def main():
    print(f"### drain CoW retentions = {DRAIN}")
    manager = build()
    mgr = manager.coordinator.single_type_managers[0]
    request = make_request("request", list(range(64)), BS, sha256)
    old_blocks = []
    for end in (16, 32, 48):
        new = manager.allocate_slots(request, 16)
        assert new is not None
        request.num_computed_tokens = end
        copies, retained = manager.take_kv_cache_block_copies()
        if DRAIN and retained:
            # mirrors Scheduler._free_cow_retained_blocks with
            # defer_block_free off (sched/scheduler.py:2699)
            manager.block_pool.free_blocks(retained)
        offers = manager.take_boundary_state_offloads()
        print(f"--- after step ending at {end} tokens")
        print(f"    req_to_blocks       = "
              f"{[(b.block_id, b.block_hash is not None, b.ref_cnt) for b in mgr.req_to_blocks['request']]}")
        print(f"    free blocks         = {manager.block_pool.get_num_free_blocks()}")
        print(f"    pending block copies= {copies}")
        print(f"    boundary offers     = {offers.get('request')}")
        [(_, block_id, boundary)] = offers["request"]
        old_blocks.append(manager.block_pool.blocks[block_id])
        manager.remove_skipped_blocks("request", end, 64)
        manager.new_step_starts()
        print(f"    after remove_skipped: req_to_blocks = "
              f"{[(b.block_id, b.block_hash is not None, b.ref_cnt) for b in mgr.req_to_blocks['request']]}")
    print("=== obsolete boundary blocks (all but the last offer):")
    for b in old_blocks[:-1]:
        print(f"    block {b.block_id}: ref_cnt={b.ref_cnt} hash_set={b.block_hash is not None}")
    print(f"=== final free blocks = {manager.block_pool.get_num_free_blocks()} / 16")


main()
