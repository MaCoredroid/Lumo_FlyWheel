# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the vLLM project
"""Discriminating check for vllm-project/vllm#57908 (align-mode CoW for full
block-aligned Mamba prefix-cache snapshots).

#57908's premise is that a full block-aligned hit "remains shared while the
resumed request writes into it", and that a running producer "overwrites the
block when they continue" past a published boundary.

W-cases drive the shipped align pre-copy planner
(``vllm.v1.worker.mamba_utils.preprocess_mamba``, the MRV1 path; the V2 kernel
``preprocess_mamba_align_fused_kernel`` computes the same columns) and record
which state-block column the kernels read (``src_col``) and which they write
(``dst_col``). ``src_col == dst_col`` is the in-place case that needs CoW.

M-cases drive the real ``MambaManager`` and pin the block/copy budget.

Expected: W1-W3 pass on both refs (they describe the worker, which #57908 does
not touch); M1, M2 and M4 pass at the merge base and fail at #57908's head;
M3 is the negative control for the pre-existing sub-block CoW path.
"""

import numpy as np
import pytest
import torch

from vllm.config.cache import CacheConfig
from vllm.v1.core.block_pool import BlockPool
from vllm.v1.core.kv_cache_utils import (
    BlockHash,
    init_none_hash,
    make_block_hash_with_group_id,
)
from vllm.v1.core.single_type_kv_cache_manager import MambaManager
from vllm.v1.kv_cache_interface import KVCacheConfig, KVCacheGroupSpec, MambaSpec
from vllm.v1.worker import mamba_utils

pytestmark = pytest.mark.cpu_test

BLOCK = 4


# --------------------------------------------------------------------------
# W-cases: which state-block column does the worker write?
# --------------------------------------------------------------------------
def _plan_precopy(
    monkeypatch, num_computed: int, num_scheduled: int, seeded_state_idx=None
) -> tuple[int | None, int]:
    """Return (src_col, dst_col) as the shipped planner computes them.

    src_col is None when no migration is planned, i.e. the kernels read and
    write the same block column and the state is mutated in place.
    """
    from types import SimpleNamespace

    recorded: list[tuple[int, int]] = []
    monkeypatch.setattr(
        mamba_utils,
        "collect_mamba_copy_meta",
        lambda copy_bufs, kv_cache_config, copy_funcs, group_ids, prev, curr, bias, req_state, fwd: recorded.append(  # noqa: E501
            (prev, curr)
        ),
    )
    monkeypatch.setattr(mamba_utils, "do_mamba_copy_block", lambda copy_bufs: None)

    spec = MambaSpec(
        block_size=BLOCK,
        shapes=((1, 1),),
        dtypes=(torch.float32,),
        mamba_cache_mode="align",
    )
    kv_cache_config = KVCacheConfig(
        num_blocks=32,
        kv_cache_tensors=[],
        kv_cache_groups=[KVCacheGroupSpec(["mamba_layer"], spec)],
    )
    req_id = "r"
    mamba_state_idx = {} if seeded_state_idx is None else {req_id: seeded_state_idx}
    mamba_utils.preprocess_mamba(
        SimpleNamespace(
            num_scheduled_tokens={req_id: num_scheduled},
            finished_req_ids=[],
            preempted_req_ids=set(),
            scheduled_cached_reqs=SimpleNamespace(resumed_req_ids=set()),
        ),
        kv_cache_config,
        CacheConfig(block_size=BLOCK, enable_prefix_caching=True),
        mamba_state_idx,
        SimpleNamespace(
            req_ids=[req_id],
            num_accepted_tokens_cpu=np.ones(1, dtype=np.int32),
            block_table=None,
        ),
        {req_id: SimpleNamespace(num_computed_tokens=num_computed)},
        forward_context={},
        mamba_state_copy_funcs={},
        copy_bufs=SimpleNamespace(offset=0, mamba_group_ids=[0], mamba_spec=spec),
        align_ctx=None,
    )
    dst = mamba_state_idx[req_id]
    if recorded:
        assert recorded[0][1] == dst
        return recorded[0][0], dst
    return None, dst


@pytest.mark.parametrize("num_local_computed,num_scheduled", [(2, 1), (2, 2), (3, 1)])
def test_w1_subblock_hit_is_written_in_place(
    monkeypatch, num_local_computed, num_scheduled
):
    """NEGATIVE CONTROL: a sub-block hit really is mutated in place, which is
    what the pre-existing partial-hit CoW covers."""
    src, dst = _plan_precopy(monkeypatch, num_local_computed, num_scheduled)
    assert src is None, f"expected in-place write, got migration {src}->{dst}"


@pytest.mark.parametrize("num_scheduled", [1, 2, BLOCK])
def test_w2_full_aligned_hit_is_migrated_before_forward(monkeypatch, num_scheduled):
    """#57908's consumer premise: is the shared aligned hit block written?"""
    src, dst = _plan_precopy(monkeypatch, BLOCK, num_scheduled)
    assert src is not None and src != dst, (
        "aligned hit block is written in place; CoW would be needed"
    )
    assert src == 0 and dst == 1


@pytest.mark.parametrize("num_scheduled", [1, BLOCK])
def test_w3_producer_past_boundary_is_migrated(monkeypatch, num_scheduled):
    """#57908's producer premise: is the just-published boundary block written
    again on the next step?"""
    src, dst = _plan_precopy(
        monkeypatch, BLOCK, num_scheduled, seeded_state_idx=0
    )
    assert src is not None and src != dst, (
        "published boundary block is written again; CoW would be needed"
    )


# --------------------------------------------------------------------------
# M-cases: the manager's block and copy budget
# --------------------------------------------------------------------------
def _make_manager(num_gpu_blocks: int = 16) -> tuple[MambaManager, BlockPool]:
    init_none_hash(__import__("vllm.utils.hashing", fromlist=["sha256"]).sha256)
    spec = MambaSpec(
        block_size=BLOCK,
        shapes=((1, 1),),
        dtypes=(torch.float32,),
        mamba_cache_mode="align",
    )
    pool = BlockPool(
        num_gpu_blocks=num_gpu_blocks, enable_caching=True, hash_block_size=BLOCK
    )
    manager = MambaManager(
        spec,
        block_pool=pool,
        enable_caching=True,
        kv_cache_group_id=0,
        scheduler_block_size=BLOCK,
    )
    return manager, pool


def _publish_block(pool: BlockPool, name: bytes, num_tokens: int):
    """A cache-resident, currently unreferenced block hashed at num_tokens."""
    block = pool.get_new_blocks(1)[0]
    raw = BlockHash(name)
    block.set_block_hash(make_block_hash_with_group_id(raw, 0), num_tokens=num_tokens)
    pool.cached_block_hash_to_block.insert(block.block_hash, block)
    pool.free_blocks([block])
    return block, raw


def test_m1_full_aligned_hit_reserves_no_extra_block():
    manager, pool = _make_manager()
    source, _ = _publish_block(pool, b"aligned", BLOCK)
    assert (
        manager.get_num_blocks_to_allocate(
            "consumer",
            num_tokens=2 * BLOCK,
            new_computed_blocks=[source],
            total_computed_tokens=BLOCK,
            num_local_computed_tokens=BLOCK,
            num_tokens_main_model=2 * BLOCK,
        )
        == 2
    ), "an extra block is reserved for a snapshot the worker never overwrites"


def test_m2_full_aligned_hit_queues_no_block_copy():
    manager, pool = _make_manager()
    source, raw = _publish_block(pool, b"aligned", BLOCK)
    manager.get_num_blocks_to_allocate(
        "consumer",
        num_tokens=2 * BLOCK,
        new_computed_blocks=[source],
        total_computed_tokens=BLOCK,
        num_local_computed_tokens=BLOCK,
        num_tokens_main_model=2 * BLOCK,
    )
    manager.add_local_computed_blocks(
        "consumer", [source], num_local_computed_tokens=BLOCK,
        num_external_computed_tokens=0,
    )
    manager.allocate_new_blocks(
        "consumer", num_tokens=2 * BLOCK, num_tokens_main_model=2 * BLOCK
    )
    assert manager.take_pending_cow_copies() == [], (
        "a device copy is queued for a snapshot the worker never overwrites"
    )
    assert manager.req_to_blocks["consumer"][0] is source
    assert pool.get_cached_block(raw, [0]) == [source]


def test_m3_subblock_hit_still_gets_one_cow_block_and_copy():
    """NEGATIVE CONTROL: the pre-existing sub-block CoW path is unchanged."""
    manager, pool = _make_manager()
    source, raw = _publish_block(pool, b"partial", BLOCK - 1)
    assert (
        manager.get_num_blocks_to_allocate(
            "consumer",
            num_tokens=2 * BLOCK,
            new_computed_blocks=[source],
            total_computed_tokens=BLOCK - 1,
            num_local_computed_tokens=BLOCK - 1,
            num_tokens_main_model=2 * BLOCK,
        )
        == 3
    )
    manager.add_local_computed_blocks(
        "consumer", [source], num_local_computed_tokens=BLOCK - 1,
        num_external_computed_tokens=0,
    )
    manager.allocate_new_blocks(
        "consumer", num_tokens=2 * BLOCK, num_tokens_main_model=2 * BLOCK
    )
    private = manager.req_to_blocks["consumer"][0]
    assert private is not source
    assert manager.take_pending_cow_copies() == [(source, private)]
    assert pool.get_cached_block(raw, [0]) == [source]


def test_m4_published_boundary_stays_on_the_producers_own_block():
    """The prefix-cache entry for a published boundary must stay on the block
    the request owns: retirement protection and connector hand-off both key on
    ``req_to_blocks[i].block_hash``."""
    from tests.v1.core.utils import create_requests

    manager, pool = _make_manager()
    request = create_requests(
        num_requests=1, num_tokens=BLOCK, block_size=BLOCK, req_ids=["producer"]
    )[0]
    manager.allocate_new_blocks(
        request.request_id, num_tokens=BLOCK, num_tokens_main_model=BLOCK
    )
    boundary = manager.req_to_blocks[request.request_id][0]
    manager.cache_blocks(request, BLOCK, replay_boundaries=(BLOCK,))
    assert boundary.block_hash is not None
    manager.get_num_blocks_to_allocate(
        request.request_id,
        num_tokens=2 * BLOCK,
        new_computed_blocks=(),
        total_computed_tokens=BLOCK,
        num_local_computed_tokens=BLOCK,
        num_tokens_main_model=2 * BLOCK,
    )
    manager.allocate_new_blocks(
        request.request_id, num_tokens=2 * BLOCK, num_tokens_main_model=2 * BLOCK
    )
    assert manager.req_to_blocks[request.request_id][0] is boundary
    assert boundary.block_hash is not None, (
        "the published hash moved off the producer's own block"
    )
    assert manager.take_pending_cow_copies() == []
