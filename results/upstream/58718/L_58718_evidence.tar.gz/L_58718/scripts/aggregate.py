# SPDX-License-Identifier: Apache-2.0
"""Aggregate timing.jsonl into the tables the report needs."""
import json
import statistics
import sys

MODELS = {
    "Qwen3-1.7B": [(4096, 2048), (2048, 2048), (12288, 2048), (2048, 6144),
                   (151936, 2048)],
    "Qwen3-4B": [(6144, 2560), (2560, 4096), (19456, 2560), (2560, 9728),
                 (151936, 2560)],
    "Qwen3-8B": [(6144, 4096), (4096, 4096), (24576, 4096), (4096, 12288),
                 (151936, 4096)],
}
SHAPE2MODEL = {s: m for m, ss in MODELS.items() for s in ss}
MS = [1, 32, 256, 512, 1024, 2048]

recs = [json.loads(l) for l in open(sys.argv[1])]
by = {}
for r in recs:
    by[(r["layout"], (r["N"], r["K"]), r["M"])] = r

for layout in ["wt", "contig"]:
    rs = [r for r in recs if r["layout"] == layout]
    if not rs:
        continue
    print("=" * 78)
    print(f"LAYOUT {layout}   ({'production: b = weight.t()' if layout=='wt' else 'control: b contiguous [K,N] - NOT the CUDA production layout'})")
    print("=" * 78)

    print("\n-- all 15 shapes, tuned/default p50 ratio (both A/B orders) --")
    print(f"{'M':>6} {'mean_TD':>8} {'mean_DT':>8} {'median':>8} {'min':>8} "
          f"{'max':>8} {'n>1.03':>7} {'n<0.97':>7}")
    for M in MS:
        rr = [by[(layout, s, M)] for s in SHAPE2MODEL if (layout, s, M) in by]
        if not rr:
            continue
        td = [r["ratio_TD"] for r in rr]
        dt = [r["ratio_DT"] for r in rr]
        both = td + dt
        print(f"{M:>6} {statistics.fmean(td):>8.3f} {statistics.fmean(dt):>8.3f} "
              f"{statistics.median(both):>8.3f} {min(both):>8.3f} {max(both):>8.3f} "
              f"{sum(1 for x in td if x > 1.03):>7} "
              f"{sum(1 for x in td if x < 0.97):>7}")

    print("\n-- per model, mean tuned/default over that model's 5 shapes (order TD) --")
    hdr = "".join(f"{('M=' + str(M)):>9}" for M in MS)
    print(f"{'model':>12}{hdr}")
    for m, shapes in MODELS.items():
        row = ""
        for M in MS:
            vals = [by[(layout, s, M)]["ratio_TD"] for s in shapes
                    if (layout, s, M) in by]
            row += f"{statistics.fmean(vals):>9.3f}" if vals else f"{'-':>9}"
        print(f"{m:>12}{row}")

    print("\n-- per shape (order TD / order DT) --")
    print(f"{'(N,K)':>15} {'model':>11}" + "".join(f"{('M='+str(M)):>15}" for M in MS))
    for m, shapes in MODELS.items():
        for s in shapes:
            row = ""
            for M in MS:
                r = by.get((layout, s, M))
                row += (f"{r['ratio_TD']:>7.3f}/{r['ratio_DT']:<7.3f}"
                        if r else f"{'-':>15}")
            print(f"{str(s):>15} {m:>11}" + row)

    dis = [r for r in rs
           if (r["ratio_TD"] - 1.0) * (r["ratio_DT"] - 1.0) < 0
           and max(abs(r["ratio_TD"] - 1), abs(r["ratio_DT"] - 1)) > 0.03]
    print(f"\n-- cells where the two A/B orders disagree in direction by >3%: "
          f"{len(dis)} --")
    for r in dis:
        print(f"   N={r['N']} K={r['K']} M={r['M']} TD={r['ratio_TD']:.3f} "
              f"DT={r['ratio_DT']:.3f}")

    bad = [r for r in rs if r["gate_vs_fp32"] and not all(
        g["allclose_1e-1"] for g in r["gate_vs_fp32"].values())]
    print(f"-- cells failing allclose(rtol=atol=1e-1) vs fp32 torch.mm: {len(bad)} --")
    mx = max((r["tuned_vs_default"]["max_abs_diff"] for r in rs), default=0)
    eq = sum(1 for r in rs if r["tuned_vs_default"]["bitwise_equal"])
    print(f"-- tuned vs default: bitwise equal in {eq}/{len(rs)} cells; "
          f"max abs diff {mx:.4g} (different tiles => different accumulation, "
          f"expected) --")
    ident = sum(1 for r in rs if r["cfg_identical"])
    print(f"-- cells where the tuned tile IS the default tile: {ident}/{len(rs)} --")

    print("\n-- peak achieved TFLOP/s (order TD) --")
    for tag in ("tflops_tuned_TD", "tflops_default_TD"):
        best = max(rs, key=lambda r: r[tag])
        print(f"   {tag:>22}: {best[tag]:7.1f} at N={best['N']} K={best['K']} "
              f"M={best['M']}")
    print()
