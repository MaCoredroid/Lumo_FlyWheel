# SPDX-License-Identifier: Apache-2.0
"""On-card check of _get_tuned_matmul_arch_family and the resolved table."""
from vllm.model_executor.determinism import batch_invariant_configs as C
from vllm.platforms import current_platform
from vllm.platforms.interface import DeviceCapability

print("real device capability:", current_platform.get_device_capability())
print("is_device_capability_family(80):",
      current_platform.is_device_capability_family(80))

for maj, minr in [(12, 0), (12, 1), (12, 2), (10, 0), (9, 0), (8, 9), (8, 0)]:
    fam = C._get_tuned_matmul_arch_family(DeviceCapability(maj, minr))
    print(f"cc ({maj}, {minr}) -> {fam!r}")
print("cc None ->", C._get_tuned_matmul_arch_family(None))

C.resolve_tuned_matmul_configs()
tbl = C._TUNED_MATMUL_CONFIGS_FOR_DEVICE
print("resolved table is sm121 dict:",
      tbl is C._BATCH_INVARIANT_MATMUL_TUNED_CONFIGS["sm121"])
print("resolved table entries:", len(tbl) if tbl is not None else None)
