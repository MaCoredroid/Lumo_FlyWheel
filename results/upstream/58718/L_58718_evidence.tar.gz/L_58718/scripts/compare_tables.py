# SPDX-License-Identifier: Apache-2.0
"""sm121 (this PR) vs sm120 (what a GB10 gets today), both measured here.

Each run measured its own `default` baseline in the same harness, so the
head-to-head is formed as (sm121/default) / (sm120/default), which cancels any
drift between the two runs. The direct ratio of the two tuned p50 times is shown
alongside as a cross-check.
"""
import json
import statistics
import sys

MODELS = {
    "Qwen3-1.7B": [(4096, 2048), (2048, 2048), (12288, 2048), (2048, 6144),
                   (151936, 2048)],
    "Qwen3-4B": [(6144, 2560), (2560, 4096), (19456, 2560), (2560, 9728),
                 (151936, 2560)],
    "Qwen3-8B": [(6144, 4096), (4096, 4096), (24576, 4096), (4096, 12288),
                 (151936, 4096)],
}
SHAPES = [s for ss in MODELS.values() for s in ss]
MS = [1, 32, 256, 512, 1024, 2048]


def load(path):
    d = {}
    for line in open(path):
        r = json.loads(line)
        if r["layout"] != "wt":
            continue
        d[((r["N"], r["K"]), r["M"])] = r
    return d


new = load(sys.argv[1])   # sm121
old = load(sys.argv[2])   # sm120

print("tuned/default p50, means over all 15 shapes (layout wt, order TD)\n")
print(f"{'M':>6} {'sm121':>8} {'sm120':>8} {'default':>8}   "
      f"{'sm121/sm120':>12}  interpretation")
for M in MS:
    r121 = [new[(s, M)]["ratio_TD"] for s in SHAPES]
    r120 = [old[(s, M)]["ratio_TD"] for s in SHAPES]
    m121, m120 = statistics.fmean(r121), statistics.fmean(r120)
    hh = statistics.fmean(a / b for a, b in zip(r121, r120))
    if hh < 0.97:
        interp = f"sm121 faster than sm120 by {(1 - hh) * 100:.0f}%"
    elif hh > 1.03:
        interp = f"sm121 SLOWER than sm120 by {(hh - 1) * 100:.0f}%"
    else:
        interp = "no difference"
    print(f"{M:>6} {m121:>8.3f} {m120:>8.3f} {1.0:>8.3f}   {hh:>12.3f}  {interp}")

print("\nper model, sm121/sm120 (mean over that model's 5 shapes)")
print(f"{'model':>12}" + "".join(f"{('M=' + str(M)):>9}" for M in MS))
for m, shapes in MODELS.items():
    row = ""
    for M in MS:
        vals = [new[(s, M)]["ratio_TD"] / old[(s, M)]["ratio_TD"] for s in shapes]
        row += f"{statistics.fmean(vals):>9.3f}"
    print(f"{m:>12}{row}")

print("\nper shape, sm121/sm120")
print(f"{'(N,K)':>15}" + "".join(f"{('M=' + str(M)):>9}" for M in MS))
for m, shapes in MODELS.items():
    for s in shapes:
        row = "".join(
            f"{new[(s, M)]['ratio_TD'] / old[(s, M)]['ratio_TD']:>9.3f}"
            for M in MS
        )
        print(f"{str(s):>15}{row}")

print("\ncross-check: direct ratio of the two runs' tuned p50 times "
      "(separate runs, so drift is not cancelled)")
print(f"{'M':>6} {'mean sm121_ms/sm120_ms':>24}")
for M in MS:
    v = [new[(s, M)]["t"]["TD_tuned"]["p50_ms"]
         / old[(s, M)]["t"]["TD_tuned"]["p50_ms"] for s in SHAPES]
    print(f"{M:>6} {statistics.fmean(v):>24.3f}")

print("\nsanity: the two runs' `default` baselines should agree")
print(f"{'M':>6} {'mean default_new/default_old':>30}")
for M in MS:
    v = [new[(s, M)]["t"]["TD_default"]["p50_ms"]
         / old[(s, M)]["t"]["TD_default"]["p50_ms"] for s in SHAPES]
    print(f"{M:>6} {statistics.fmean(v):>30.4f}")
