# SPDX-License-Identifier: Apache-2.0
"""Item L: which tile does the sm121 table actually dispatch under torch.compile?

Model-free.  Compiles the same call vLLM's unquantized linear layer makes under
VLLM_BATCH_INVARIANT (`linear_batch_invariant(x, weight)`, linear.py:238) and
records, for each M:
  - the config `_get_matmul_config` returned, and whether M was a SymInt at the
    time (i.e. whether the tile was chosen at trace time or at run time),
  - how many Dynamo graphs were compiled,
  - whether the compiled output is bitwise equal to eager,
  - whether row 0 stays bitwise identical across M on the compiled path,
  - the same two checks under a captured CUDA graph.
"""
import hashlib
import json

import torch

from vllm.model_executor.determinism import batch_invariant_configs as C
import vllm.model_executor.determinism.batch_invariant as B
from vllm.model_executor.determinism.batch_invariant import linear_batch_invariant

N, K = 4096, 4096
MS = [1, 8, 32, 512, 2048]
_real = C._get_matmul_config
CALLS = []


def recorder(M, n, k, dtype, default):
    cfg = _real(M, n, k, dtype, default)
    CALLS.append({
        "M_repr": repr(M),
        "M_type": type(M).__name__,
        "M_is_symbolic": not isinstance(M, int),
        "N": int(n) if isinstance(n, int) else repr(n),
        "K": int(k) if isinstance(k, int) else repr(k),
        "cfg": dict(cfg),
    })
    return cfg


C._get_matmul_config = recorder
B._get_matmul_config = recorder
C._TUNED_MATMUL_CONFIGS_RESOLVED = True
C._TUNED_MATMUL_CONFIGS_FOR_DEVICE = C._BATCH_INVARIANT_MATMUL_TUNED_CONFIGS["sm121"]


def h(t):
    return hashlib.sha256(
        t.contiguous().view(torch.uint8).cpu().numpy().tobytes()
    ).hexdigest()[:32]


dev = torch.device("cuda")
torch.manual_seed(1234)
w = torch.rand((N, K), dtype=torch.bfloat16, device=dev)
a_full = torch.rand((max(MS), K), dtype=torch.bfloat16, device=dev)

res = {"N": N, "K": K, "per_M": [], "cudagraph": [], "notes": []}


def eager(x):
    return linear_batch_invariant(x, w)


print(f"### compiled-path dispatch probe, N={N} K={K} "
      f"(tuned BLOCK_K={C._TUNED_MATMUL_CONFIGS_FOR_DEVICE[(N, K)].block_k}) ###\n")

torch._dynamo.reset()
compiled = torch.compile(eager)

n_graphs_prev = 0
for M in MS:
    x = a_full[:M]
    CALLS.clear()
    out_c = compiled(x)
    torch.cuda.synchronize()
    calls_compiled = list(CALLS)

    CALLS.clear()
    out_e = eager(x)
    torch.cuda.synchronize()
    calls_eager = list(CALLS)

    ng = torch._dynamo.utils.counters["stats"].get("unique_graphs", 0)
    rec = {
        "M": M,
        "compiled_calls": calls_compiled,
        "eager_cfg": calls_eager[-1]["cfg"] if calls_eager else None,
        "compiled_cfg": calls_compiled[-1]["cfg"] if calls_compiled else None,
        "cfg_matches_eager": bool(
            calls_compiled and calls_eager
            and calls_compiled[-1]["cfg"] == calls_eager[-1]["cfg"]
        ),
        "chosen_with_symbolic_M": bool(
            calls_compiled and calls_compiled[-1]["M_is_symbolic"]
        ),
        "n_config_lookups_this_call": len(calls_compiled),
        "unique_graphs_total": ng,
        "new_graphs_this_M": ng - n_graphs_prev,
        "bitwise_equal_to_eager": bool(torch.equal(out_c, out_e)),
        "row0_hash_compiled": h(out_c[0]),
        "row0_hash_eager": h(out_e[0]),
    }
    n_graphs_prev = ng
    res["per_M"].append(rec)
    print(f"M={M:>5}  lookups={rec['n_config_lookups_this_call']} "
          f"symbolicM={rec['chosen_with_symbolic_M']!s:>5} "
          f"newgraphs={rec['new_graphs_this_M']}  "
          f"compiled_tile={rec['compiled_cfg']}")
    print(f"        eager_tile={rec['eager_cfg']}")
    print(f"        tile==eager: {rec['cfg_matches_eager']}   "
          f"bitwise==eager: {rec['bitwise_equal_to_eager']}   "
          f"row0 {rec['row0_hash_compiled'][:16]}")

hs = {r["M"]: r["row0_hash_compiled"] for r in res["per_M"]}
res["row0_invariant_on_compiled_path"] = len(set(hs.values())) == 1
print(f"\nrow 0 identical across M on the compiled path: "
      f"{res['row0_invariant_on_compiled_path']}")
res["row0_invariant_eager"] = len(
    {r["row0_hash_eager"] for r in res["per_M"]}
) == 1
print(f"row 0 identical across M eager:                 "
      f"{res['row0_invariant_eager']}")

# ---- CUDA graph capture at a small and a large M ----
print("\n### CUDA-graph replay ###")
for M in (1, 2048):
    x_static = a_full[:M].clone()
    CALLS.clear()
    s = torch.cuda.Stream()
    s.wait_stream(torch.cuda.current_stream())
    with torch.cuda.stream(s):
        for _ in range(3):
            eager(x_static)
    torch.cuda.current_stream().wait_stream(s)
    torch.cuda.synchronize()
    g = torch.cuda.CUDAGraph()
    with torch.cuda.graph(g):
        y = eager(x_static)
    cfg = CALLS[-1]["cfg"]
    x_static.copy_(a_full[:M])
    g.replay()
    torch.cuda.synchronize()
    ref = eager(a_full[:M])
    ok = bool(torch.equal(y, ref))
    res["cudagraph"].append({
        "M": M, "captured_cfg": cfg, "bitwise_equal_to_eager": ok,
        "row0_hash": h(y[0]),
    })
    print(f"M={M:>5}  captured_tile={cfg}")
    print(f"        replay bitwise == eager: {ok}   row0 {h(y[0])[:16]}")
    del g, y, x_static
    torch.cuda.synchronize()

res["cudagraph_row0_invariant"] = len(
    {c["row0_hash"] for c in res["cudagraph"]}
) == 1
print(f"\nrow 0 identical between the two captured graphs: "
      f"{res['cudagraph_row0_invariant']}")

with open("/home/mark/shared/tmp-scratch/L_58718/data/compile_probe.json", "w") as f:
    json.dump(res, f, indent=1, sort_keys=True, default=str)
print("\nwrote data/compile_probe.json")
