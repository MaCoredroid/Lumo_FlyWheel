# SPDX-License-Identifier: Apache-2.0
"""Item L: bitwise M-invariance hashes + BLOCK_K sensitivity of the output bits.

E1  For each of the 15 sm121 keys, at M in {1, 2048}, compare the bf16 output of
    the tuned tile against the default tile, and against tiles that differ ONLY in
    BLOCK_SIZE_K, and against tiles that differ in everything EXCEPT BLOCK_SIZE_K.
    Two input distributions: randn/sqrt(K) and torch.rand (what the PR's own tests
    use).  This asks whether BLOCK_SIZE_K is what actually moves the output bits.

E2  The brief's gate: sha256 of the bytes of output row 0 computed at M=1 vs at
    M in {8, 32, 2048}, same a[0], same b, tuned table active, all 15 keys.

E3  Negative control: force a config that DOES change the reduction, and show the
    E2 hash comparison fails, so the gate is not vacuous.
"""
import argparse
import hashlib
import json

import torch

from vllm.model_executor.determinism import batch_invariant_configs as C
from vllm.model_executor.determinism.batch_invariant import matmul_persistent

BF16_DEFAULT = {
    "BLOCK_SIZE_M": 128, "BLOCK_SIZE_N": 128, "BLOCK_SIZE_K": 64,
    "GROUP_SIZE_M": 8, "num_stages": 3, "num_warps": 8,
}
SM121 = C._BATCH_INVARIANT_MATMUL_TUNED_CONFIGS["sm121"]
KEYS = sorted(SM121.keys())
_real_get = C._get_matmul_config


class ForceConfig:
    """Force matmul_persistent to use one explicit config, or the real table."""

    def __init__(self, cfg=None, per_m=None):
        self.cfg, self.per_m, self.seen = cfg, per_m, []

    def __enter__(self):
        def patched(M, N, K, dtype, default):
            if self.per_m is not None:
                out = dict(self.per_m(M, N, K))
            elif self.cfg is not None:
                out = dict(self.cfg)
            else:
                out = _real_get(M, N, K, dtype, default)
            self.seen.append((M, N, K, dict(out)))
            return out

        C._get_matmul_config = patched
        import vllm.model_executor.determinism.batch_invariant as B
        B._get_matmul_config = patched
        return self

    def __exit__(self, *a):
        C._get_matmul_config = _real_get
        import vllm.model_executor.determinism.batch_invariant as B
        B._get_matmul_config = _real_get


def tuned_cfg(N, K, M):
    C._TUNED_MATMUL_CONFIGS_RESOLVED = True
    C._TUNED_MATMUL_CONFIGS_FOR_DEVICE = SM121
    return _real_get(M, N, K, torch.bfloat16, dict(BF16_DEFAULT))


def row_hash(t):
    return hashlib.sha256(
        t.contiguous().view(torch.uint8).cpu().numpy().tobytes()
    ).hexdigest()


def diffstats(x, y):
    d = x.view(torch.int16) != y.view(torch.int16)
    n = int(d.sum().item())
    return {
        "n_diff_elems": n,
        "n_elems": x.numel(),
        "frac_diff": n / x.numel(),
        "max_abs_diff": float((x.float() - y.float()).abs().max().item()),
        "bitwise_equal": n == 0,
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", required=True)
    args = ap.parse_args()
    dev = torch.device("cuda")
    res = {"E1": [], "E2": [], "E3": []}

    # ---------------- E1: what moves the output bits ----------------
    print("### E1  does BLOCK_SIZE_K move the bf16 output bits? ###")
    print(f"{'(N,K)':>15} {'M':>5} {'dist':>6} {'bk_t':>5} "
          f"{'tuned_vs_default':>18} {'bk_only':>18} {'notbk_only':>18}")
    for (N, K) in KEYS:
        for dist in ("randn", "rand"):
            torch.manual_seed(1234)
            if dist == "randn":
                w = torch.randn((N, K), dtype=torch.bfloat16, device=dev) / (K ** 0.5)
                a_full = torch.randn((2048, K), dtype=torch.bfloat16, device=dev)
            else:
                w = torch.rand((N, K), dtype=torch.bfloat16, device=dev)
                a_full = torch.rand((2048, K), dtype=torch.bfloat16, device=dev)
            b = w.t()
            for M in (1, 2048):
                a = a_full[:M]
                ct = tuned_cfg(N, K, M)
                # same as tuned but BLOCK_SIZE_K forced to the default 64
                c_bk = dict(ct)
                c_bk["BLOCK_SIZE_K"] = 64
                # the default tile but with the tuned BLOCK_SIZE_K
                c_nbk = dict(BF16_DEFAULT)
                c_nbk["BLOCK_SIZE_K"] = ct["BLOCK_SIZE_K"]
                outs = {}
                for tag, cfg in (("tuned", ct), ("default", BF16_DEFAULT),
                                 ("bk_only", c_bk), ("notbk_only", c_nbk)):
                    try:
                        with ForceConfig(cfg=cfg):
                            outs[tag] = matmul_persistent(a, b)
                    except Exception as e:  # e.g. Triton OutOfResources on GB10
                        outs[tag] = None
                        print(f"    [{tag}] unavailable: "
                              f"{type(e).__name__}: {str(e)[:90]}", flush=True)
                def ds(x, y):
                    if outs[x] is None or outs[y] is None:
                        return {"unavailable": True}
                    return diffstats(outs[x], outs[y])

                r = {
                    "N": N, "K": K, "M": M, "dist": dist,
                    "cfg_tuned": ct,
                    "block_k_tuned": ct["BLOCK_SIZE_K"],
                    # tuned vs default: differs in tile AND (usually) BLOCK_K
                    "tuned_vs_default": ds("tuned", "default"),
                    # same tile, BLOCK_K 128 -> 64 : isolates BLOCK_K
                    "bk_only": ds("tuned", "bk_only"),
                    # default tile with tuned BLOCK_K vs default tile:
                    # also isolates BLOCK_K, from the other side
                    "notbk_only_vs_default": ds("notbk_only", "default"),
                    # tuned vs (default tile + tuned BLOCK_K): everything but BLOCK_K
                    "tile_only": ds("tuned", "notbk_only"),
                }
                res["E1"].append(r)
                def fmt(d):
                    if d.get("unavailable"):
                        return f"{'n/a':>18}"
                    return f"{d['n_diff_elems']:>10}/{d['n_elems']:<7}"

                print(f"{str((N,K)):>15} {M:>5} {dist:>6} {ct['BLOCK_SIZE_K']:>5} "
                      f"{fmt(r['tuned_vs_default'])} {fmt(r['bk_only'])} "
                      f"{fmt(r['tile_only'])}", flush=True)
                del outs
            del w, b, a_full
            torch.cuda.empty_cache()

    # ---------------- E2: the brief's M-invariance hash gate ----------------
    print("\n### E2  sha256 of output row 0, M=1 vs M in {8,32,2048}, "
          "tuned table ###")
    C._TUNED_MATMUL_CONFIGS_RESOLVED = True
    C._TUNED_MATMUL_CONFIGS_FOR_DEVICE = SM121
    all_ok = True
    for (N, K) in KEYS:
        torch.manual_seed(1234)
        w = torch.rand((N, K), dtype=torch.bfloat16, device=dev)
        b = w.t()
        a_full = torch.rand((2048, K), dtype=torch.bfloat16, device=dev)
        hashes, cfgs = {}, {}
        for M in (1, 8, 32, 2048):
            a = a_full[:M]
            cfgs[M] = tuned_cfg(N, K, M)
            hashes[M] = row_hash(matmul_persistent(a, b)[0])
        ok = len(set(hashes.values())) == 1
        all_ok &= ok
        res["E2"].append({
            "N": N, "K": K, "hashes": hashes, "configs": cfgs,
            "one_hash": ok,
            "distinct_tiles": len({tuple(sorted(c.items())) for c in cfgs.values()}),
        })
        print(f"{str((N,K)):>15}  {'SAME' if ok else 'DIFFER':>6}  "
              f"{hashes[1][:16]}  tiles@M1/8/32/2048 distinct="
              f"{res['E2'][-1]['distinct_tiles']}")
        del w, b, a_full
        torch.cuda.empty_cache()
    print("E2 verdict:", "all 15 shapes give ONE hash" if all_ok else "MISMATCH")

    # ---------------- E3: negative controls ----------------
    print("\n### E3  negative controls - can the E2 gate fail at all? ###")
    N, K = 4096, 4096
    torch.manual_seed(1234)
    w = torch.rand((N, K), dtype=torch.bfloat16, device=dev)
    b = w.t()
    a_full = torch.rand((2048, K), dtype=torch.bfloat16, device=dev)

    # (i) configs that differ ONLY in BLOCK_SIZE_K, everything else pinned,
    #     and every one of them launchable on GB10 (101376 B of shared memory).
    for bk_small, bk_big in ((64, 128), (32, 128), (32, 64)):
        hs, seen = {}, {}
        ok = True
        for M, bk in ((1, bk_small), (2048, bk_big)):
            cfg = {"BLOCK_SIZE_M": 64, "BLOCK_SIZE_N": 128, "BLOCK_SIZE_K": bk,
                   "GROUP_SIZE_M": 8, "num_stages": 3, "num_warps": 4}
            try:
                with ForceConfig(cfg=cfg) as fc:
                    hs[M] = row_hash(matmul_persistent(a_full[:M], b)[0])
                seen[M] = fc.seen[-1][3]
            except Exception as e:
                ok = False
                seen[M] = f"unavailable: {type(e).__name__}"
        name = f"block_k_only_{bk_small}_at_M1_vs_{bk_big}_at_M2048"
        differ = ok and len(set(hs.values())) > 1
        res["E3"].append({"control": name, "N": N, "K": K, "hashes": hs,
                          "launched_cfgs": seen, "ran": ok,
                          "hashes_differ": differ})
        print(f"  {name:>44}: "
              f"{'DIFFER' if differ else ('SAME' if ok else 'could not run')}")

    # (ii) tile-only change at a pinned BLOCK_SIZE_K: the property the PR relies on.
    hs, seen = {}, {}
    for M, cfg in (
        (1, {"BLOCK_SIZE_M": 16, "BLOCK_SIZE_N": 32, "BLOCK_SIZE_K": 64,
             "GROUP_SIZE_M": 8, "num_stages": 5, "num_warps": 4}),
        (2048, {"BLOCK_SIZE_M": 128, "BLOCK_SIZE_N": 128, "BLOCK_SIZE_K": 64,
                "GROUP_SIZE_M": 8, "num_stages": 3, "num_warps": 8}),
    ):
        with ForceConfig(cfg=cfg) as fc:
            hs[M] = row_hash(matmul_persistent(a_full[:M], b)[0])
        seen[M] = fc.seen[-1][3]
    differ = len(set(hs.values())) > 1
    res["E3"].append({"control": "tile_only_same_block_k", "N": N, "K": K,
                      "hashes": hs, "launched_cfgs": seen, "ran": True,
                      "hashes_differ": differ})
    print(f"  {'tile_only_same_block_k':>44}: "
          f"{'DIFFER' if differ else 'SAME'}")

    # (iii) SENSITIVITY CONTROLS - these must DIFFER, else the gate proves nothing.
    C._TUNED_MATMUL_CONFIGS_RESOLVED = True
    C._TUNED_MATMUL_CONFIGS_FOR_DEVICE = SM121
    full = matmul_persistent(a_full[:1], b)[0]
    h_full = row_hash(full)

    # split the K reduction in half and add the halves: same maths, different
    # order, so the bytes must move if the hash is sensitive to order at all.
    half = K // 2
    split = (matmul_persistent(a_full[:1, :half], b[:half])
             + matmul_persistent(a_full[:1, half:], b[half:]))[0]
    d_split = row_hash(split) != h_full
    res["E3"].append({"control": "SENSITIVITY_split_k_halves", "N": N, "K": K,
                      "hashes": {"full": h_full, "split": row_hash(split)},
                      "ran": True, "hashes_differ": d_split,
                      "max_abs_diff": float(
                          (full.float() - split.float()).abs().max().item())})
    print(f"  {'SENSITIVITY split-K halves':>44}: "
          f"{'DIFFER (gate is sensitive)' if d_split else 'SAME -- GATE IS BLIND'}")

    # cuBLAS with a different reduction order entirely.
    cub = torch.mm(a_full[:1], b)[0]
    d_cub = row_hash(cub) != h_full
    res["E3"].append({"control": "SENSITIVITY_vs_cublas_torch_mm", "N": N, "K": K,
                      "hashes": {"triton": h_full, "cublas": row_hash(cub)},
                      "ran": True, "hashes_differ": d_cub,
                      "max_abs_diff": float(
                          (full.float() - cub.float()).abs().max().item())})
    print(f"  {'SENSITIVITY vs cuBLAS torch.mm':>44}: "
          f"{'DIFFER (gate is sensitive)' if d_cub else 'SAME -- GATE IS BLIND'}")

    with open(args.out, "w") as f:
        json.dump(res, f, indent=1, sort_keys=True, default=str)
    print("\nwrote", args.out)


if __name__ == "__main__":
    main()
