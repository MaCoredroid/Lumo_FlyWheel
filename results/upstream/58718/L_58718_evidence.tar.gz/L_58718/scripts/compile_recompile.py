# SPDX-License-Identifier: Apache-2.0
"""Does the tuned table force Dynamo to specialize on M?  (uninstrumented)

`_get_matmul_config` compares the runtime M against the bucket edges
(batch_invariant_configs.py:777-780).  With the table absent it returns `default`
before ever touching M (lines 769-770).  This counts unique Dynamo graphs over
the same M sequence for both, with NO patching of the traced code: an earlier
version of this script appended to a global list inside the traced function,
which added a `len(G['SYM'])` guard of its own and made both variants recompile
on every call.  That run is void; this one has no such side effect.
"""
import json

import torch

from vllm.model_executor.determinism import batch_invariant_configs as C
from vllm.model_executor.determinism.batch_invariant import linear_batch_invariant

N, K = 4096, 4096
SEQ = [1, 8, 16, 32, 64, 128, 256, 512, 1024, 2048]
torch._dynamo.config.recompile_limit = 64

dev = torch.device("cuda")
torch.manual_seed(1234)
w = torch.rand((N, K), dtype=torch.bfloat16, device=dev)
a = torch.rand((max(SEQ), K), dtype=torch.bfloat16, device=dev)
out = {}

for variant in ("tuned", "default"):
    C._TUNED_MATMUL_CONFIGS_RESOLVED = True
    C._TUNED_MATMUL_CONFIGS_FOR_DEVICE = (
        C._BATCH_INVARIANT_MATMUL_TUNED_CONFIGS["sm121"] if variant == "tuned"
        else None
    )
    torch._dynamo.reset()
    torch._dynamo.utils.counters.clear()
    fn = torch.compile(lambda x: linear_batch_invariant(x, w))
    per_m, prev = [], 0
    for M in SEQ:
        fn(a[:M])
        torch.cuda.synchronize()
        ng = torch._dynamo.utils.counters["stats"].get("unique_graphs", 0)
        per_m.append({"M": M, "new_graphs": ng - prev, "total": ng})
        prev = ng
    out[variant] = {"unique_graphs": prev, "per_m": per_m}
    print(f"{variant:>8}: {prev} unique Dynamo graphs over M={SEQ}")
    print(f"          new graphs per M: "
          f"{[(p['M'], p['new_graphs']) for p in per_m]}")

print()
print("same number of graphs for tuned and default: "
      f"{out['tuned']['unique_graphs'] == out['default']['unique_graphs']}")
with open("/home/mark/shared/tmp-scratch/L_58718/data/compile_recompile.json",
          "w") as f:
    json.dump(out, f, indent=1, sort_keys=True)
print("wrote data/compile_recompile.json")
