# SPDX-License-Identifier: Apache-2.0
"""Static analysis of the sm120 / sm121 tuned matmul tables at PR head.

No GPU needed. Reports:
  - set-equality of the (N, K) keys
  - BLOCK_K per shape for sm121 vs sm120 vs the bf16 default (64)
  - the m_bucket edges
  - which tile _get_matmul_config would return at each M of interest
"""
import json
import sys

from vllm.model_executor.determinism.batch_invariant_configs import (
    _BATCH_INVARIANT_MATMUL_TUNED_CONFIGS as T,
)

BF16_DEFAULT = {
    "BLOCK_SIZE_M": 128,
    "BLOCK_SIZE_N": 128,
    "BLOCK_SIZE_K": 64,
    "GROUP_SIZE_M": 8,
    "num_stages": 3,
    "num_warps": 8,
}

sm120 = T["sm120"]
sm121 = T["sm121"]

print("families present:", sorted(T.keys()))
print("sm120 keys:", len(sm120), " sm121 keys:", len(sm121))
print("set-equal:", set(sm120.keys()) == set(sm121.keys()))
only120 = set(sm120) - set(sm121)
only121 = set(sm121) - set(sm120)
print("only in sm120:", sorted(only120))
print("only in sm121:", sorted(only121))

MS = [1, 32, 256, 512, 1024, 2048]


def lookup(shape_config, M):
    m_config = shape_config.m_buckets[-1][1]
    for max_m, bucket_config in shape_config.m_buckets:
        if max_m >= M:
            m_config = bucket_config
            break
    return {
        "BLOCK_SIZE_M": m_config.block_m,
        "BLOCK_SIZE_N": m_config.block_n,
        "BLOCK_SIZE_K": shape_config.block_k,
        "GROUP_SIZE_M": 8,
        "num_warps": m_config.num_warps,
        "num_stages": m_config.num_stages,
    }


print()
print("bucket edges identical across all sm121 shapes:",
      len({tuple(e for e, _ in c.m_buckets) for c in sm121.values()}) == 1)
print("sm121 bucket edges:", [e for e, _ in next(iter(sm121.values())).m_buckets])

print()
print(f"{'(N,K)':>16} {'bk121':>6} {'bk120':>6} {'bk_def':>7}  tiles@M (sm121)")
nk128 = 0
for key in sorted(sm121.keys()):
    c121, c120 = sm121[key], sm120[key]
    if c121.block_k == 128:
        nk128 += 1
    tiles = " ".join(
        f"M{M}:{lookup(c121, M)['BLOCK_SIZE_M']}x{lookup(c121, M)['BLOCK_SIZE_N']}"
        f"w{lookup(c121, M)['num_warps']}s{lookup(c121, M)['num_stages']}"
        for M in MS
    )
    print(f"{str(key):>16} {c121.block_k:>6} {c120.block_k:>6} {64:>7}  {tiles}")
print()
print(f"sm121 shapes with BLOCK_K=128: {nk128}/{len(sm121)}")
print(f"sm120 shapes with BLOCK_K=128: "
      f"{sum(1 for c in sm120.values() if c.block_k == 128)}/{len(sm120)}")

# how many sm121 tiles differ from the bf16 default at each M
print()
for M in MS:
    same = sum(1 for k in sm121 if lookup(sm121[k], M) == BF16_DEFAULT)
    print(f"M={M:>5}: sm121 tile == bf16 default for {same}/{len(sm121)} shapes")

out = {
    "keys": sorted([list(k) for k in sm121.keys()]),
    "sm121": {
        f"{k[0]}x{k[1]}": {
            "block_k": sm121[k].block_k,
            "buckets": [[e, list(c)] for e, c in sm121[k].m_buckets],
        }
        for k in sm121
    },
    "sm120_block_k": {f"{k[0]}x{k[1]}": sm120[k].block_k for k in sm120},
    "bf16_default": BF16_DEFAULT,
    "lookup_at_M": {
        str(M): {f"{k[0]}x{k[1]}": lookup(sm121[k], M) for k in sorted(sm121)}
        for M in MS
    },
}
with open(sys.argv[1], "w") as f:
    json.dump(out, f, indent=1, sort_keys=True)
print("\nwrote", sys.argv[1])
