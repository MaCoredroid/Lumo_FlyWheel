# SPDX-License-Identifier: Apache-2.0
"""Item L: re-time the 15 sm121 (N, K) keys, tuned table vs default tile.

For every (layout, (N, K), M) cell this times `matmul_persistent` with the sm121
table active and with it disabled, in BOTH A/B orders, using CUDA events with one
event pair per iteration and reporting the p50.

Layouts:
  wt     -- b = w.t() where w is a contiguous [N, K] weight. This is what
            `linear_batch_invariant` actually hands to `mm_batch_invariant`
            (batch_invariant.py:1036-1037), i.e. the production layout.
  contig -- b is a contiguous [K, N]. This is the layout a naive sweep or the
            `contiguous` half of the PR's own test uses.

Results are appended as JSON lines so a partial run is still usable.
"""

import argparse
import json
import statistics
import sys
import time

import torch

from vllm.model_executor.determinism import batch_invariant_configs as C
from vllm.model_executor.determinism.batch_invariant import matmul_persistent

BF16_DEFAULT = {
    "BLOCK_SIZE_M": 128,
    "BLOCK_SIZE_N": 128,
    "BLOCK_SIZE_K": 64,
    "GROUP_SIZE_M": 8,
    "num_stages": 3,
    "num_warps": 8,
}
MS = [1, 32, 256, 512, 1024, 2048]
MAX_M = max(MS)


TABLE = "sm121"


def set_variant(variant):
    """tuned -> TABLE active; default -> table disabled (default tile)."""
    C._TUNED_MATMUL_CONFIGS_RESOLVED = True
    if variant == "tuned":
        C._TUNED_MATMUL_CONFIGS_FOR_DEVICE = C._BATCH_INVARIANT_MATMUL_TUNED_CONFIGS[
            TABLE
        ]
    elif variant == "default":
        C._TUNED_MATMUL_CONFIGS_FOR_DEVICE = None
    else:
        raise ValueError(variant)


def dispatched_config(M, N, K):
    return C._get_matmul_config(M, N, K, torch.bfloat16, dict(BF16_DEFAULT))


def time_cell(a, b, iters, warmup):
    """p50 / min / mean of per-iteration CUDA-event times, in ms."""
    for _ in range(warmup):
        matmul_persistent(a, b)
    torch.cuda.synchronize()
    starts = [torch.cuda.Event(enable_timing=True) for _ in range(iters)]
    ends = [torch.cuda.Event(enable_timing=True) for _ in range(iters)]
    for i in range(iters):
        starts[i].record()
        matmul_persistent(a, b)
        ends[i].record()
    torch.cuda.synchronize()
    ts = sorted(starts[i].elapsed_time(ends[i]) for i in range(iters))
    return {
        "p50_ms": statistics.median(ts),
        "min_ms": ts[0],
        "p10_ms": ts[max(0, int(0.10 * len(ts)) - 1)],
        "p90_ms": ts[min(len(ts) - 1, int(0.90 * len(ts)))],
        "mean_ms": statistics.fmean(ts),
        "iters": iters,
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", required=True)
    ap.add_argument("--layouts", default="wt,contig")
    ap.add_argument("--iters-small", type=int, default=200)
    ap.add_argument("--iters-large", type=int, default=50)
    ap.add_argument("--warmup", type=int, default=10)
    ap.add_argument("--ms", default=",".join(str(m) for m in MS))
    ap.add_argument("--max-shapes", type=int, default=0)
    ap.add_argument("--table", default="sm121")
    args = ap.parse_args()
    global TABLE
    TABLE = args.table
    ms = [int(x) for x in args.ms.split(",")]

    torch.manual_seed(0)
    dev = torch.device("cuda")
    keys = sorted(C._BATCH_INVARIANT_MATMUL_TUNED_CONFIGS[TABLE].keys())
    assert len(keys) == 15, len(keys)
    if args.max_shapes:
        keys = keys[: args.max_shapes]

    out = open(args.out, "a", buffering=1)
    t_start = time.time()

    for layout in args.layouts.split(","):
        for (N, K) in keys:
            torch.manual_seed(1234)
            w = torch.randn((N, K), dtype=torch.bfloat16, device=dev) / (K ** 0.5)
            b = w.t() if layout == "wt" else w.t().contiguous()
            a_full = torch.randn((max(ms), K), dtype=torch.bfloat16, device=dev)

            # fp32 reference rows for the correctness gate (cheap: small M only)
            for M in ms:
                a = a_full[:M]
                assert a.is_contiguous()
                iters = args.iters_small if M <= 32 else args.iters_large
                cfgs, res = {}, {}

                # Pre-compile every kernel we are about to time, so JIT is never
                # inside a timed region.
                for variant in ("tuned", "default"):
                    set_variant(variant)
                    cfgs[variant] = dispatched_config(M, N, K)
                    matmul_persistent(a, b)
                torch.cuda.synchronize()

                # correctness gate vs an fp32 torch.mm reference (M <= 32 only:
                # an fp32 reference at M=2048, N=151936 is not worth the time)
                gate = {}
                if M <= 32:
                    ref = torch.mm(a.float(), b.float())
                    for variant in ("tuned", "default"):
                        set_variant(variant)
                        o = matmul_persistent(a, b).float()
                        gate[variant] = {
                            "max_abs_err": (o - ref).abs().max().item(),
                            "allclose_1e-1": bool(
                                torch.allclose(o, ref, rtol=1e-1, atol=1e-1)
                            ),
                        }
                    del ref

                # tuned vs default agreement at every cell
                set_variant("tuned")
                ot = matmul_persistent(a, b)
                set_variant("default")
                od = matmul_persistent(a, b)
                tuned_vs_default = {
                    "bitwise_equal": bool(torch.equal(ot, od)),
                    "max_abs_diff": (ot.float() - od.float()).abs().max().item(),
                }
                del ot, od

                # Timed A/B, both orders.
                for order in ("TD", "DT"):
                    seq = ("tuned", "default") if order == "TD" else (
                        "default",
                        "tuned",
                    )
                    for variant in seq:
                        set_variant(variant)
                        res[(order, variant)] = time_cell(
                            a, b, iters, args.warmup
                        )

                flops = 2.0 * M * N * K
                rec = {
                    "table": TABLE,
                    "layout": layout,
                    "N": N,
                    "K": K,
                    "M": M,
                    "iters": iters,
                    "cfg_tuned": cfgs["tuned"],
                    "cfg_default": cfgs["default"],
                    "cfg_identical": cfgs["tuned"] == cfgs["default"],
                    "gate_vs_fp32": gate,
                    "tuned_vs_default": tuned_vs_default,
                    "t": {
                        f"{o}_{v}": res[(o, v)] for (o, v) in res
                    },
                    "ratio_TD": res[("TD", "tuned")]["p50_ms"]
                    / res[("TD", "default")]["p50_ms"],
                    "ratio_DT": res[("DT", "tuned")]["p50_ms"]
                    / res[("DT", "default")]["p50_ms"],
                    "tflops_tuned_TD": flops / (res[("TD", "tuned")]["p50_ms"] * 1e9),
                    "tflops_default_TD": flops
                    / (res[("TD", "default")]["p50_ms"] * 1e9),
                    "elapsed_s": round(time.time() - t_start, 1),
                }
                out.write(json.dumps(rec, sort_keys=True) + "\n")
                print(
                    f"[{rec['elapsed_s']:7.1f}s] {layout:6s} N={N:6d} K={K:5d} "
                    f"M={M:5d}  tuned {res[('TD','tuned')]['p50_ms']:9.4f}ms  "
                    f"default {res[('TD','default')]['p50_ms']:9.4f}ms  "
                    f"ratio TD {rec['ratio_TD']:.3f} DT {rec['ratio_DT']:.3f}",
                    flush=True,
                )
            del w, b, a_full
            torch.cuda.empty_cache()
    out.close()
    print("total %.1f s" % (time.time() - t_start))
    return 0


if __name__ == "__main__":
    sys.exit(main())
