# Pre-run card — Item L, vllm-project/vllm#58718

Written **before** any GPU run. Item L is a second-GB10 measurement of the `sm121`
batch-invariant matmul table added by #58718 (head `b40edf46984f06bb5fb84f35e6c56634df3de364`).

## What is under test

1. **The PR's own determinism test** at PR head:
   `tests/v1/determinism/test_matmul_batch_invariant.py` (34 cases expected).
2. **The tuned-vs-default timing claim.** For each of the 15 `(N, K)` keys in the new
   `sm121` table, time `matmul_persistent` at `M ∈ {1, 32, 256, 512, 1024, 2048}` with
   the tuned table active and with it disabled (bf16 default tile
   `128x128x64 / GROUP_M=8 / 8 warps / 3 stages`, `batch_invariant.py:307-315`).
   CUDA events, p50 of ≥50 timed iterations after warmup, **both A/B orders**.
3. **Bitwise M-invariance off the author's box.** For each of the 15 keys, sha256 of the
   bytes of output row 0 computed at `M = 1` vs at `M ∈ {8, 32, 2048}`, all from the same
   `a[0]` and same `b`, with the tuned table active.
4. **Compiled-path dispatch probe.** Which tile `_get_matmul_config` actually returns when
   the matmul is reached through `torch.compile` (and one CUDA-graph replay), at small and
   large `M`, and whether compiled output is bitwise equal to eager.

## Claims being checked (from the PR body and thread)

- C1: tuned/default ≈ 0.68x at M=1, 0.74x at M=32, 0.95x at M=256 (i.e. a decode win).
- C2: tuned/default ≈ 1.07x at M=512, 1.18x at M=1024, 1.14x at M=2048 (i.e. a 7-18%
  slowdown above M=512), "consistently across all three models".
- C3: the 15 `(N, K)` keys are set-equal to `sm120`; no shape added or dropped.
- C4: 12 of 15 shapes pick `BLOCK_K = 128` while the default tile uses 64, so the large-M
  buckets cannot fall back to the default without changing K-reduction order.
- C5: M=1 rows are bitwise identical to the same rows computed at M = 8 / 32 / 256 / 2048.
- C6: `_get_tuned_matmul_arch_family` maps 12.1 -> `sm121`, 12.0/12.2 -> `sm120`,
  10.0 -> `blackwell`, 9.0 -> `hopper`, 8.9 -> `ada`.

## Pass / fail

- **Reproduces** = the sign and rough size of the effect match: tuned/default < 1 at
  M ∈ {1, 32} (decode win) and > 1 at M ∈ {512, 1024, 2048} (large-M penalty), in both A/B
  orders, with the per-shape spread reported rather than only the mean.
- A ratio within ±0.03 of 1.00 in both orders is called **noise**, not a direction.
- **Invariance passes** = all 15 shapes give one sha256 for row 0 across
  M ∈ {1, 8, 32, 2048}. A single mismatch is a fail and is reported as a defect.
- **Test passes** = 34 passed, 0 failed.

## Negative control

The hash gate is only meaningful if it can fail. One run forces `BLOCK_SIZE_K = 64` at
M=1 and `128` at M=2048 for one shape (patching `_get_matmul_config`, not the table) and
must show **different** hashes. If that control does not fail, the gate proves nothing.

## What this evidence will NOT show

- **No end-to-end serving claim.** No `vllm serve`, no `vllm bench`, no model is loaded.
  A microbenchmark ratio on 15 GEMM shapes is not a tokens/s claim; the mix of M values a
  real workload sees, and everything else in the step, are out of scope.
- **Not a statement about the author's box.** Different driver/toolkit/Triton (see
  provenance in the report) can move tile rankings. A disagreement is a disagreement
  between two configurations, not proof the author mismeasured.
- **Not a re-sweep.** The search space is not re-explored, so this cannot say whether a
  better table exists, nor whether the decode-weighted score is the right objective.
- **No merge verdict and no design pitch.**
- The compiled probe covers a model-free `linear_batch_invariant` call, not vLLM's real
  V1 runner with its cudagraph capture set.

## Risks / expected confounders

- GB10 is unified LPDDR5X shared with the host: allocations stay small, each shape's
  tensors are freed before the next, and the A/B is interleaved per cell with both orders.
- Clock/thermal drift: both orders per cell, p50 not mean, and a re-time of any cell whose
  two orders disagree in direction.
- Triton JIT: every distinct config is compiled and cached before timing starts.
- The venv's compiled `*.so` were built 2026-08-24 from clone commit `23ab0cfdb`, not from
  PR head. This path is pure Python + Triton JIT, so that matters only for imports.
