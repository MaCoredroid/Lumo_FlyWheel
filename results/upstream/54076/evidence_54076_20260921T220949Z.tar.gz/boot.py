#!/usr/bin/env python3
"""#54076 boot check — launch one arm, archive everything, shut down."""
import argparse, json, os, signal, subprocess, sys, time, urllib.request

E = "/home/mark/shared/exp54928"
W = os.path.join(E, "exp54076")
TARGET = "Qwen/Qwen3.8-27B-FP8"
TARGET_REV = "017b9c7af6b5689d5dd426a76e0bc077eb5ca20a"
DRAFT = "incoai/Qwen3.8-27B-DFlash2"
DRAFT_REV = "dedf8df68adfb1afeaf7b7480c0a0243108177b4"

COMMON = ["--revision", TARGET_REV, "--tensor-parallel-size", "1",
          "--enable-prefix-caching", "--mamba-cache-mode", "align",
          "--max-num-seqs", "4", "--max-model-len", "4096",
          "--served-model-name", "qwen38", "--gpu-memory-utilization", "0.50"]

DFLASH = json.dumps({"model": DRAFT, "revision": DRAFT_REV, "num_speculative_tokens": 7})
EHS = json.dumps({"method": "extract_hidden_states", "num_speculative_tokens": 1,
                  "draft_model_config": {"hf_config": {"eagle_aux_hidden_state_layer_ids": [32]}}})

ARMS = {
    "arm1_dflash2":   COMMON + ["--speculative-config", DFLASH],
    "arm2_nospec":    COMMON,
    "arm3_bs816":     COMMON + ["--speculative-config", DFLASH, "--block-size", "816"],
    "arm4_extract":   COMMON + ["--speculative-config", EHS, "--kv-transfer-config",
                                json.dumps({"kv_connector": "ExampleHiddenStatesConnector",
                                            "kv_role": "kv_producer",
                                            "kv_connector_extra_config": {
                                                "shared_storage_path": os.path.join(W, "runs", "ehs_out"),
                                                "allow_custom_save_path": True}})],
}


def http(url, data=None, timeout=300):
    req = urllib.request.Request(url, data=json.dumps(data).encode() if data is not None else None,
                                 headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read().decode()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--arm", required=True, choices=sorted(ARMS))
    ap.add_argument("--port", type=int, default=8000)
    ap.add_argument("--timeout", type=int, default=1500)
    a = ap.parse_args()
    out = os.path.join(W, "runs", a.arm)
    os.makedirs(out, exist_ok=True)
    os.makedirs(os.path.join(W, "runs", "ehs_out"), exist_ok=True)
    env = dict(os.environ,
               HF_HOME=os.path.join(E, "hf"), HF_HUB_OFFLINE="1",
               PATH=os.path.join(E, ".venv/bin") + os.pathsep + os.environ.get("PATH", ""),
               FLASHINFER_WORKSPACE_BASE=os.path.join(E, "flashinfer_ws"),
               PYTHONPATH=os.path.join(W, "hook"),
               VLLM_LOGGING_LEVEL="DEBUG")
    argv = [os.path.join(E, ".venv/bin/vllm"), "serve", TARGET, *ARMS[a.arm], "--port", str(a.port)]
    with open(os.path.join(out, "argv.json"), "w") as f:
        json.dump(argv, f, indent=1)
    with open(os.path.join(out, "env.json"), "w") as f:
        json.dump({k: env[k] for k in sorted(("HF_HOME", "HF_HUB_OFFLINE", "PATH",
                   "FLASHINFER_WORKSPACE_BASE", "PYTHONPATH", "VLLM_LOGGING_LEVEL"))}, f, indent=1)
    log = open(os.path.join(out, "server.log"), "w")
    t0 = time.time()
    srv = subprocess.Popen(argv, stdout=log, stderr=subprocess.STDOUT, env=env, start_new_session=True)
    base = f"http://127.0.0.1:{a.port}"
    ready = False
    while time.time() - t0 < a.timeout:
        if srv.poll() is not None:
            break
        try:
            http(base + "/health", timeout=5); ready = True; break
        except Exception:
            time.sleep(5)
    meta = {"arm": a.arm, "argv": argv, "started_utc": time.strftime("%FT%TZ", time.gmtime(t0)),
            "ready": ready, "startup_s": round(time.time() - t0, 1), "server_exit": srv.poll()}
    if ready:
        try:
            with open(f"/proc/{srv.pid}/cmdline", "rb") as f:
                meta["proc_cmdline"] = [x.decode() for x in f.read().split(b"\0") if x]
        except Exception as ex:
            meta["proc_cmdline_error"] = repr(ex)
        for name, path in (("models", "/v1/models"), ("version", "/version")):
            try:
                meta[name] = json.loads(http(base + path))
            except Exception as ex:
                meta[name + "_error"] = repr(ex)
        try:
            resp = http(base + "/v1/chat/completions", {
                "model": "qwen38", "messages": [{"role": "user", "content": "Say OK."}],
                "max_tokens": 8, "temperature": 0, "seed": 1234,
                "chat_template_kwargs": {"enable_thinking": False}})
            with open(os.path.join(out, "smoke_resp.json"), "w") as f:
                f.write(resp)
            meta["smoke_ok"] = True
        except Exception as ex:
            meta["smoke_error"] = repr(ex)
    meta["finished_utc"] = time.strftime("%FT%TZ", time.gmtime())
    with open(os.path.join(out, "meta.json"), "w") as f:
        json.dump(meta, f, indent=1)
    if srv.poll() is None:
        os.killpg(os.getpgid(srv.pid), signal.SIGINT)
        try:
            srv.wait(150)
        except subprocess.TimeoutExpired:
            os.killpg(os.getpgid(srv.pid), signal.SIGKILL)
    log.close()
    print(f"[{a.arm}] ready={ready} startup={meta['startup_s']}s exit={srv.poll()}", flush=True)
    return 0 if ready else 2


if __name__ == "__main__":
    sys.exit(main())
