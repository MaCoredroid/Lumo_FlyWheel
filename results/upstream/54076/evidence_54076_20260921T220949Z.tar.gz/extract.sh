#!/usr/bin/env bash
# Pull the decisive lines (with line numbers) out of one arm's server.log.
set -u
W=/home/mark/shared/exp54928/exp54076
ARM=$1
L=$W/runs/$ARM/server.log
echo "##### $ARM  ($(wc -l < "$L") lines)  #####"
echo "--- ready/startup ---"
python3 -c "import json;m=json.load(open('$W/runs/$ARM/meta.json'));print({k:m.get(k) for k in ('ready','startup_s','server_exit','smoke_ok','smoke_error')})" 2>/dev/null
echo "--- stock INFO/DEBUG block-size lines ---"
grep -nE "Setting kv cache block size|Setting attention block size|Padding mamba page size|Using block size|GPU KV cache size|Maximum concurrency|KV cache groups|kv_cache_group" "$L" | grep -v "Loaded weight" | cut -c1-400
echo "--- hook lines ---"
grep -n "E54076" "$L" | grep -vE "SITECUSTOMIZE_LOADED" | cut -c1-500
echo "--- errors ---"
grep -nE "Traceback|ValueError|RuntimeError|AssertionError|NotImplementedError|ERROR " "$L" | head -10 | cut -c1-300
