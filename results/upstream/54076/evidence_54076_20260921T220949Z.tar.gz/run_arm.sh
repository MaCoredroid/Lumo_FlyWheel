#!/usr/bin/env bash
# One arm, under the GPU lock, with drop_caches first. Usage: run_arm.sh <arm>
set -u
E=/home/mark/shared/exp54928
W=$E/exp54076
ARM=$1
mkdir -p "$W/logs" "$W/runs/$ARM"
{
  echo "=== arm=$ARM start $(date -u +%FT%TZ)"
  nvidia-smi --query-gpu=name,driver_version,memory.used --format=csv,noheader
  sudo -n sh -c 'sync; echo 3 > /proc/sys/vm/drop_caches' 2>/dev/null && echo "drop_caches ok" || echo "drop_caches FAILED"
  sleep 3
  $E/.venv/bin/python -c "import torch;f,t=torch.cuda.mem_get_info();print('free_GiB',round(f/2**30,1),'total_GiB',round(t/2**30,1))"
  $E/.venv/bin/python "$W/boot.py" --arm "$ARM" --port 8000
  rc=$?
  echo "=== arm=$ARM boot.py exit=$rc $(date -u +%FT%TZ)"
  pkill -f '[v]llm serve' 2>/dev/null; sleep 10
  nvidia-smi --query-compute-apps=pid,used_memory --format=csv
  nvidia-smi --query-gpu=memory.used --format=csv,noheader
  echo "=== arm=$ARM end $(date -u +%FT%TZ)"
} 2>&1 | tee -a "$W/logs/run_$ARM.log"
