# Pre-run card — Item J, vllm-project/vllm#58400

Written before any run. Nothing below is a result.

## What is under test

`MambaHybridModelState` + the GDN metadata builder as the **state-routing contract**
for the batch class PR #58400 newly admits to the FULL decode graph: a cached
one-token prompt tail (full prefix-cache hit / P/D KV import / final one-token
chunk), optionally padded by the scheduler with K placeholder drafts to the K+1
spec-decode shape, sharing a batch with real verify decodes.

The claim to be checked by execution — the **state invariant** — is:

> After such a step, the recurrent state bytes that the NEXT step reads as the
> request's initial state are exactly the bytes the eager (unpadded, PIECEWISE)
> execution of the same logical request would leave there; state derived from
> the placeholder/rejected draft tokens stays in the scratch columns and never
> becomes the committed state.

Unit under test, by execution:

1. `GPUModelRunner.gather_batch_req_state` — `prefill_runs_as_decode_np`,
   `decode_graph_eligible`, and the `get_uniform_decode_token_count` gate.
2. `MambaHybridModelState.prepare_attn` — the `is_prefilling` adjustment and the
   `num_decode_draft_tokens_cpu` / `num_accepted_tokens` it hands the builder, at
   `CUDAGraphMode.FULL` (request- and token-padded) and at `CUDAGraphMode.NONE`.
3. `GDNAttentionMetadataBuilder.build` — the real `spec_state_indices_tensor`,
   `non_spec_state_indices_tensor`, `prefill_state_indices`, `has_initial_state`,
   `num_accepted_tokens` for that metadata.
4. `MambaHybridModelState.postprocess_state` — the real acceptance-count commit
   (`num_accepted_tokens_gpu`), which is what selects the committed column at the
   next step.
5. A **synthetic recurrent mixer** over synthetic conv/SSM pools. It is not a
   model: it is a line-by-line reimplementation of the three state-write
   contracts read out of the source, each cited in the test file:
   - spec-decode row: initial state from `spec_state_indices[row, num_accepted-1]`,
     per-token state written to `spec_state_indices[row, t]`, `<=0` skipped
     (`vllm/third_party/flash_linear_attention/ops/fused_recurrent.py:103-163`);
   - non-spec decode row: in-place at `non_spec_state_indices_tensor[row]`
     (`vllm/model_executor/layers/mamba/gdn/qwen_gdn_linear_attn.py:1488`);
   - prefill row: initial state from `prefill_state_indices` gated by
     `has_initial_state`, only the FINAL state written back
     (`qwen_gdn_linear_attn.py:1500-1523`).
   The recurrence is integer (`h -> (h*31 + tok) mod 2**20`) so every comparison
   is byte-exact with no tolerance.

## Cases

- **A** one-token cached tail + K rejected placeholders, FULL path, vs the same
  request unpadded and eager: committed bytes must be equal, for the tail and for
  every other request in the batch.
- **B** the tail's placeholder columns pre-poisoned with a sentinel AND the
  placeholder tokens themselves poison-tagged: no poison byte may appear in the
  committed state.
- **C** fresh-prompt control (`num_computed_prefill == 0`): must NOT be marked
  `prefill_runs_as_decode`, must keep `is_prefilling`, must not make the batch
  FULL-eligible, and its state must be initialised from scratch.
- **D** FULL-path cudagraph padding rows must commit nothing, even when their
  block-table rows are non-null.
- **E** one-token MID-prompt chunk padded with placeholder drafts (more than one
  prompt token still remaining): head marks it, merge-base does not.
- **negative control (NC)** the padded tail routed through the *prefill* write
  contract instead — i.e. the state h(N+K+1) that folded the placeholders is
  written to the committed column, exactly what `mamba_hybrid.py`'s comment says
  the prefill kernels do. Every byte assertion above must FAIL. If NC passes,
  the test does not discriminate and its passes are worthless.

## Pass / fail

- PASS at PR head = every case A..E holds and NC fails as designed.
- Discrimination = the same file at the merge base must fail at least one
  assertion; which one, and whether that failure is a live defect on `main` or
  only an unreachable-path difference, is a result to be reported, not assumed.

## What the evidence will NOT show

- No model is loaded and no mamba/GDN/conv CUDA or Triton kernel is executed.
  The synthetic mixer stands in for them. If the real kernels' write contract
  differs from the source lines cited above, this test is wrong in the same way.
- Nothing about throughput, TPOT, or the non-FULL step share the PR measures.
- Nothing about a real CUDA graph capture/replay: the FULL arm is the FULL-mode
  *metadata* path (`num_reqs_after_padding` / `num_tokens_after_padding`), not a
  captured graph. Stale-pointer or shape-baking hazards of an actual capture are
  out of scope.
- Nothing about `mamba_cache_mode="align"`, so nothing about
  `MambaSpecDecodeGPUContext.run_fused_postprocess_align`, the other V2
  state-commit boundary.
- Nothing about PCP, PP, DBO, or adaptive verification.
- No end-to-end token or logprob equality; no statement about output quality.

## Environment

GB10, single GPU, under `flock /home/mark/shared/exp54928/gpu.lock`. No model
launch, so no cache drop needed; peak allocation is a few hundred KB of
synthetic pools. Python `/home/mark/shared/vllm-head/.venv/bin/python`, sources
selected by `PYTHONPATH` to worktrees of `/home/mark/shared/vllm-head` at the PR
head and the merge base. GitHub access read-only.
