# SPDX-License-Identifier: Apache-2.0
"""Print, verbatim, the assertion the negative control triggers.

Not part of the offered test file.
"""

import sys

sys.path.insert(0, ".")

from probe_metadata_diff import _MP  # noqa: E402
from tests.v1.worker.test_mamba_hybrid_prompt_tail_state import (  # noqa: E402
    CUDAGraphMode,
    _assert_tail_committed_state_is_clean,
    _committed,
    _decode_row,
    _eager_tail_row,
    _padded_tail_row,
    _run_arm,
)


def main() -> None:
    mp = _MP()
    broken = _run_arm(
        [_decode_row(), _padded_tail_row(poison=True)],
        mp,
        cudagraph_mode=CUDAGraphMode.FULL,
        num_reqs_padded=4,
        num_tokens_padded=16,
        num_sampled={"d0": 2, "tail": 1},
        tail_as_prefill_rid="tail",
    )
    mp.undo()
    eager = _run_arm(
        [_decode_row(), _eager_tail_row()],
        mp,
        cudagraph_mode=CUDAGraphMode.NONE,
        num_sampled={"d0": 2, "tail": 1},
    )
    mp.undo()
    tail = next(r for r in broken.ordered if r.rid == "tail")
    ssm, conv = _committed(broken.state, broken.pools, tail)
    print("broken committed ssm :", ssm.tolist())
    print("broken committed conv:", conv.tolist())
    tail_e = next(r for r in eager.ordered if r.rid == "tail")
    ssm_e, conv_e = _committed(eager.state, eager.pools, tail_e)
    print("eager  committed ssm :", ssm_e.tolist())
    print("eager  committed conv:", conv_e.tolist())
    try:
        _assert_tail_committed_state_is_clean(broken, eager)
    except AssertionError as exc:
        print("negative control raised AssertionError:")
        print(str(exc))
        return
    raise SystemExit("NEGATIVE CONTROL DID NOT FIRE")


if __name__ == "__main__":
    main()
