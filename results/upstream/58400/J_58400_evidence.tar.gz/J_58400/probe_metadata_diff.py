# SPDX-License-Identifier: Apache-2.0
"""Dump the GDN metadata the FULL arm of the state test produces, so the head
and the merge base can be diffed field by field.

Not part of the offered test file. Run with PYTHONPATH pointing at the worktree
whose sources are under test; prints one JSON object.
"""

import json
import sys

import torch

sys.path.insert(0, ".")

from tests.v1.worker.test_mamba_hybrid_prompt_tail_state import (  # noqa: E402
    CUDAGraphMode,
    _decode_row,
    _eager_tail_row,
    _padded_tail_row,
    _run_arm,
)


class _MP:
    """The two attributes pytest's monkeypatch fixture exposes here."""

    def __init__(self):
        self._undo = []

    def setattr(self, target, name, value=None):
        old = getattr(target, name)
        self._undo.append((target, name, old))
        setattr(target, name, value)

    def undo(self):
        for target, name, old in reversed(self._undo):
            setattr(target, name, old)
        self._undo.clear()


def _t(x):
    if x is None:
        return None
    if isinstance(x, torch.Tensor):
        return x.cpu().tolist()
    return x


def _dump(arm, name):
    m = arm.meta
    return {
        "arm": name,
        "is_prefilling": _t(arm.mamba_meta.is_prefilling),
        "num_decode_draft_tokens_cpu": _t(arm.mamba_meta.num_decode_draft_tokens_cpu),
        "num_accepted_tokens_in": _t(arm.mamba_meta.num_accepted_tokens),
        "num_spec_decodes": m.num_spec_decodes,
        "num_decodes": m.num_decodes,
        "num_prefills": m.num_prefills,
        "num_prefill_tokens": m.num_prefill_tokens,
        "num_spec_decode_tokens": m.num_spec_decode_tokens,
        "spec_sequence_masks": _t(m.spec_sequence_masks),
        "spec_state_indices_tensor": _t(m.spec_state_indices_tensor),
        "non_spec_state_indices_tensor": _t(m.non_spec_state_indices_tensor),
        "prefill_state_indices": _t(m.prefill_state_indices),
        "has_initial_state": _t(m.has_initial_state),
        "num_accepted_tokens_out": _t(m.num_accepted_tokens),
        "spec_query_start_loc": _t(m.spec_query_start_loc),
        "uniform_tok_count": arm.uniform_tok_count,
        "decode_graph_eligible": bool(
            getattr(
                arm.batch_state,
                "decode_graph_eligible",
                not arm.batch_state.has_prefill,
            )
        ),
        "num_accepted_tokens_gpu_after": _t(arm.state.num_accepted_tokens_gpu),
        "ssm_pool_nonempty": {
            str(i): row
            for i, row in enumerate(arm.pools.ssm.cpu().tolist())
            if row != [-1, -1, -1]
        },
        "conv_pool_nonempty": {
            str(i): row
            for i, row in enumerate(arm.pools.conv.cpu().tolist())
            if set(row) != {-1}
        },
    }


def main() -> None:
    mp = _MP()
    out = []
    full = _run_arm(
        [_decode_row(), _padded_tail_row(poison=True)],
        mp,
        cudagraph_mode=CUDAGraphMode.FULL,
        num_reqs_padded=4,
        num_tokens_padded=16,
        num_sampled={"d0": 2, "tail": 1},
    )
    out.append(_dump(full, "FULL padded tail (poisoned scratch)"))
    mp.undo()
    eager = _run_arm(
        [_decode_row(), _eager_tail_row()],
        mp,
        cudagraph_mode=CUDAGraphMode.NONE,
        num_sampled={"d0": 2, "tail": 1},
    )
    out.append(_dump(eager, "eager unpadded tail"))
    mp.undo()
    import vllm

    print(
        json.dumps(
            {"vllm_file": vllm.__file__, "arms": out}, indent=2, sort_keys=True
        )
    )


if __name__ == "__main__":
    main()
