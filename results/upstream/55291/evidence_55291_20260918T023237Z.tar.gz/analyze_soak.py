#!/usr/bin/env python3
"""Summarise the #55291 soak records into a verdict per CARD.md section 10."""
import json, os, sys, collections

OUT = "/home/mark/shared/exp54928/exp55291/runs/soak"
recs = []
with open(os.path.join(OUT, "records.jsonl")) as f:
    for line in f:
        line = line.strip()
        if line:
            try:
                recs.append(json.loads(line))
            except Exception:
                pass
meta = json.load(open(os.path.join(OUT, "meta.json"))) if os.path.exists(os.path.join(OUT, "meta.json")) else {}

by_kind = collections.Counter(r["kind"] for r in recs)
errs = [r for r in recs if r.get("error")]
col = [r for r in recs if r.get("COLLAPSE")]
gen = sum(r.get("n_gen") or 0 for r in recs)
maxctx = max([(r.get("n_prompt") or 0) + (r.get("n_gen") or 0) for r in recs] or [0])
finish = collections.Counter(r.get("finish_reason") for r in recs)
longest_bang = max([r.get("bang_longest_chars") or 0 for r in recs] or [0])
longest_bang_tok = max([r.get("bang_longest_run") or 0 for r in recs] or [0])
maxrep = max([r.get("max_repeat_run") or 0 for r in recs] or [0])
maxrep_rec = max(recs, key=lambda r: r.get("max_repeat_run") or 0) if recs else None
lat = sorted(r["latency_s"] for r in recs if "latency_s" in r)

print("=== #55291 SOAK SUMMARY ===")
print("requests         :", len(recs), dict(by_kind))
print("errors           :", len(errs))
if errs:
    ec = collections.Counter(e["error"][:90] for e in errs)
    for k, v in ec.most_common(6):
        print("   ", v, "x", k)
print("generated tokens :", gen)
print("max ctx (p+g)    :", maxctx, " (max_model_len:", meta.get("max_model_len"), ")")
print("finish_reason    :", dict(finish))
print("bang token ids   :", meta.get("bang_token_ids"))
print("text field       :", dict(collections.Counter(r.get("text_field") for r in recs)))
print("longest ! run    :", longest_bang, "chars /", longest_bang_tok, "tokens  (COLLAPSE threshold: 16 chars)")
print("max any-token run:", maxrep, "token", maxrep_rec.get("max_repeat_token") if maxrep_rec else None,
      "in", maxrep_rec.get("tag") if maxrep_rec else None)
if lat:
    print("latency s        : min %.1f p50 %.1f p95 %.1f max %.1f" %
          (lat[0], lat[len(lat)//2], lat[int(len(lat)*0.95)], lat[-1]))
print("COLLAPSES        :", len(col))
for r in col[:20]:
    print("   ", r["tag"], r["kind"], "first_idx", r["bang_first_index"],
          "chars", r.get("bang_longest_chars"), "frac", r["bang_frac"])
canaries = [r for r in recs if r["kind"] == "CANARY"]
print("canaries         :", len(canaries), "collapsed:", sum(1 for r in canaries if r.get("COLLAPSE")))
if canaries:
    print("  first canary text:", (canaries[0].get("text_head") or "")[:120])
    print("  last  canary text:", (canaries[-1].get("text_head") or "")[:120])
if meta.get("poisoning"):
    print("poisoning        :", json.dumps({k: v for k, v in meta["poisoning"].items() if k != "log_hits"}))
print("log mamba lines  :")
for l in (meta.get("log_mamba_lines") or [])[:8]:
    print("   ", l[:200])

verdict = ("REPRODUCES" if col and meta.get("poisoning", {}).get("solo_canaries_collapsed", "0/10").split("/")[0].isdigit()
           and int(meta.get("poisoning", {}).get("solo_canaries_collapsed", "0/10").split("/")[0]) >= 6
           else "PARTIALLY REPRODUCES" if col else "DOES NOT REPRODUCE")
print("VERDICT          :", verdict)
