#!/usr/bin/env python3
"""#55291 reproduction soak on GB10 — implements CARD.md exactly.

One server launch, phases P0..P4, mechanical collapse detection on token ids,
poisoning protocol on first collapse. Everything recorded.
"""
import argparse, json, os, signal, subprocess, sys, threading, time, urllib.request, urllib.error

E = "/home/mark/shared/exp54928"
X = os.path.join(E, "exp55291")
MODEL = "Qwen/Qwen3.6-27B-FP8"
REV = "e89b16ebf1988b3d6befa7de50abc2d76f26eb09"
SERVED = "Qwen3.6-27B"
PORT = 8000
BASE = f"http://127.0.0.1:{PORT}"
MML_LADDER = [128000, 65536, 32768]

OUT = os.path.join(X, "runs", "soak")
os.makedirs(OUT, exist_ok=True)
REC = open(os.path.join(OUT, "records.jsonl"), "a", buffering=1)
REC_LOCK = threading.Lock()
STATE = {"collapsed": False, "n_req": 0, "n_gen_tok": 0, "max_ctx": 0,
         "bang_ids": set(), "bang_chars": {}, "stop": False}
SNAP = ("/home/mark/shared/exp54928/hf/hub/models--Qwen--Qwen3.6-27B-FP8/"
        "snapshots/e89b16ebf1988b3d6befa7de50abc2d76f26eb09")


def log(*a):
    print(f"[{time.strftime('%H:%M:%S')}]", *a, flush=True)


def http(url, data=None, timeout=900):
    req = urllib.request.Request(
        url, data=json.dumps(data).encode() if data is not None else None,
        headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read().decode()


# ---------------------------------------------------------------- prompts
FILLER = (
    "The distribution ledger for fiscal quarter {q} records that warehouse {w} "
    "dispatched {n} pallets of component {c} to the regional depot, where the "
    "receiving clerk logged a variance of {v} units against the manifest. "
)


def long_doc(seed_i, approx_tokens=6000):
    parts = []
    i = seed_i
    # ~40 tokens per sentence, so ~150 sentences for 6k tokens
    for k in range(approx_tokens // 40):
        i = (i * 1103515245 + 12345) & 0x7FFFFFFF
        parts.append(FILLER.format(q=(i % 4) + 1, w=chr(65 + i % 26) + str(i % 97),
                                   c=f"C-{i % 9973:04d}", n=i % 500, v=(i % 41) - 20))
    return "".join(parts)


CANARY_CONTENT = "Hello, please introduce yourself in one sentence."

SHORT_PROMPTS = [
    "What is 17 times 23?",
    "What is the capital of Portugal?",
    "Write a one-line shell command to count files in a directory.",
    "Write a haiku about rain.",
    "Name three primary colors.",
    "What year did the Apollo 11 mission land on the moon?",
    "Translate 'good morning' into French.",
    "In one sentence, what does a compiler do?",
]
# never used before P-poisoning step 3
FRESH_PROMPTS = [
    "How many sides does a hexagon have?",
    "What is the boiling point of water in Celsius at sea level?",
    "Give me one synonym for 'rapid'.",
    "What is the chemical symbol for gold?",
    "Write the first five Fibonacci numbers.",
    "What is 2 to the power of 10?",
    "Name the largest ocean on Earth.",
    "Spell the word 'necessary'.",
]
LONG_QUESTIONS = [
    "Summarise the ledger above in three sentences, then list any depot that appears more than twice.",
    "Based on the ledger above, explain in detail what an auditor should check first and why.",
    "Write a detailed step-by-step reconciliation procedure for the ledger above.",
    "Describe at length the risks implied by the variances in the ledger above.",
]


def mkreq(kind, idx, messages=None, max_tokens=None, greedy=False, top_lp=1):
    if kind == "CANARY":
        messages = [{"role": "user", "content": CANARY_CONTENT}]
        max_tokens, greedy, top_lp = 100, True, 5
    body = {
        "model": SERVED, "messages": messages, "max_tokens": max_tokens,
        "stream": False, "n": 1,
        "temperature": 0.0 if greedy else 0.7,
        "top_p": 1.0 if greedy else 0.95,
        "seed": 55291 + idx,
        "logprobs": True, "top_logprobs": top_lp,
        "return_token_ids": True,
    }
    return body


# ---------------------------------------------------------------- detection
def find_bang_run(ids, bang):
    """bang: {token_id: n_bang_chars}. A maximal run of consecutive bang tokens is
    scored by the total number of '!' CHARACTERS it emits, because the vocab has
    multi-'!' tokens ('!!!!!!!!' is one token). Returns
    (first_index_of_run_with_ge_16_chars, longest_run_tokens, longest_run_chars, frac)."""
    if not ids:
        return None, 0, 0, 0.0
    best_tok = best_chr = cur_tok = cur_chr = 0
    cur_i = None
    first16 = None
    for i, t in enumerate(ids):
        n = bang.get(t)
        if n:
            if cur_tok == 0:
                cur_i = i
            cur_tok += 1
            cur_chr += n
            if cur_chr >= 16 and first16 is None:
                first16 = cur_i
            if cur_chr > best_chr:
                best_chr, best_tok = cur_chr, cur_tok
        else:
            cur_tok = cur_chr = 0
    frac = sum(1 for t in ids if t in bang) / len(ids)
    return first16, best_tok, best_chr, frac


def analyze(kind, tag, body, raw, dt):
    rec = {"t": time.strftime("%FT%TZ", time.gmtime()), "kind": kind, "tag": tag,
           "latency_s": round(dt, 2)}
    try:
        d = json.loads(raw)
    except Exception as ex:
        rec["error"] = f"unparseable: {ex!r}"; rec["raw_head"] = raw[:400]
        return rec, None
    if "error" in d and "choices" not in d:
        rec["error"] = str(d["error"])[:500]
        return rec, d
    ch = d["choices"][0]
    msg = ch.get("message") or {}
    # vLLM 0.28.0 returns generated token ids on the CHOICE, not the message.
    ids = ch.get("token_ids") or msg.get("token_ids") or []
    # With --reasoning-parser qwen3 the text may land in `reasoning`, not `content`.
    text = msg.get("content") or msg.get("reasoning") or msg.get("reasoning_content") or ""
    rec["text_field"] = ("content" if msg.get("content") else
                         "reasoning" if (msg.get("reasoning") or msg.get("reasoning_content"))
                         else "empty")
    rec["finish_reason"] = ch.get("finish_reason")
    rec["n_gen"] = (d.get("usage") or {}).get("completion_tokens")
    rec["n_prompt"] = (d.get("usage") or {}).get("prompt_tokens")
    rec["n_token_ids"] = len(ids)
    rec["text_head"] = text[:160]
    rec["text_tail"] = text[-80:] if len(text) > 240 else ""
    rec["reasoning_tokens"] = ((d.get("usage") or {}).get("completion_tokens_details") or {}).get("reasoning_tokens")
    bang = STATE["bang_chars"]
    first16, longest_tok, longest_chr, frac = find_bang_run(ids, bang)
    rec["bang_first_index"] = first16
    rec["bang_longest_run"] = longest_tok
    rec["bang_longest_chars"] = longest_chr
    rec["bang_frac"] = round(frac, 4)
    # secondary: any single token repeated >=64
    rep_tok, rep_run, cur, cur_t = None, 0, 0, None
    for t in ids:
        cur = cur + 1 if t == cur_t else 1
        cur_t = t
        if cur > rep_run:
            rep_run, rep_tok = cur, t
    rec["max_repeat_run"] = rep_run
    rec["max_repeat_token"] = rep_tok
    collapse = bool(first16 is not None or (frac >= 0.90 and len(ids) >= 32))
    rec["n_gen_ids"] = len(ids)
    rec["COLLAPSE"] = collapse
    if collapse:
        # logprob signature at the first bang index
        try:
            lps = (ch.get("logprobs") or {}).get("content") or []
            i = first16 if first16 is not None else 0
            rec["logprob_signature"] = lps[max(0, i - 1): i + 3]
        except Exception as ex:
            rec["logprob_signature_error"] = repr(ex)
    return rec, d


def fire(kind, tag, body, keep_full=False):
    t0 = time.time()
    try:
        raw = http(f"{BASE}/v1/chat/completions", body)
    except Exception as ex:
        raw = json.dumps({"error": repr(ex)})
    rec, full = analyze(kind, tag, body, raw, time.time() - t0)
    with REC_LOCK:
        STATE["n_req"] += 1
        STATE["n_gen_tok"] += rec.get("n_gen") or 0
        STATE["max_ctx"] = max(STATE["max_ctx"], (rec.get("n_prompt") or 0) + (rec.get("n_gen") or 0))
        REC.write(json.dumps(rec, ensure_ascii=False) + "\n")
        if rec.get("COLLAPSE"):
            STATE["collapsed"] = True
        if keep_full or rec.get("COLLAPSE"):
            with open(os.path.join(OUT, f"full_{tag}.json"), "w") as f:
                f.write(raw)
            with open(os.path.join(OUT, f"req_{tag}.json"), "w") as f:
                json.dump(body, f, ensure_ascii=False, indent=1)
    return rec


def snap_metrics(tag):
    try:
        with open(os.path.join(OUT, f"metrics_{tag}.txt"), "w") as f:
            f.write(http(f"{BASE}/metrics", timeout=60))
    except Exception as ex:
        log("metrics fail", repr(ex))


def canary(tag):
    r = fire("CANARY", tag, mkreq("CANARY", 0), keep_full=(tag.endswith("_0") or STATE["collapsed"]))
    snap_metrics(tag)
    log(f"CANARY {tag}: collapse={r.get('COLLAPSE')} bang_chars={r.get('bang_longest_chars')} "
        f"n_gen={r.get('n_gen')} ids={r.get('n_gen_ids')} via={r.get('text_field')} "
        f"text={(r.get('text_head') or '')[:70]!r}")
    return r


# ---------------------------------------------------------------- server
def launch(mml, attempt):
    env = dict(os.environ, HF_HOME=os.path.join(E, "hf"), HF_HUB_OFFLINE="1",
               PATH=os.path.join(E, ".venv/bin") + os.pathsep + os.environ.get("PATH", ""),
               FLASHINFER_WORKSPACE_BASE=os.path.join(E, "flashinfer_ws"))
    argv = [
        os.path.join(E, ".venv/bin/vllm"), "serve", MODEL,
        "--revision", REV,
        "--host", "127.0.0.1", "--port", str(PORT),
        "--trust-remote-code",
        "--tensor-parallel-size", "1",
        "--served-model-name", SERVED,
        "--gpu-memory-utilization", "0.50",
        "--max-num-seqs", "20",
        "--enable-chunked-prefill",
        "--max-cudagraph-capture-size", "64",
        "--max-model-len", str(mml),
        "--limit-mm-per-prompt", '{"image": 16, "video": 1}',
        "--enable-prefix-caching",
        "--mm-processor-cache-gb", "0",
        "--mm-encoder-tp-mode", "data",
        "--enable-auto-tool-choice",
        "--reasoning-parser", "qwen3",
        "--tool-call-parser", "qwen3_xml",
        "--max-num-batched-tokens", "16384",
    ]
    subprocess.run(["sudo", "-n", "sh", "-c", "sync; echo 3 > /proc/sys/vm/drop_caches"],
                   check=False)
    time.sleep(3)
    logf = open(os.path.join(OUT, f"server_attempt{attempt}_mml{mml}.log"), "w")
    t0 = time.time()
    srv = subprocess.Popen(argv, stdout=logf, stderr=subprocess.STDOUT, env=env,
                           start_new_session=True)
    ready = False
    while time.time() - t0 < 2400:
        if srv.poll() is not None:
            break
        try:
            http(BASE + "/health", timeout=5)
            ready = True
            break
        except Exception:
            time.sleep(5)
    return srv, logf, argv, ready, round(time.time() - t0, 1)


def kill(srv):
    if srv.poll() is None:
        try:
            os.killpg(os.getpgid(srv.pid), signal.SIGINT)
            srv.wait(180)
        except Exception:
            try:
                os.killpg(os.getpgid(srv.pid), signal.SIGKILL)
            except Exception:
                pass
    subprocess.run(["pkill", "-f", "[v]llm serve"], check=False)
    time.sleep(10)


def resolve_bang_ids():
    """Every vocab token whose surface form is only '!' chars (optionally one
    leading space/newline marker). Returns {id: number_of_bang_chars}."""
    import re as _re
    tj = json.load(open(os.path.join(SNAP, "tokenizer.json")))
    vocab = tj["model"]["vocab"]
    pat = _re.compile(r"^(\u0120|\u010a)?!+$")
    out = {}
    for tok, i in vocab.items():
        if pat.match(tok):
            out[i] = tok.count("!")
    # cross-check against the served tokenizer
    try:
        r = json.loads(http(f"{BASE}/tokenize",
                            {"model": SERVED, "prompt": "!", "add_special_tokens": False},
                            timeout=60))
        log("server /tokenize('!') ->", r.get("tokens"))
    except Exception as ex:
        log("tokenize cross-check failed", repr(ex))
    return out


# ---------------------------------------------------------------- phases
def run_concurrent(items, workers):
    """items: list of (kind, tag, body). Returns list of recs."""
    out, lock, it = [], threading.Lock(), iter(list(enumerate(items)))

    def w():
        while not STATE["stop"] and not STATE["collapsed"]:
            with lock:
                try:
                    _, (kind, tag, body) = next(it)
                except StopIteration:
                    return
            r = fire(kind, tag, body)
            with lock:
                out.append(r)

    ts = [threading.Thread(target=w, daemon=True) for _ in range(workers)]
    [t.start() for t in ts]
    [t.join() for t in ts]
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--deadline-min", type=float, default=225.0, help="soak budget after ready")
    a = ap.parse_args()

    meta = {"card": "CARD.md", "model": MODEL, "revision": REV,
            "started_utc": time.strftime("%FT%TZ", time.gmtime())}
    srv = logf = None
    ready = False
    for attempt, mml in enumerate(MML_LADDER, 1):
        log(f"launch attempt {attempt} max_model_len={mml}")
        srv, logf, argv, ready, startup = launch(mml, attempt)
        meta.setdefault("launch_attempts", []).append(
            {"attempt": attempt, "max_model_len": mml, "ready": ready,
             "startup_s": startup, "exit": srv.poll()})
        if ready:
            meta["argv"], meta["max_model_len"], meta["startup_s"] = argv, mml, startup
            break
        log(f"attempt {attempt} failed (exit={srv.poll()}), stepping ladder")
        kill(srv)
        logf.close()
    if not ready:
        meta["verdict"] = "INCONCLUSIVE: could not launch"
        json.dump(meta, open(os.path.join(OUT, "meta.json"), "w"), indent=1)
        log("COULD NOT LAUNCH"); return 2

    deadline = time.time() + a.deadline_min * 60
    try:
        with open(f"/proc/{srv.pid}/cmdline", "rb") as f:
            meta["proc_cmdline"] = [x.decode() for x in f.read().split(b"\0") if x]
    except Exception as ex:
        meta["proc_cmdline_error"] = repr(ex)
    for ep in ("/v1/models", "/version"):
        try:
            meta[ep] = json.loads(http(BASE + ep, timeout=60))
        except Exception as ex:
            meta[ep] = f"ERR {ex!r}"
    STATE["bang_chars"] = resolve_bang_ids()
    STATE["bang_ids"] = set(STATE["bang_chars"])
    meta["bang_token_ids"] = {str(k): v for k, v in sorted(STATE["bang_chars"].items())}
    log("bang token ids:", meta["bang_token_ids"])
    # resolved mamba ssm cache dtype from the server log
    try:
        sl = open(os.path.join(OUT, f"server_attempt{len(meta['launch_attempts'])}_mml{meta['max_model_len']}.log"),
                  errors="replace").read()
        meta["log_mamba_lines"] = [l for l in sl.splitlines()
                                   if "mamba" in l.lower() or "ssm_cache" in l.lower()][:20]
    except Exception as ex:
        meta["log_mamba_error"] = repr(ex)
    json.dump(meta, open(os.path.join(OUT, "meta.json"), "w"), indent=1)

    def budget_left():
        return time.time() < deadline and not STATE["collapsed"] and not STATE["stop"]

    # ---- P0 baseline, serial
    log("=== P0 baseline (serial)")
    for i in range(5):
        canary(f"P0_canary_{i}")
        if STATE["collapsed"]:
            break
    if not STATE["collapsed"]:
        for i, p in enumerate(SHORT_PROMPTS):
            fire("SHORT", f"P0_short_{i}",
                 mkreq("SHORT", i, [{"role": "user", "content": p}], 128, greedy=True),
                 keep_full=(i == 0))
    meta["P0_done"] = True

    # ---- P1 serial soak
    rnd = 0
    log("=== P1 serial soak")
    while budget_left() and rnd < 6:
        for i, p in enumerate(SHORT_PROMPTS):
            if not budget_left():
                break
            fire("SHORT", f"P1_r{rnd}_short_{i}",
                 mkreq("SHORT", 1000 + rnd * 100 + i, [{"role": "user", "content": p}], 128))
        for i, q in enumerate(LONG_QUESTIONS):
            if not budget_left():
                break
            fire("LONG", f"P1_r{rnd}_long_{i}",
                 mkreq("LONG", 2000 + rnd * 100 + i,
                       [{"role": "user", "content": long_doc(rnd * 10 + i) + "\n\n" + q}], 2048))
        if budget_left():
            canary(f"P1_r{rnd}_canary")
        rnd += 1

    # ---- P2 concurrent soak
    log("=== P2 concurrent soak (20 workers)")
    batch = 0
    while budget_left() and batch < 8:
        items = []
        for i, p in enumerate(SHORT_PROMPTS):
            items.append(("SHORT", f"P2_b{batch}_short_{i}",
                          mkreq("SHORT", 3000 + batch * 100 + i,
                                [{"role": "user", "content": p}], 256)))
        for i, q in enumerate(LONG_QUESTIONS):
            for j in range(3):
                items.append(("LONG", f"P2_b{batch}_long_{i}_{j}",
                              mkreq("LONG", 4000 + batch * 100 + i * 10 + j,
                                    [{"role": "user", "content": long_doc(100 + batch * 20 + i * 3 + j) + "\n\n" + q}],
                                    1536)))
        run_concurrent(items, 20)
        if budget_left():
            canary(f"P2_b{batch}_canary")
        batch += 1

    # ---- P3 long-context growth
    log("=== P3 long-context growth")
    mml = meta["max_model_len"]
    convs = [[{"role": "user", "content": long_doc(900 + c) + "\n\nContinue analysing this ledger in depth."}]
             for c in range(4)]
    grow = 0
    while budget_left() and grow < 12:
        items = []
        for c, conv in enumerate(convs):
            items.append(("GROW", f"P3_g{grow}_c{c}", mkreq("GROW", 5000 + grow * 10 + c, conv, 1024)))
        recs = run_concurrent(items, 4)
        # append outputs and a follow-up to grow context
        for c, conv in enumerate(convs):
            r = next((x for x in recs if x["tag"] == f"P3_g{grow}_c{c}"), None)
            if r and r.get("text_head") is not None and not r.get("error"):
                try:
                    full = json.load(open(os.path.join(OUT, f"full_P3_g{grow}_c{c}.json")))
                    _m = full["choices"][0]["message"]
                    content = (_m.get("content") or _m.get("reasoning")
                               or _m.get("reasoning_content") or "")
                except Exception:
                    content = (r.get("text_head") or "") * 8
                conv.append({"role": "assistant", "content": content})
                conv.append({"role": "user", "content": long_doc(1900 + grow * 7 + c, 3000) +
                             "\n\nContinue the analysis, adding new detail each time."})
        if budget_left():
            canary(f"P3_g{grow}_canary")
        grow += 1
        # guard against blowing max_model_len
        if STATE["max_ctx"] > mml * 0.85:
            log("context near max_model_len, resetting conversations")
            convs = [[{"role": "user", "content": long_doc(3000 + grow * 5 + c) +
                       "\n\nAnalyse this ledger in depth."}] for c in range(4)]

    # ---- P4 repeat P2 until budget
    log("=== P4 repeat concurrent until budget")
    batch = 100
    while budget_left():
        items = []
        for i, p in enumerate(SHORT_PROMPTS):
            items.append(("SHORT", f"P4_b{batch}_short_{i}",
                          mkreq("SHORT", 6000 + batch * 100 + i, [{"role": "user", "content": p}], 256)))
        for i, q in enumerate(LONG_QUESTIONS):
            for j in range(3):
                items.append(("LONG", f"P4_b{batch}_long_{i}_{j}",
                              mkreq("LONG", 7000 + batch * 100 + i * 10 + j,
                                    [{"role": "user", "content": long_doc(5000 + batch * 20 + i * 3 + j) + "\n\n" + q}],
                                    1536)))
        run_concurrent(items, 20)
        if budget_left():
            canary(f"P4_b{batch}_canary")
        batch += 1

    # ---- poisoning protocol
    if STATE["collapsed"]:
        log("!!! COLLAPSE DETECTED — running poisoning protocol")
        meta["poisoning"] = po = {}
        time.sleep(20)
        n_col = 0
        for i in range(10):
            r = fire("POISON_CANARY", f"POIS_canary_{i}", mkreq("CANARY", 0), keep_full=True)
            n_col += bool(r.get("COLLAPSE"))
            log(f"  poison canary {i}: collapse={r.get('COLLAPSE')}")
            time.sleep(5)
        po["solo_canaries_collapsed"] = f"{n_col}/10"
        nf = 0
        for i, p in enumerate(FRESH_PROMPTS):
            r = fire("POISON_FRESH", f"POIS_fresh_{i}",
                     mkreq("SHORT", 9000 + i, [{"role": "user", "content": p}], 128, greedy=True),
                     keep_full=True)
            nf += bool(r.get("COLLAPSE"))
        po["fresh_prompts_collapsed"] = f"{nf}/{len(FRESH_PROMPTS)}"
        log("idle 120s, then re-probe self-heal")
        time.sleep(120)
        nh = 0
        for i in range(5):
            r = fire("POISON_HEAL", f"POIS_heal_{i}", mkreq("CANARY", 0), keep_full=True)
            nh += bool(r.get("COLLAPSE"))
        po["after_120s_idle_collapsed"] = f"{nh}/5"
        snap_metrics("POIS_final")
        try:
            sl = open(os.path.join(OUT, f"server_attempt{len(meta['launch_attempts'])}_mml{meta['max_model_len']}.log"),
                      errors="replace").read().splitlines()
            po["log_hits"] = [l for l in sl if any(k in l.lower()
                              for k in ("nan", "inf", "assert", "error", "traceback"))][-60:]
        except Exception as ex:
            po["log_error"] = repr(ex)

    meta.update({"finished_utc": time.strftime("%FT%TZ", time.gmtime()),
                 "n_requests": STATE["n_req"], "n_generated_tokens": STATE["n_gen_tok"],
                 "max_context_tokens": STATE["max_ctx"], "collapsed": STATE["collapsed"],
                 "server_exit_during_run": srv.poll()})
    json.dump(meta, open(os.path.join(OUT, "meta.json"), "w"), indent=1)
    log("SOAK DONE", json.dumps({k: meta[k] for k in
        ("n_requests", "n_generated_tokens", "max_context_tokens", "collapsed")}))

    # restart probe (poisoning protocol step 6)
    if STATE["collapsed"]:
        kill(srv); logf.close()
        log("restarting server to confirm a restart clears it")
        srv2, logf2, _, ready2, _ = launch(meta["max_model_len"], 9)
        if ready2:
            STATE["collapsed"] = False
            nc = 0
            for i in range(5):
                r = fire("RESTART_CANARY", f"RESTART_canary_{i}", mkreq("CANARY", 0), keep_full=True)
                nc += bool(r.get("COLLAPSE"))
            meta["poisoning"]["after_restart_collapsed"] = f"{nc}/5"
        kill(srv2); logf2.close()
        json.dump(meta, open(os.path.join(OUT, "meta.json"), "w"), indent=1)
    else:
        kill(srv); logf.close()
    REC.close()
    return 0


if __name__ == "__main__":
    sys.exit(main())
