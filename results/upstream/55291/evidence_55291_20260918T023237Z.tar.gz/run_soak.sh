#!/usr/bin/env bash
set -u
E=/home/mark/shared/exp54928
X=$E/exp55291
cd "$E"
export HF_HOME="$E/hf" HF_HUB_OFFLINE=1
{
  echo "=== soak start $(date -u +%FT%TZ)"
  nvidia-smi --query-gpu=name,driver_version --format=csv,noheader
  "$E/.venv/bin/python" -c "import vllm,torch;print('vllm',vllm.__version__,'torch',torch.__version__,'cuda',torch.version.cuda)"
  sha256sum "$E/wheels/"*.whl
  pkill -f '[v]llm serve' 2>/dev/null; sleep 5
  "$E/.venv/bin/python" "$X/soak.py" --deadline-min 195
  rc=$?
  echo "=== soak exit=$rc $(date -u +%FT%TZ)"
  pkill -f '[v]llm serve' 2>/dev/null; sleep 5
  nvidia-smi --query-gpu=memory.used --format=csv,noheader
  echo "=== soak end $(date -u +%FT%TZ)"
} 2>&1 | tee -a "$X/logs/soak.log"
