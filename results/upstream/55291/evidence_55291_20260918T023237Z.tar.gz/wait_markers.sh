#!/usr/bin/env bash
# Poll for both GPU-release markers every 60s, up to 4 hours. Exit 0 = released, 3 = timeout.
A=/home/mark/shared/tmp-scratch/A_done.marker
B=/home/mark/shared/tmp-scratch/B_done.marker
DEADLINE=$(( $(date +%s) + 4*3600 ))
echo "wait start $(date -u +%FT%TZ) deadline $(date -u -d @$DEADLINE +%FT%TZ)"
while :; do
  if [ -e "$A" ] && [ -e "$B" ]; then
    echo "BOTH MARKERS PRESENT $(date -u +%FT%TZ)"; ls -la "$A" "$B"; exit 0
  fi
  if [ "$(date +%s)" -ge "$DEADLINE" ]; then
    echo "TIMEOUT: GPU not released after 4h $(date -u +%FT%TZ)"
    [ -e "$A" ] && echo "A present" || echo "A missing"
    [ -e "$B" ] && echo "B present" || echo "B missing"
    exit 3
  fi
  sleep 60
done
