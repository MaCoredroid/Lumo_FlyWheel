#!/usr/bin/env bash
set -u
E=/home/mark/shared/exp54928
X=$E/exp55291
export HF_HOME="$E/hf"
REPO=Qwen/Qwen3.6-27B-FP8
REV=e89b16ebf1988b3d6befa7de50abc2d76f26eb09
{
echo "=== download start $(date -u +%FT%TZ) repo=$REPO rev=$REV"
"$E/.venv/bin/hf" download "$REPO" --revision "$REV" 2>&1 | tail -5
echo "=== exit=$? $(date -u +%FT%TZ)"
du -sh "$HF_HOME/hub/models--Qwen--Qwen3.6-27B-FP8"
ls "$HF_HOME/hub/models--Qwen--Qwen3.6-27B-FP8/snapshots/"
echo "=== download end $(date -u +%FT%TZ)"
} 2>&1 | tee -a "$X/logs/download.log"
