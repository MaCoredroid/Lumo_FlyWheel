# Mechanism, route and agent-workload evidence — 23 September 2026

The agent deployment and the numerical-qualification route are separate configurations. Loaded receipts establish engagement; a configured flag alone does not prove a launch or an isolated gain.

| Mechanism | NVFP4 Hydra27 coding-agent route | FP8 Cat10 qualification | Agent-workload attribution |
| --- | --- | --- | --- |
| Shared descriptor / scan-replay publication | Active,32 physical rows and 27 active drafts | Ten-node Cat10, flat slots | Workload case only; no state-policy timing ablation |
| Draft-logit reuse | Enabled with full-vocabulary head | Same-input head/candidate checks | No same-workload ON/OFF comparison |
| Probability/acceptance processing | Stochastic full-vocabulary fixed32 route | Greedy route with Python loops/readbacks | Do not equate the two paths or infer a general sampler-law proof |
| Convolution / packed operands | Configured fused convolution, pregather and eager pack | Source-bound vectorized helper and packed buffers | No isolated agent gain; packed buffers do not prove all-layer replay |
| Attention | Engaged patched FA2 GQA-pair split-K4 | Stock TREE_ATTN flat-map reads/writes | Cqc10 completed case, no matched full-task attention ablation |
| Graphs and prefix caching | Enabled | Disabled for bounded qualification | Qualification does not transfer automatically |
| Fixed32 GDN single launch | Disabled in deployed case | Outside generic Cat10 | No composed improvement claimed |

Current pooled comparison: `results/agent-workload/competitive-rate-audit.json`. The best recorded tree run reaches **29.09 pooled tokens/s** on SWE-bench Verified Astropy tasks 12907 and 13033. The two recovered SGLang EAGLE runs reach **26.89 and 30.70** on those same tasks. The tree is 8.18% above the later run and 5.23% below the earlier run; there is no best-versus-best speed win in these records. Later tree rates and the separate ten-task result remain visible. Each system's decoder design and optimizations are part of the measured system. A matched component ablation is needed only for isolated optimization attribution. Earlier E1/E8 local-document timings remain audit-only.