Current best shared-task revision (24 September 2026): the headline is Sr12 29.09 versus SGLang EAGLE26.89 pooled tokens/s on identical task IDs. The package retains later runs, the full Sr12 cohort and Cqc10. Run `results/agent-workload/shared_task_reduce.py`; see FINAL-DELIVERY.json for final identities. Entries below are dated earlier checkpoints.

Current pooled decode revision (23 September 2026): the common tree/SGLang comparison and its 48 hash-bound input files are packaged with the current paper. Run `results/agent-workload/shared_rate_reduce.py` from the extracted paper directory. See `FINAL-DELIVERY.json` for final source/PDF/archive identity. Older checkpoints below retain their original scope and superseded estimator labels.

Current history-correction revision (23 September 2026): executed comparator experiments are acknowledged; superseded rates remain excluded. The current PDF and source checkpoint are identified by `FINAL-DELIVERY.json`. See `../notes/comparator-git-history-2026-09-23.md`.

> **Current scope — 23 September 2026:** Paper performance now uses only named coding-agent workloads. E1/E8 local-document rate results below are audit history, not current manuscript claims. Latest eligible completed workload case is dated Cqc10 NVFP4; matched current native/tree task comparison remains proposed, not launched. See `review-experiments.md` and current `FINAL-REVIEW.md`. Earlier completion statements apply only to their original bounded scope.

# Private review checkpoints

These files are private review artifacts. The latest manuscript uses the qualified design and final current results; obsolete narratives and pilot-only summaries have been removed. Core E1/E2/E7 evidence remains unchanged. E8 is complete and independently verified, with two qualification and six timing boots. No further GPU experiment is required for the bounded claims. The delivery receipt identifies the latest reviewed PDF/build and paper archive, which binds five evidence companions. Dated entries below describe preserved earlier checkpoints.

The new E8 companion is `e8-single-logits-20260922T2255Z.tar.gz`: 702 payload files, 16,237,576 bytes, SHA-256 `b4c0a5cbcd2592ce5ddfdc823243f0e99dc15ef412d238a096068d6bae11ebf4`. It preserves every attempted E8 source/run and the final raw review. Extract to an empty directory treated as v2, then run `python3 -B scripts/export_e8.py --paper . --verify-extracted`. This verifies member hashes, two qualification and six timing joins, and the entire aggregate with only relocated path metadata normalized for comparison. No model weights or Docker image are redistributed. Review `../p0/monitor/e8-artifact-final-redteam.md` and the delivery receipt for final extraction verification.

Reviewed manuscript/E7a checkpoint (2026-09-22; predates the added model diagnostics):

- `paper-review-20260922T0710Z.tar.gz`: manuscript/PDF,80hash-manifested files, historical accounting sources, P0 audit sources, exact older E7a source versions. SHA256 `3676083f2e7b3c7b31ce1648ddebbf9dfcb804bf80363bb43261e8c79ed6c8ea`.
- `e7a-evidence-20260922T0709Z.tar.gz` and `.manifest.json`:2859files, all8frozen pilot inputs/provenance,31primaryconfirmation inputs plus original failure/retry records, native selection pool/scores,4historical tensors, result JSON and frozen-analysis erratum. SHA256 `776ddcaf5d938cc665bafca20f46e29d1e9a550a34914d798e78f70636cd180b`.

All companion file hashes were verified after transfer. Targeted independent review closed the missing-file findings in `../p0/monitor/artifact-redteam-round1.md`. Original absolute paths are preserved and mapped explicitly; hash verification and raw-result inspection are supported, while a full unmodified GPU rerun on a different host is not certified. The pinned image and model are external dependencies; model weights and JIT cache bytes are excluded.

The earlier0700E7a and0702paper pair is superseded because it omitted3pilot captures,4historical tensors,selection data and older source/P0 records. Preserve it as audit history, use the newer pair for review. `review-smoke-*` directories are extracted verification workspaces, not authoritative evidence.

Rebuild with `../scripts/build_review_bundle.py --output <new filename>` after final experiments/claim ledger stabilize; do not overwrite old snapshots.

Additional completed diagnostic evidence:

- `e7b-diagnostics-20260922T0801Z.tar.gz` and `.manifest.json`: 727 files, 2,179,735,658 archive bytes. Includes both completed three-boot batches, raw operands/states/hidden/logit captures, executed snapshots, and the reviewed CPU continuation source/dependencies. SHA-256 `c573b5064d944547df280e314520a97dd0c10678fb877c8d75b3a898d548ad05`. Every member size and hash was independently verified after transfer (see `../p0/monitor/2026-09-22-e7b-artifact-checkpoint.json`). These six boots had plain-route attention-KV remap disabled; they support the stated local diagnostics, not full-route qualification.

The twelve-page manuscript/PDF at08:37 UTC included the independently reviewed verifier/commit diagnostics and explicit KV-off limitation. It was newer than the0710 manuscript archive. The final manuscript archive must be rebuilt with this E7b companion and the eventual corrected-route/timing evidence; no current archive should be represented as the completed v2 release.

Latest intermediate manuscript checkpoint:

- `paper-review-20260922T0837Z.tar.gz`: 98 manifest-listed files, current twelve-page manuscript/PDF, updated scope, diagnostic results and independent review reports. SHA-256 `745ca13026dfff18f9cd1b50b7547d2e600477ce41af5098d2fa146e7c059111`. Its manifest binds both the 0709 E7a and 0801 E7b companions. Every member hash passed, archived historical accounting reproduced, and the extracted manuscript rebuilt without warnings (`../p0/monitor/2026-09-22-paper-checkpoint0837.json`). This supersedes the 0710 manuscript checkpoint for reviewing the current text, but still precedes completed serving-route qualification and E1 timing. Retain all earlier checkpoints as audit history.


## Selected-route evidence checkpoint, 2026-09-22 09:34 UTC

`selected-route-20260922T0930Z.tar.gz` and its `.manifest.json` contain840 files /1,735,458,237 bytes. Archive SHA-256: `7f127f0c2e8198f067eb0f59737e1a58afc34991aa562dacbc11d7d147d25a30`. All member hashes and the embedded manifest were verified locally; proof is `p0/monitor/2026-09-22-selected-route-artifact-checkpoint.json`.

The three captured roots preserve incompatible policy A (including the failed async recorder) and the selected synchronous flat-slot B1/B4 pilots. The B4 loop's original failed verdict is retained together with the reviewed v3e offline gate, independently derived exact API-ID evidence, and corrected numerical-label summary. Later offline analyzers and repository helper dependencies are copied under `p0/monitor/selected-route-source-20260922T0928Z`; its README records the path mapping and distinguishes reviewed sources from other preserved dependencies. These are finite continuation checks, not warmed timing or full-model sequential-equivalence evidence.

The current selected-route manuscript text has passed independent review; native live preflight,18 E1 confirmation cells, and a final paper bundle remain pending. The0837 paper archive above is still an older intermediate checkpoint. No file has been published or submitted.


Latest manuscript archive (09:48 UTC): `paper-review-20260922T0948Z.tar.gz`,110 files, SHA-256 `7899411a6ded18ffd6f94f6da72a1de66a126720a5774d03505f1152fd174279`. It contains the13-page paper at source1857d760 / abstract9a29ea33 / PDF93610803 and binds allthree companions. Every member size/hash passed; the canonical manuscript was built and visually checked immediately before packaging. This supersedes0837 for the selected-route text, while native preflight and E1 timing are still pending. Proof: `p0/monitor/2026-09-22-paper-checkpoint0948.json`.


Working manuscript checkpoint10:16 UTC: `paper-review-20260922T1016Z.tar.gz`, 118 files, SHA-256 `6c5560a1c518f6cdad65d81fbff81721815d3ee38033d9f93f22a602e7c883f7`. Includes current13-page paperf52a828f/abstract0eddd199/PDFae619da4, closed whole-paper review and first-native-cell audit. Every member size/hash verified; allthree earlier evidence companions bound. E1 campaign is still running; this is not a final result package. Proof: `../p0/monitor/2026-09-22-paper-checkpoint1016.json`.


## Final E1 evidence companion, 2026-09-22

`e1-timing-20260922T1225Z.tar.gz` and `.manifest.json`: 1,482 payload files; 12,955,447 archive bytes; SHA-256 `bf50b33386eb9614cf7874039f60cb62a484ee62bc0882e32ab32731857318d6`. All member sizes/hashes and the exact member set were checked in `../p0/monitor/2026-09-22-e1-artifact-checkpoint.json`. Independent essential-evidence/source/reducer/qualification completeness review is `../p0/monitor/e1-artifact-final-redteam.md`.

The archive contains the original 18 cells, 230 phase captures, 90 loaded modules, direct API IDs, event records, the frozen aggregate, support/exclusion tables, full-stream diagnostics, exact guarded dependencies and T1 deviation records. It retains the native/tree engine-seed difference, the EOS outcome, and continuation divergence. The measured rates compare as-executed instrumented configurations on fixed prefixes; they are not matched-output, quality-preserving, seed-controlled causal speedups.

The final paper package built by `../scripts/build_review_bundle.py` binds all four evidence companions. Extract the paper archive at a scratch repository root and companions at a separate evidence root. Original DGX paths remain in provenance; replay needs explicit path mapping. For raw E1 accounting, use the archived direct-ID mapper/joiner with a cell's event/API/join inputs and a separate output path. The frozen aggregate writes `aggregate.json`, so use a writable scratch copy. Fresh serving additionally requires the pinned external model/image/runtime. Copied-byte verification does not certify an unmodified cross-host GPU rerun.


## Historical-number removal revision, 2026-09-22 19:45 UTC

The current 11-page manuscript reports quantitative results only from fresh v2 captures or fresh synthetic controls. Historical result numbers, plots and mixed archived-operand remeasurements were removed at the author's request; historical raw files and earlier immutable checkpoints remain audit evidence. `paper-final-20260922T194605Z.tar.gz` supersedes the 12:39 paper archive for manuscript review and binds the same four unchanged raw-evidence companions. See `FINAL-DELIVERY.json` for archive hashes and member checks; the independent removal review and canonical build/visual proof are included in the archive. The earlier extracted numerical replay checks remain applicable to the unchanged raw evidence, not a claim of a repeated GPU campaign.
