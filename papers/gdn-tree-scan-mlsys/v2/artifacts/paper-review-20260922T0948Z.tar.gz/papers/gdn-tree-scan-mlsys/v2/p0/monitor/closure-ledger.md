# V2 closure ledger

Created UTC: 2026-09-22T06:29:36.802397+00:00
Owner: Codex coordinator. Implementation/GPU owner: existing Claude tmux lumo-v2-20260921. Independent paper review: Codex subagent paper_redteam_round1 (read-only source/evidence).

## User authorization and endpoint
The user explicitly asked to drive the work, spawn an independent paper red-team agent, and repeat fixes/experiments until no new necessary fixes or experiments remain. Continue without another user permission checkpoint for this already authorized bounded work. Internal numerical/provenance/runtime gates remain mandatory. No publishing, submission, external messages, new quantization/task-quality campaigns, or authors-system port is implied.

Completion requires: (1) no unresolved material paper/harness correctness or evidence findings; (2) the agreed E7a -> E2/E7b -> E1 sequence completed where technically supportable, including necessary minimal follow-ups; (3) a traceable claim-to-artifact ledger and honest failures/limits; (4) current compiled and visually inspected PDF; (5) a fresh independent red-team pass with no new unresolved material findings. Do not achieve completion merely by deleting a difficult central claim. Optional research directions do not prevent closing a defensible finite scope. If a necessary route remains technically impossible, record attempted fixes and narrow the affected claim with explicit evidence; do not silently declare the experiment passed.

## Current findings / disposition
Current snapshot: 2026-09-22T09:13:43.683103+00:00. Dated updates below preserve superseded settings and review chronology.

| ID | Finding | Current disposition |
| --- | --- | --- |
| R12/R13 | Aliasing, publication row, matched sham, continuation identity | CLOSED within independently verified diagnostic scope |
| E7a | Frozen analysis and provenance failures | PRESERVED: 31/32 provenance, 31 eligible; original frozen rules failed |
| E7b | Stage-isolated propagation and offline continuation | CLOSED narrow observations: six boots, KV off, one prefix, ten API-bound offline intervals |
| E2 fixtures | Conv, pending token, KV and B4 packing | CLOSED bounded helper contracts; live byte snapshots not claimed |
| E2 policy | Slot reorder on TREE_ATTN | Incompatibility preserved; selected flat policy B = remap1/reorder0/syncfree1, explicit synchronous scheduling |
| E2 B1 | Actual selected route | CLOSED bounded live checks:12 captures,11 state links,31 post-prefill API tokens independently reconstructed |
| E2 B4 | Actual four-request cohort | Executed; corrected gate and per-request fidelity review active; original failed verdicts retained |
| B4 identity/path | API decoded strings and duplicate siblings | CLOSED independent exact unique inversion for128 tokens; published p085 path legal under sampled sibling selection |
| E1 recorder | Event lifecycle | CPU v5 and actual synchronous B1 closed; B4 final review and native baseline source audit active |
| E1 timing | Frozen-stack campaign | 0/18; immutable campaign driver being built, coverage/precision criteria decided before data |
| Paper | Source/PDF | Selected-route section added; current source awaits next PDF build; last verified PDF242689ea |
| Artifacts | Private evidence | E7a2859files and E7b727files fully verified; final corrected-route/E1/paper packages pending |

## Immediate queue
1. Independently close versioned B4 per-request state, full-logit/path, exact API-ID and frozen-class numerical checks; preserve original reducers and failures.
2. Finish immutable18-cell driver/client/manifest. Native MTP may share the patched runner only with explicit mode/descriptor guards proving the native path, plus live preflight before retained data.
3. Freeze all source/settings before first retained data. B1 requires each of eight prompts >=1 retained interval (N1>=8); B4 each of two cohorts >=1 full four-request interval (N4>=2). These support floors are distinct from the10% precision target.
4. Execute18serialtimingcells, integrate verified results, rebuild/inspect PDF, refresh private packages and obtain a fresh final independent review. Repeat only for unresolved material findings.


## Counting and communication
Every ten-minute report: actual Pacific time; completed/planned counting units; independently verified vs merely completed; real GPU/container jobs; Claude and red-team activity; blockers and next/overall ETA with assumptions. Old E7b diagnostics remain 3 distinct completed boots under a superseded protocol, not completed science cells in the new plan. Corrected validation 0/3 at ledger creation. E7a kernel campaigns2, pilot8/8, confirmation31/32 provenance, eligible GPU comparisons31/31. E2 qualified0; E1 timing0/18. No inferred finish deadline.

## Review14 update 2026-09-22T06:42:32.462153+00:00
Independent round1 complete, manuscript ca191a41 and11-page PDF rebuilt/visually checked; round2 running. New omitted frozen-rule finding reproduced and disclosed; exhaustive checker/erratum pending with Claude. Source-level review13 repairs and10commit+15reducer CPU tests pass. New validation completed 2/3; real paired interpretation pending. Artifact bundling remains open; final source citation must resolve v2 data rather than only pre-v2 commit.

## Review15 update 2026-09-22T06:54:51.445892+00:00
Corrected p072 validation completed3/3; GPU idle after owned containers exited. Independent read-only validation review active. New P1 authoritative-state-row bug: commit substitution targets accepted column but stateless next forward consumes col0. No commit/both runs authorized until corrected and negative-control validated. Current verifier-only comparison remains usable; terminal-copy state captures are not proven consumed-state observations. E2/E7b0 qualified; E1 0/18.

Paper redteam round2 complete: material H3 support mismatch; parent independently checked all3 historical sources/hashes and raw counters. Manuscript/abstract/figure relabeled as proxy/residual; P0 addendum and support JSON added. New PDF build pending. Exhaustive frozen checker/erratum completed by Claude, independent review active.

## Review16 execution update 2026-09-22T07:12:00.227226+00:00
- Verifier threeboot3/3 independently checked; narrow single-prefix propagation witness in notes/verified-e7b-p072-r13.md.
- Authoritative-col0 fix passed12CPUcontrols per current/staged runtime plus independently checked actual next verify consumption. New commit batch0/3 started07:07:29Z: none/matchedBcommitsham/commitonly, all capture_operands; expected07:25-07:28Z if healthy.
- Continuation fixture review found malformed path, missing steps, wrong-row/next-h0 and carry-precision labels did not fail closed; Claude repairing, independent reviewer will recheck once settled. Full-model E2 remains0qualified, E1 0/18.
- H3 manuscript finding CLOSED by independent round2 atmain5e579cbf, PDF9b15aabb built11pages and visually inspected. No other material manuscript finding from that pass.
- Frozen checker completeness CLOSED, all prior frozen failures retained.
- Private artifact checkpoint paper0710(80files)+E7a0709(2859files) added missing pilot tensors, selection sources, four historical tensors, exact historical harness sources and P0 reconstructions. Parent verified every companion hash and8/8pilotpayload/provenance. Independent artifact followup pending; final bundle must refresh after ongoing experiments.

## Review17 invalid capture protocol 2026-09-22T07:17:00.530822+00:00
The07:07:29Zcommit batch was STOPPED: v7driver snapshotted/re-executed v6, so the executed spec defaulted capture_operands=false. Firstboot completed13statefiles/0operands; secondboot aborted during loading; third never launched. None qualifies for planned fixed-input continuation. Preserve these1completed+1abortedattempts separately. Parent direct evidence:2026-09-22-review-17-disabled-operands.json. Claude repairing actual snapshot/reexec self-reference and full-path preflight before new3bootbatch.

E1 design redteam flags overlapping per-request intervals: count unique physical-step wall intervals once for aggregateB4throughput, and explicitly qualify each actualbatch/graph/cache/sampling/descriptor route instead of treatingB1eagerqualification as blanket18cellpermission. Existing planned18cells unchanged.

## Corrected commit batch restart 2026-09-22T07:22:16.607455+00:00
New rootout-20260922T071945Z-e7b-r16-p072-commit-batch started07:19:45Z. Full three-arm stub launcher preflight passed; parent checked actual firstbootwritten capture_operands/state=true and self-reexecv7(no v6snapshot). Actualsnapshotdriver5d1dafa4,runtime9c3a6d94,shim40063932,loopa5b47e09,operandsgate8c2a0862. Boot1expected07:26Z, batch07:39-07:42Z ifhealthy. No experimentqualification yet.

## First corrected baseline verified 2026-09-22T07:28:26.272083+00:00
Completed1/3, matchedcommitshamboot2 started07:25:41Z. Actual loadedcapture_operands=true,13operands/13states,provenanceandoperandsgatesPASS. ParentdirectCPU tensorcheck all12nextforwardh0s bitwise match authoritativepublishedrow21 (acceptedlengths0,1,2,3,4,5 represented). Parentfixturebaseline13steps pass declaredT9/T10/T6 numericalclasses, maxoracle-replayabs7.15e-7; noarmcontinuationrunyet. This is layer-level baselineevidence,notfullconv/KV/E2qualification.

Settled continuation27/27controls and targetedE2CPU66/66pass. Independentreview leaves2identitychecks: armoperandtopology must match and fullpositionsmustcoverallrowids. Claude repairing. NoadditionalGPUcampaignneededfortheseCPUfixes.

## Review18 progress 2026-09-22T07:37:34.997555+00:00
Continuation fixture original identity findings CLOSED by independent review16 (report df619d12); actual baseline13/13 numerical fidelity and12/12 bitwise next-h0 linkage. No whole-model qualification implied. Corrected commit batch2/3complete; compact commit-only running since07:31:41Z, independent raw-arm review dispatched.

E1 implementation redteam found five repair items: actual emitted-ID/event binding, explicit mixed-step breaks, request IDs in the same coordinate order as replay arrays, strict cohort uniqueness/completeness with instrumentation loss invalidating cells, and nonthrowing sink failure. Full report copied to worker; no timing until settled repairs independently pass. Unique physical interval summation itself is correct. Planned18cells unchanged. Q1 pinned-image fixture rerun and minimalJ3two baseline captures can proceed after currentbatch when gates pass; native/B4 exact measured routes still require explicit qualification. Artifact gaps closed in private0709/0710checkpoints, final refresh pending results.

## Corrected commit batch complete 2026-09-22T07:43:41.799055+00:00
All3boot gatesPASS; independentrawcheck none/sham bitwise identical, compactcommitactuallypublishes13changes andall12next-h0linksconsume publishedbytes.12matchedverificationcalls butonly11completeAPI-boundpostcommitboundaries; terminalpartialandextra13thcapturemustnotbeclaimedasfullyemittedcontinuation. CPUfixedinputreviewpending. Q1pinned-imagefixturecontainer e2-tests-074236running.

NewE2routeP1: r16loadedconfigurationandlauncheromitFR13_ATTN_KV_REMAP; sourceplainroutegate defaults0 andnoncontiguouscat10pathshavepotentialKVremaprequirement. Workeraskedtoinvestigateandqualifyintendedloadedpolicy; J3sameungatedrouteHELDpendingresolution. Layer62arithmeticevidencestandswithin scope. E1precisionfreezewordingcorrectionrequested; timingstill0/18. Parentlocalmain210c5e5daddsverifiedverifierdiagnostic, buildheldforcombinedcommitresultupdate.

## Review19 route and lifecycle work 2026-09-22T08:08:22.688169+00:00
Canonical serving policy selected from required_tree_flags.sh: KV remap, slot reorder and sync-free remap all enabled. The earlier flat-layout suggestion is superseded. The initial13newfixture passes do not close current-route coverage: selected sync-free/permutation path, actual shared-page SSM safety, and production pending-token consumer require repairs. Fused-conv16default-mode failures were localized to stale legacy test-reference row semantics; legacy tests can be labeled/pinned, but current cat10 B1/B4 RUNROW_INIT=1 coverage must still pass. No production-row switch is permitted merely to make tests green.

E1 original ID/cohort/mixed-interval negatives are closed at v3, but real prefill output, warmup phase selection and final sink failure need the v5 lifecycle repair and independent recheck. Primary rate will retain valid slow same-cohort pure intervals; a1.5s cutoff is diagnostic only unless an explicit idle/phase break exists. B4 warmup must exercise four actual requests. Timing remains0/18; no model/GPU job running at the latest check.

Private E7b snapshot completed:727files,2179735658bytes,archiveSHA c573b5064d944547df280e314520a97dd0c10678fb877c8d75b3a898d548ad05. Download complete; local per-member verification running. Paper/PDF remain12pages d4e10045/69cc2d40, with KV-off limitation explicit.

## Review20 canonical B1 and first recorder integration 2026-09-22T08:19:57.655608+00:00
First corrected-policy B1 boot completed08:17:58Z: provenance PASS, seven operand captures, operand gate PASS, slot pi and KV-remap engagement observed. It emitted18tokens. Recorder INVALID: actual async scheduling produced8expliciterrors,0output records, and a closing seal retaining those errors. Switch to an explicit matched synchronous scheduling route before E1 and validate it live; no favorable-prefix reduction is allowed. No E1 timing cell has run.

Independent fixtures still require source-consistent KV slot/node identity and distinct per-page remainder sentinels; full-page corruption must fail. Pending-token double-consume negative is now caught. The E7b companion download and all727member hashes are fully verified. Current-route qualification remains0/2.

## Review21 selected backend contract 2026-09-22T08:33:06.341611+00:00
Independent source analysis proves policyA incompatibility on TREE_ATTN: KV writes use permuted slot_mapping but unified attention reads flat block-table positions with unchanged node masks. CPU query3address witness reads[0,1,4]ratherthan[0,1,3]. Parent actual first-forward audit found identical positions/inputhidden, firstdifferenceatlayer3, finalmaxlogit6.125 and changedargmaxrow5. Select policyB remap1/reorder0/syncfree1, explicit sync scheduling. No forkedFAport or extraablation. B1started08:28:15Z; B4mustcapture40rows. All originalnewfixturefindings independentlyclosed; actualservedgates stillpending.


## Review22 corrected B1, B4 interpretation and launch preparation 2026-09-22T09:13:43.683103+00:00
Policy-B B1 independently passes full captured-logit/draft walks, exact state handoffs and sealed API/event reconciliation. Actual B4 completed four32-token requests, eight full-B4 forwards and seven complete B4-to-B4 intervals. Original operands gate failed by flattening request/step identity; revised gates are under independent negative-control review.

The apparent C4 mismatch was p085, not p095. Equal-token siblings561 have equal overlap weights and sampled source selection. Published[1,3] legally emits13,561,8057; neither FIRST/LAST nor maximal path is guaranteed. Preserve v3 failure and v3b last-child reinterpretation. Exact API formatter/tokenizer enumeration independently recovers all128 decoded strings uniquely over all248320 model output IDs, including seven tokenizer_config-only special tokens and UTF-8 repair; write a labeled derived sidecar, request direct IDs for future work.

Native MTP in a shared patched runner is provisionally selected for matched instrumentation, conditional on actual naive_mtp mode/no tree descriptor/native state-sampler source guards. Baked tree helpers cannot be called disabled merely by env. No native boot or E1 timing data yet. GPU is idle; idle memory retention is being recovered under the existing guarded cleanup authorization.


## Review23 selected-route closure and timing campaign repair 2026-09-22T09:31Z
Bounded policy-B B1 and B4 qualification is CLOSED. Independent B4 review105d5eb7 reproduces53 layer62 numerical dictionaries,49 byte-exact state links,32 full-logit request blocks,85 structural/83 captured-support API tokens and128 total API tokens. Original failed loop remains failed; final v3e offline gates and isolated refusal controls pass. No additional J3 boot is needed. The duplicate/compaction request is p085. Native source guards preserve stock critical-path AST; native live preflights remain pending.

E1 launch report a4571ea0 identifies six concrete draft integration blockers (embedded Python syntax, asymmetric heavy diagnostics, API/engine phase mapping, preflight ordered after timing, mutable campaign/overwrite, and zero support misclassification). Claude is completing one repair pass and CPU stubs; reviewer recheck waits settled hashes. E1 0/18; no confirmation data collected. Idle memory recovery restored101.5GiBavailable/swap0 without killing processes.

Selected-route private archive built:840files,1735458237bytes,SHA7f127f0c2e8198f067eb0f59737e1a58afc34991aa562dacbc11d7d147d25a30. Includes allthree completed roots (failed policyA and corrected B1/B4), original verdicts, independently reviewed final analyzers/reports and supporting source dependencies. Local transfer/hash verification pending. Parent main/abstract incorporate the closed counts and finite limits; next combined PDF rebuild pending, last inspected13pagePDF8cd3d8f4.
